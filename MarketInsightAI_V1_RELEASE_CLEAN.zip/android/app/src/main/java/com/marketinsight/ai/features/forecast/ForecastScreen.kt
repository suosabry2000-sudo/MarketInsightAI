package com.marketinsight.ai.features.forecast

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.DataQuality
import com.marketinsight.ai.core.model.Forecast
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*

@Composable
fun ForecastScreen(ticker: String, repository: MarketRepository) {
    var result by remember(ticker) { mutableStateOf<FetchResult<Forecast>?>(null) }
    LaunchedEffect(ticker) { result = repository.forecast(ticker) }
    val f = result?.data
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("$ticker AI Forecast", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text("Forecast ranges are probabilistic estimates, not guaranteed prices or investment advice.", style = MaterialTheme.typography.bodySmall)
        }
        item { StatusBanner(result?.isOffline == true, result?.isDemo == true, result?.error) }
        if (f == null) item { CircularProgressIndicator() } else {
            item {
                if (f.dataQuality != DataQuality.VERIFIED) {
                    SectionCard("Forecast Warning") {
                        Text(when (f.dataQuality) {
                            DataQuality.DATA_CONFLICT -> "DATA CONFLICT — source disagreement reduces reliability."
                            DataQuality.NO_RELIABLE_FORECAST -> "NO RELIABLE FORECAST — evidence threshold not met."
                            DataQuality.STALE -> "STALE — forecast is not based on fresh market data."
                            DataQuality.LIMITED -> "LIMITED — some evidence is unavailable or incomplete."
                            else -> "VERIFIED"
                        })
                    }
                }
            }
            item {
                SectionCard("Tomorrow") {
                    MetricRow("Open", f.tomorrowOpen?.let(::money) ?: "—")
                    MetricRow("Low", f.tomorrowLow?.let(::money) ?: "—")
                    MetricRow("High", f.tomorrowHigh?.let(::money) ?: "—")
                    MetricRow("Close", f.tomorrowClose?.let(::money) ?: "—")
                    MetricRow("Confidence", "%.0f%%".format(f.confidence))
                    MetricRow("Bull probability", probability(f.bullProbability))
                    MetricRow("Bear probability", probability(f.bearProbability))
                    MetricRow("Risk", f.risk)
                }
            }
            item {
                SectionCard("Bear / Base / Bull") {
                    MetricRow("Bear", money(f.bearTarget))
                    MetricRow("Base", money(f.baseTarget))
                    MetricRow("Bull", money(f.bullTarget))
                    Text("Base is the center case, not a guaranteed target.", style = MaterialTheme.typography.bodySmall)
                }
            }
            item {
                SectionCard("Monday → Friday") {
                    if (f.dailyRows.isEmpty()) Text("Daily path unavailable for this forecast.")
                    f.dailyRows.forEach { row ->
                        Text(row.date, fontWeight = FontWeight.Bold)
                        MetricRow("Low / High", "${money(row.low)} / ${money(row.high)}")
                        MetricRow("Base", money(row.base))
                        MetricRow("Confidence", "%.0f%%".format(row.confidence))
                        Divider()
                    }
                }
            }
            item {
                SectionCard("Why this forecast?") {
                    Text(f.explanation.ifBlank { "The backend did not provide an explanation for this forecast." })
                    Text("Model: ${f.modelVersion}", style = MaterialTheme.typography.bodySmall)
                    QualityBadge(f.dataQuality)
                }
            }
        }
    }
}

@Composable
fun ForecastHubScreen(onOpenScanner: () -> Unit, onOpenStock: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Forecasts", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
        item { Button(onClick = onOpenScanner, modifier = Modifier.fillMaxWidth()) { Text("MON → FRI STOCK LIST") } }
        item {
            SectionCard("Quick Forecast") {
                listOf("AAPL", "NVDA", "MSFT", "AMD", "TSLA").forEach { ticker ->
                    OutlinedButton(onClick = { onOpenStock(ticker) }, modifier = Modifier.fillMaxWidth()) { Text(ticker) }
                }
            }
        }
    }
}
