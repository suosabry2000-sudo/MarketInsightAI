package com.marketinsight.ai.features.weeklyscanner

import com.marketinsight.ai.core.model.DataQuality
import com.marketinsight.ai.core.model.ScannerRow
import org.junit.Assert.assertEquals
import org.junit.Test

class ScannerLogicTest {
    private val aapl = ScannerRow("AAPL",100.0,101.0,95.0,106.0,110.0,6.0,4.9,.7,.3,82.0,75.0,"BULLISH","MEDIUM",DataQuality.VERIFIED,"NASDAQ","Technology",listOf("S&P 500","Nasdaq"),listOf("Technology","AI"),"Mega Cap",true,.2)
    private val amd = ScannerRow("AMD",100.0,98.0,90.0,94.0,105.0,-6.0,-4.0,.3,.7,70.0,50.0,"BEARISH","HIGH",DataQuality.LIMITED,"NASDAQ","Technology",listOf("S&P 500","Nasdaq"),listOf("Technology","Semiconductors"),"Mega Cap",true,.5)

    @Test fun filters_ai_and_semiconductors() {
        assertEquals(listOf("AAPL"), applyScannerFilter(listOf(aapl, amd), ScannerFilter.AI).map { it.ticker })
        assertEquals(listOf("AMD"), applyScannerFilter(listOf(aapl, amd), ScannerFilter.SEMICONDUCTORS).map { it.ticker })
    }

    @Test fun sorts_gain_drop_and_ticker() {
        val rows=listOf(amd,aapl)
        assertEquals("AAPL", applyScannerSort(rows, ScannerSort.HIGHEST_GAIN).first().ticker)
        assertEquals("AMD", applyScannerSort(rows, ScannerSort.HIGHEST_DROP).first().ticker)
        assertEquals(listOf("AAPL","AMD"), applyScannerSort(rows, ScannerSort.TICKER_AZ).map { it.ticker })
    }
}
