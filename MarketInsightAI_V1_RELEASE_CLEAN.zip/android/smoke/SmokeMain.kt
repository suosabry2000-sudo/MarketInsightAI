import com.marketinsight.ai.core.model.DataQuality
import com.marketinsight.ai.core.model.ScannerRow
import com.marketinsight.ai.core.state.FreshnessState
import com.marketinsight.ai.core.state.freshnessState
import com.marketinsight.ai.features.weeklyscanner.ScannerFilter
import com.marketinsight.ai.features.weeklyscanner.ScannerSort
import com.marketinsight.ai.features.weeklyscanner.applyScannerFilter
import com.marketinsight.ai.features.weeklyscanner.applyScannerSort

fun main() {
    check(freshnessState(isOffline = true, ageSeconds = 1.0, quality = DataQuality.VERIFIED) == FreshnessState.OFFLINE)
    check(freshnessState(isOffline = false, ageSeconds = 180.0, quality = DataQuality.VERIFIED) == FreshnessState.STALE)
    val rows = listOf(
        ScannerRow("AAPL", 100.0, 101.0, 95.0, 106.0, 110.0, 6.0, 4.95, .7, .3, 80.0, 72.0, "BULLISH", "MEDIUM", DataQuality.VERIFIED, "NASDAQ", "Technology", listOf("S&P 500", "Nasdaq"), listOf("Technology", "AI"), "Mega Cap", true, .25),
        ScannerRow("AMD", 100.0, 98.0, 90.0, 94.0, 105.0, -6.0, -4.08, .3, .7, 75.0, 58.0, "BEARISH", "HIGH", DataQuality.LIMITED, "NASDAQ", "Technology", listOf("S&P 500", "Nasdaq"), listOf("Technology", "Semiconductors"), "Mega Cap", true, .45),
    )
    check(applyScannerFilter(rows, ScannerFilter.AI).map { it.ticker } == listOf("AAPL"))
    check(applyScannerFilter(rows, ScannerFilter.SEMICONDUCTORS).map { it.ticker } == listOf("AMD"))
    check(applyScannerSort(rows, ScannerSort.HIGHEST_GAIN).first().ticker == "AAPL")
    check(applyScannerSort(rows, ScannerSort.HIGHEST_DROP).first().ticker == "AMD")
    println("Kotlin smoke checks passed")
}
