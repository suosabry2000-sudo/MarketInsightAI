package com.example.proxyvideotester.domain

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TestSessionEngineTest {
    private fun endpoint(host: String) = ProxyEndpoint(host = host, port = 8080)

    @Test fun preservesEndpointOrderAndContinuesAfterFailure() = runTest {
        val attempted = mutableListOf<String>()
        val engine = TestSessionEngine(
            ipCheck = IpCheckPort { ep ->
                attempted += ep.host
                if (ep.host == "bad") IpCheckOutcome(false, false, error = "dead")
                else IpCheckOutcome(true, true, ip = "203.0.113.1", latencyMs = 12)
            },
            playback = PlaybackPort { _, _, requested, _ ->
                PlaybackOutcome(true, requested, requested, 5, 0, 0)
            },
            nowEpochMs = { 1000L },
        )
        val results = engine.run(
            TestSessionRequest(
                mediaUrl = "https://example.test/video.mp4",
                targetDisplay = "https://example.test/video.mp4",
                requestedPlayingMs = 60_000,
                endpoints = listOf(endpoint("one"), endpoint("bad"), endpoint("three")),
            )
        )
        assertEquals(listOf("one", "bad", "three"), attempted)
        assertEquals(listOf(TestStatus.PASSED, TestStatus.PROXY_UNREACHABLE, TestStatus.PASSED), results.map { it.status })
    }

    @Test fun stopMarksCurrentAttemptCancelledAndStartsNoMore() = runTest {
        lateinit var engine: TestSessionEngine
        var playCalls = 0
        engine = TestSessionEngine(
            ipCheck = IpCheckPort { IpCheckOutcome(true, true, ip = "203.0.113.1") },
            playback = PlaybackPort { _, _, _, shouldStop ->
                playCalls += 1
                engine.requestStop()
                assertTrue(shouldStop())
                PlaybackOutcome(true, 1_000, 1_000, 5, 0, 0, cancelled = true)
            },
            nowEpochMs = { 1000L },
        )
        val results = engine.run(
            TestSessionRequest(
                mediaUrl = "https://example.test/video.mp4",
                targetDisplay = "https://example.test/video.mp4",
                requestedPlayingMs = 60_000,
                endpoints = listOf(endpoint("one"), endpoint("two")),
            )
        )
        assertEquals(1, playCalls)
        assertEquals(1, results.size)
        assertEquals(TestStatus.USER_CANCELLED, results.single().status)
    }
}
