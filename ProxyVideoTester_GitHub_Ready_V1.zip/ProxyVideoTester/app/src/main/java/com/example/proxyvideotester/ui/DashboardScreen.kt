package com.example.proxyvideotester.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DashboardScreen(
    state: MainUiState,
    onMediaUrlChange: (String) -> Unit,
    onDurationChange: (String) -> Unit,
    onStart: () -> Unit,
    onStop: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text("Proxy Video Tester", style = MaterialTheme.typography.headlineMedium)
            Text("Real proxy/IP + direct-media playback QA")
        }
        item {
            OutlinedTextField(
                value = state.mediaUrl,
                onValueChange = onMediaUrlChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Authorized direct MP4 / HLS / DASH URL") },
                singleLine = true,
                enabled = !state.session.running,
            )
        }
        item {
            OutlinedTextField(
                value = state.durationText,
                onValueChange = onDurationChange,
                label = { Text("Watch duration (seconds)") },
                singleLine = true,
                enabled = !state.session.running,
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (state.session.running) {
                    Button(onClick = onStop) { Text("Stop Test") }
                } else {
                    Button(onClick = onStart, enabled = state.canStart) { Text("Start Test") }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                SummaryCard("Endpoints", state.enabledEndpoints.size.toString(), Modifier.weight(1f))
                SummaryCard("Passed", state.session.passed.toString(), Modifier.weight(1f))
                SummaryCard("Failed", state.session.failed.toString(), Modifier.weight(1f))
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Current status", style = MaterialTheme.typography.titleMedium)
                    Text(if (state.session.running) "RUNNING" else "IDLE")
                    Text("Current endpoint: ${state.currentEndpoint?.toString() ?: "—"}")
                    Text("Detected IP: ${state.session.detectedIp ?: "—"}")
                    val played = state.livePlayback?.actualPlayingMs ?: state.session.actualPlayingMs
                    Text("Actual playback: ${formatDuration(played)} / ${formatDuration(state.session.requestedPlayingMs)}")
                    Text("Buffering: ${formatDuration(state.livePlayback?.bufferingMs ?: 0)}")
                    Text("Remaining: ${state.session.remaining}")
                }
            }
        }
        if (state.endpoints.isEmpty()) {
            item { Text("Add proxies from the Proxies tab before starting.") }
        } else {
            item { Text("Enabled endpoints", style = MaterialTheme.typography.titleMedium) }
            items(state.enabledEndpoints.take(8), key = { it.id }) { endpoint ->
                Text(endpoint.toString())
            }
        }
    }
}

@Composable
private fun SummaryCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(value, style = MaterialTheme.typography.headlineSmall)
            Text(label)
        }
    }
}

internal fun formatDuration(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0) / 1_000)
    return "%02d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
