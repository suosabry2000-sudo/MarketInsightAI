package com.example.proxyvideotester.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class PlaybackClockTest {
    @Test fun bufferingDoesNotCountTowardPlayedDuration() {
        val clock = PlaybackClock()
        clock.onPlayingChanged(true, 0)
        assertEquals(20_000, clock.playedMs(20_000))
        clock.onPlayingChanged(false, 20_000)
        assertEquals(20_000, clock.playedMs(30_000))
        clock.onPlayingChanged(true, 30_000)
        assertEquals(60_000, clock.playedMs(70_000))
    }
}
