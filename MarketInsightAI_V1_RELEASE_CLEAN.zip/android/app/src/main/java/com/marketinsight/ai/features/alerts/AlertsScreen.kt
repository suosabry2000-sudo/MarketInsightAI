package com.marketinsight.ai.features.alerts

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.messaging.FirebaseMessaging
import com.marketinsight.ai.data.repository.MarketRepository
import kotlinx.coroutines.launch

private data class AlertOption(val label: String, val wire: String, val needsPrice: Boolean = false)
private val options = listOf(
    AlertOption("Price Above", "PRICE_ABOVE", true), AlertOption("Price Below", "PRICE_BELOW", true),
    AlertOption("Signal Change", "SIGNAL_CHANGE"), AlertOption("Confidence Threshold", "CONFIDENCE_THRESHOLD"),
    AlertOption("Weekly Opportunity", "WEEKLY_OPPORTUNITY"), AlertOption("Breaking News", "BREAKING_NEWS"), AlertOption("Earnings Approaching", "EARNINGS_APPROACHING"),
)

@Composable
fun AlertsScreen(repository: MarketRepository) {
    var ticker by remember { mutableStateOf("AAPL") }
    var price by remember { mutableStateOf("300") }
    var selected by remember { mutableStateOf(options.first()) }
    var message by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Alerts", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        OutlinedTextField(value = ticker, onValueChange = { ticker = it.uppercase().take(10) }, label = { Text("Ticker") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Text("Alert Type", fontWeight = FontWeight.Bold)
        options.forEach { option ->
            FilterChip(selected = selected == option, onClick = { selected = option }, label = { Text(option.label) }, modifier = Modifier.fillMaxWidth())
        }
        if (selected.needsPrice) OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Price threshold") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            scope.launch {
                val ok = repository.saveAlert(ticker.takeIf { it.isNotBlank() }, selected.wire, if (selected.needsPrice) price.toDoubleOrNull() else null, repository.intPreference("confidence_threshold", 75))
                message = if (ok) "Alert saved on server." else "Alert saved locally is unavailable; server authentication or network is offline."
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Save Alert") }
        OutlinedButton(onClick = {
            runCatching {
                FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                    if (!task.isSuccessful) { message = "Push token unavailable until Firebase is configured."; return@addOnCompleteListener }
                    scope.launch { message = if (repository.registerPushToken(task.result)) "Push notifications registered." else "Push registration failed; backend may be offline." }
                }
            }.onFailure { message = "Push notifications require Firebase configuration." }
        }, modifier = Modifier.fillMaxWidth()) { Text("Register Push Notifications") }
        message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
        Text("Server-side alerts use verified/fresh market data. The app does not generate market alerts from stale cached prices.", style = MaterialTheme.typography.bodySmall)
    }
}
