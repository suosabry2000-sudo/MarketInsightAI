package com.marketinsight.ai.features.stockdetails

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.*
import com.marketinsight.ai.core.state.freshnessState
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*
import kotlinx.coroutines.launch

private val ranges = listOf("1D", "1W", "1M", "3M", "6M", "1Y", "5Y", "MAX")

@Composable
fun StockDetailsScreen(
    ticker: String,
    repository: MarketRepository,
    onOpenForecast: () -> Unit,
    onOpenTechnical: () -> Unit,
    onOpenFundamentals: () -> Unit,
    onOpenNews: () -> Unit,
    onOpenVerification: () -> Unit,
    onOpenAccuracy: () -> Unit,
) {
    var quoteResult by remember(ticker) { mutableStateOf<FetchResult<Quote>?>(null) }
    var liveQuote by remember(ticker) { mutableStateOf<Quote?>(null) }
    var chartResult by remember(ticker) { mutableStateOf<FetchResult<List<PriceBar>>?>(null) }
    var range by remember { mutableStateOf("1M") }
    var chartType by remember { mutableStateOf("Line") }
    var watchlist by remember { mutableStateOf(repository.localWatchlist()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(ticker) { quoteResult = repository.quote(ticker); liveQuote = quoteResult?.data }
    LaunchedEffect(ticker, range) { chartResult = repository.chart(ticker, range) }
    DisposableEffect(ticker) { repository.quoteSocket.subscribe(listOf(ticker)); onDispose { /* socket shared by repository */ } }
    LaunchedEffect(ticker) { repository.quoteSocket.quotes.collect { if (it.ticker.equals(ticker, true)) liveQuote = it } }

    val quote = liveQuote ?: quoteResult?.data
    val bars = chartResult?.data.orEmpty()
    val previous = bars.dropLast(1).lastOrNull()?.close
    val change = if (quote != null && previous != null && previous != 0.0) (quote.price / previous - 1) * 100 else null

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(ticker.uppercase(), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
                    Text(quote?.feedLabel ?: "Loading market source…", style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = {
                    scope.launch {
                        watchlist = if (ticker.uppercase() in watchlist) repository.removeWatchlist(ticker) else repository.addWatchlist(ticker)
                    }
                }) {
                    Icon(if (ticker.uppercase() in watchlist) Icons.Filled.Star else Icons.Outlined.StarBorder, "Watchlist")
                }
            }
            Text(quote?.let { money(it.price) } ?: "—", style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
            if (change != null) Text(pct(change), color = if (change >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            if (quote != null) QualityBadge(quote.dataQuality, freshnessState(quoteResult?.isOffline == true, quote.freshnessSeconds, quote.dataQuality))
        }
        item { StatusBanner(quoteResult?.isOffline == true || chartResult?.isOffline == true, quoteResult?.isDemo == true || chartResult?.isDemo == true, quoteResult?.error ?: chartResult?.error) }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(ranges) { r -> FilterChip(selected = range == r, onClick = { range = r }, label = { Text(r) }) }
            }
        }
        item {
            SectionCard("Price Chart") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = chartType == "Line", onClick = { chartType = "Line" }, label = { Text("Line") })
                    FilterChip(selected = chartType == "Candlestick", onClick = { chartType = "Candlestick" }, label = { Text("Candlestick") })
                }
                PriceChart(bars, chartType)
                Text("Volume", fontWeight = FontWeight.Bold)
                Text(bars.lastOrNull()?.volume?.let { "%,.0f".format(it) } ?: "—")
            }
        }
        item {
            SectionCard("Stats") {
                MetricRow("Open", bars.lastOrNull()?.let { money(it.open) } ?: "—")
                MetricRow("High", bars.lastOrNull()?.let { money(it.high) } ?: "—")
                MetricRow("Low", bars.lastOrNull()?.let { money(it.low) } ?: "—")
                MetricRow("Previous Close", previous?.let(::money) ?: "—")
                MetricRow("Market Cap", "—")
                MetricRow("Volume", bars.lastOrNull()?.volume?.let { "%,.0f".format(it) } ?: "—")
                MetricRow("Average Volume", bars.takeLast(20).map { it.volume }.takeIf { it.isNotEmpty() }?.average()?.let { "%,.0f".format(it) } ?: "—")
                MetricRow("52-week High", bars.maxOfOrNull { it.high }?.let(::money) ?: "—")
                MetricRow("52-week Low", bars.minOfOrNull { it.low }?.let(::money) ?: "—")
            }
        }
        item {
            SectionCard("Analysis") {
                Button(onClick = onOpenForecast, modifier = Modifier.fillMaxWidth()) { Text("AI Forecast") }
                OutlinedButton(onClick = onOpenTechnical, modifier = Modifier.fillMaxWidth()) { Text("Technical Analysis") }
                OutlinedButton(onClick = onOpenFundamentals, modifier = Modifier.fillMaxWidth()) { Text("Fundamental Analysis") }
                OutlinedButton(onClick = onOpenNews, modifier = Modifier.fillMaxWidth()) { Text("News & Sentiment") }
                OutlinedButton(onClick = onOpenVerification, modifier = Modifier.fillMaxWidth()) { Text("Trusted Source Verification") }
                OutlinedButton(onClick = onOpenAccuracy, modifier = Modifier.fillMaxWidth()) { Text("Model Accuracy") }
            }
        }
        item { Spacer(Modifier.height(36.dp)) }
    }
}

@Composable
private fun PriceChart(bars: List<PriceBar>, chartType: String) {
    val lineColor = MaterialTheme.colorScheme.primary
    val candleColor = MaterialTheme.colorScheme.secondary
    Canvas(Modifier.fillMaxWidth().height(190.dp)) {
        if (bars.size < 2) return@Canvas
        val min = bars.minOf { it.low }; val max = bars.maxOf { it.high }; val span = (max - min).takeIf { it > 0 } ?: 1.0
        fun y(v: Double) = size.height - ((v - min) / span * size.height).toFloat()
        val step = size.width / (bars.size - 1).coerceAtLeast(1)
        if (chartType == "Line") {
            val path = Path()
            bars.forEachIndexed { index, bar ->
                val point = Offset(index * step, y(bar.close)); if (index == 0) path.moveTo(point.x, point.y) else path.lineTo(point.x, point.y)
            }
            drawPath(path, lineColor, style = Stroke(width = 4f))
        } else {
            bars.forEachIndexed { index, bar ->
                val x = index * step
                drawLine(candleColor, Offset(x, y(bar.low)), Offset(x, y(bar.high)), strokeWidth = 2f)
                drawLine(candleColor, Offset(x - 3f, y(bar.open)), Offset(x, y(bar.open)), strokeWidth = 4f)
                drawLine(candleColor, Offset(x, y(bar.close)), Offset(x + 3f, y(bar.close)), strokeWidth = 4f)
            }
        }
    }
}
