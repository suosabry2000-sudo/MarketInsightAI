package com.marketinsight.ai.features.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.MetricRow
import com.marketinsight.ai.ui.SectionCard

@Composable
fun SettingsScreen(repository: MarketRepository, themeMode: String, onThemeChanged: (String) -> Unit, onOpenAlerts: () -> Unit) {
    var chart by remember { mutableStateOf(repository.stringPreference("chart_type", "Line")) }
    var period by remember { mutableStateOf(repository.stringPreference("forecast_period", "Weekly")) }
    var confidence by remember { mutableIntStateOf(repository.intPreference("confidence_threshold", 75)) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Profile & Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
        SectionCard("Appearance") {
            listOf("System", "Light", "Dark").forEach { option ->
                Row(Modifier.fillMaxWidth()) { RadioButton(selected = themeMode == option, onClick = { onThemeChanged(option) }); Text(option, modifier = Modifier.padding(top = 12.dp)) }
            }
        }
        SectionCard("Defaults") {
            Text("Chart Type")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Line", "Candlestick").forEach { option -> FilterChip(selected = chart == option, onClick = { chart = option; repository.setStringPreference("chart_type", option) }, label = { Text(option) }) }
            }
            Text("Forecast Period")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Tomorrow", "Weekly").forEach { option -> FilterChip(selected = period == option, onClick = { period = option; repository.setStringPreference("forecast_period", option) }, label = { Text(option) }) }
            }
            MetricRow("Minimum confidence", "$confidence%")
            Slider(value = confidence.toFloat(), onValueChange = { confidence = it.toInt() }, onValueChangeFinished = { repository.setIntPreference("confidence_threshold", confidence) }, valueRange = 50f..95f)
        }
        Button(onClick = onOpenAlerts, modifier = Modifier.fillMaxWidth()) { Text("Alerts & Notifications") }
        SectionCard("Privacy & About") {
            Text("API keys, provider credentials, and model secrets remain on the backend; the APK contains only public endpoint configuration.")
            Text("Disclaimer", fontWeight = FontWeight.Bold)
            Text("Market Insight AI provides probabilistic research estimates. It does not guarantee prices, returns, or investment outcomes and does not place trades.")
        }
    }
}
