package com.example.proxyvideotester.ui

import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithText
import com.example.proxyvideotester.domain.ProxyEndpoint
import org.junit.Rule
import org.junit.Test

class DashboardScreenTest {
    @get:Rule val compose = createComposeRule()

    @Test fun startIsDisabledWithoutInputs() {
        compose.setContent {
            DashboardScreen(MainUiState(), {}, {}, {}, {})
        }
        compose.onNodeWithText("Start Test").assertIsNotEnabled()
    }

    @Test fun startIsEnabledWithValidMediaAndEndpoint() {
        compose.setContent {
            DashboardScreen(
                MainUiState(
                    mediaUrl = "https://example.test/video.mp4",
                    durationText = "60",
                    endpoints = listOf(ProxyEndpoint(host = "127.0.0.1", port = 8080)),
                ),
                {}, {}, {}, {},
            )
        }
        compose.onNodeWithText("Start Test").assertIsEnabled()
    }
}
