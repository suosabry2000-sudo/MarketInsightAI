package com.example.proxyvideotester.domain

class PlaybackClock {
    private var accumulatedMs: Long = 0
    private var playingSinceMs: Long? = null

    fun onPlayingChanged(isPlaying: Boolean, nowMs: Long) {
        val activeSince = playingSinceMs
        when {
            isPlaying && activeSince == null -> playingSinceMs = nowMs
            !isPlaying && activeSince != null -> {
                accumulatedMs += (nowMs - activeSince).coerceAtLeast(0)
                playingSinceMs = null
            }
        }
    }

    fun playedMs(nowMs: Long): Long {
        val active = playingSinceMs
        return accumulatedMs + if (active != null) (nowMs - active).coerceAtLeast(0) else 0
    }

    fun reset() {
        accumulatedMs = 0
        playingSinceMs = null
    }
}
