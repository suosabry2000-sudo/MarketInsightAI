# Proxy Video Tester

Android network/video QA app for testing an authorized direct MP4/HLS/DASH stream through user-supplied proxy endpoints.

## Scope

This project verifies proxy connectivity and external IP, measures actual Media3 playback time, buffering and latency, and stores/export test results. It is not designed to generate or inflate public platform views or other engagement metrics.

## Supported proxy input

- `host:port`
- `http://host:port`
- `http://user:pass@host:port`
- `socks5://host:port` (unauthenticated only in V1; media support is best-effort and HTTP proxy is the primary acceptance path)

## GitHub one-repo build

Push this folder to a GitHub repository. The included **Android CI** workflow automatically runs unit tests, Android lint, builds the debug APK, and uploads it as the `proxy-video-tester-debug-apk` Actions artifact.

No signing secret is needed for the debug APK.

## Local build

Open the repository in Android Studio (JDK 17, Android SDK 35) or use Gradle 8.9:

```bash
gradle test
gradle lint
gradle assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`.

## One-repository GitHub setup

See [`GITHUB_SETUP.md`](GITHUB_SETUP.md). The repository includes its own Actions workflow, so after upload the debug APK is built entirely by GitHub; no local Android build environment is required to obtain the APK artifact.
