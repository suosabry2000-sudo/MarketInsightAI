package com.example.proxyvideotester.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.proxyvideotester.network.IpVerifier
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore(name = "tester_settings")

data class TesterSettings(
    val defaultDurationSeconds: Int = 60,
    val connectionTimeoutMs: Long = 10_000,
    val startupTimeoutMs: Long = 20_000,
    val ipCheckEndpoint: String = IpVerifier.DEFAULT_IP_ECHO_URL,
    val showPlayerPreview: Boolean = true,
)

class SettingsStore(private val context: Context) {
    private object Keys {
        val duration = intPreferencesKey("default_duration_seconds")
        val connectTimeout = longPreferencesKey("connection_timeout_ms")
        val startupTimeout = longPreferencesKey("startup_timeout_ms")
        val ipEndpoint = stringPreferencesKey("ip_check_endpoint")
        val preview = booleanPreferencesKey("show_player_preview")
    }

    val settings: Flow<TesterSettings> = context.settingsDataStore.data.map { p ->
        TesterSettings(
            defaultDurationSeconds = p[Keys.duration] ?: 60,
            connectionTimeoutMs = p[Keys.connectTimeout] ?: 10_000,
            startupTimeoutMs = p[Keys.startupTimeout] ?: 20_000,
            ipCheckEndpoint = p[Keys.ipEndpoint] ?: IpVerifier.DEFAULT_IP_ECHO_URL,
            showPlayerPreview = p[Keys.preview] ?: true,
        )
    }

    suspend fun update(settings: TesterSettings) {
        context.settingsDataStore.edit { p ->
            p[Keys.duration] = settings.defaultDurationSeconds.coerceIn(1, 3_600)
            p[Keys.connectTimeout] = settings.connectionTimeoutMs.coerceIn(1_000, 120_000)
            p[Keys.startupTimeout] = settings.startupTimeoutMs.coerceIn(1_000, 120_000)
            p[Keys.ipEndpoint] = settings.ipCheckEndpoint
            p[Keys.preview] = settings.showPlayerPreview
        }
    }
}
