package com.marketinsight.ai.features.weeklyscanner

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.ScannerResponse
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*

@Composable
fun WeeklyScannerScreen(repository: MarketRepository, onOpenStock: (String) -> Unit) {
    var result by remember { mutableStateOf<FetchResult<ScannerResponse>?>(null) }
    var filter by remember { mutableStateOf(ScannerFilter.ALL) }
    var sort by remember { mutableStateOf(ScannerSort.BEST_OPPORTUNITY) }
    var sortMenu by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { result = repository.scanner() }
    val watchlist = repository.localWatchlist()
    val visible = applyScannerSort(applyScannerFilter(result?.data?.stocks.orEmpty(), filter, watchlist), sort)

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("MON → FRI STOCK LIST", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text("First valid U.S. trading session → final valid trading session. Forecasts are probabilities, not guarantees.", style = MaterialTheme.typography.bodySmall)
        }
        item { StatusBanner(result?.isOffline == true, result?.isDemo == true, result?.error) }
        item {
            SectionCard("Week") {
                MetricRow("Market", result?.data?.marketStatus ?: "Loading…")
                MetricRow("Reference Session", result?.data?.referenceSession ?: "—")
                MetricRow("Target Session", result?.data?.targetSession ?: "—")
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ScannerFilter.entries) { item ->
                    FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item.label) })
                }
            }
        }
        item {
            Box {
                OutlinedButton(onClick = { sortMenu = true }) { Text("Sort: ${sort.label}") }
                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                    ScannerSort.entries.forEach { option ->
                        DropdownMenuItem(text = { Text(option.label) }, onClick = { sort = option; sortMenu = false })
                    }
                }
            }
        }
        if (visible.isEmpty()) item { Text("No stocks match this filter.") }
        items(visible, key = { it.ticker }) { row ->
            Card(Modifier.fillMaxWidth().clickable { onOpenStock(row.ticker) }) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column { Text(row.ticker, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black); Text(row.signal, color = if (row.expectedMovePct >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
                        QualityBadge(row.dataQuality)
                    }
                    MetricRow("Monday Ref", money(row.mondayReference))
                    MetricRow("Current", money(row.livePrice))
                    Divider()
                    MetricRow("Friday Bear", money(row.fridayBear))
                    MetricRow("Friday Base", money(row.fridayBase))
                    MetricRow("Friday Bull", money(row.fridayBull))
                    MetricRow("Possible Move", pct(row.expectedMovePct))
                    MetricRow("From Current", pct(row.expectedMoveFromLivePct))
                    MetricRow("Bull / Bear", "${probability(row.bullProbability)} / ${probability(row.bearProbability)}")
                    MetricRow("Confidence", "%.0f%%".format(row.confidence))
                    MetricRow("Opportunity", "%.1f / 100".format(row.opportunityScore.coerceIn(0.0, 100.0)))
                    MetricRow("Risk", row.risk)
                }
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
