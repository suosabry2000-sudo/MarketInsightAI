package com.example.proxyvideotester.domain

import java.util.UUID

enum class TestStatus {
    PASSED,
    PROXY_UNREACHABLE,
    IP_VERIFY_FAILED,
    MEDIA_PREPARE_FAILED,
    PLAYBACK_FAILED,
    PLAYBACK_TIMEOUT,
    USER_CANCELLED,
}

data class AttemptFacts(
    val proxyReachable: Boolean,
    val ipVerified: Boolean,
    val mediaPrepared: Boolean,
    val actualPlayingMs: Long,
    val requestedPlayingMs: Long,
    val playbackFailed: Boolean = false,
    val timedOut: Boolean = false,
    val cancelled: Boolean = false,
)

object ResultClassifier {
    fun classify(facts: AttemptFacts): TestStatus = when {
        facts.cancelled -> TestStatus.USER_CANCELLED
        !facts.proxyReachable -> TestStatus.PROXY_UNREACHABLE
        !facts.ipVerified -> TestStatus.IP_VERIFY_FAILED
        !facts.mediaPrepared -> TestStatus.MEDIA_PREPARE_FAILED
        facts.playbackFailed -> TestStatus.PLAYBACK_FAILED
        facts.actualPlayingMs >= facts.requestedPlayingMs -> TestStatus.PASSED
        facts.timedOut -> TestStatus.PLAYBACK_TIMEOUT
        else -> TestStatus.PLAYBACK_FAILED
    }
}

data class EndpointTestResult(
    val id: String = UUID.randomUUID().toString(),
    val sessionId: String,
    val proxyId: String,
    val targetDisplay: String,
    val startedAtEpochMs: Long,
    val finishedAtEpochMs: Long,
    val requestedWatchMs: Long,
    val actualPlayingMs: Long,
    val wallClockMs: Long,
    val detectedPublicIp: String?,
    val connectLatencyMs: Long?,
    val timeToFirstPlaybackMs: Long?,
    val bufferingMs: Long,
    val bufferEventCount: Int,
    val status: TestStatus,
    val errorDetail: String? = null,
)

data class SessionSummary(
    val sessionId: String,
    val total: Int,
    val passed: Int,
    val failed: Int,
    val remaining: Int,
    val currentProxyId: String? = null,
    val detectedIp: String? = null,
    val actualPlayingMs: Long = 0,
    val requestedPlayingMs: Long = 0,
    val running: Boolean = false,
)
