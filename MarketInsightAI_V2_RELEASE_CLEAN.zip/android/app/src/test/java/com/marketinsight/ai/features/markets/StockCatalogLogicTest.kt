package com.marketinsight.ai.features.markets

import com.marketinsight.ai.core.model.StockSearchResult
import org.junit.Assert.assertEquals
import org.junit.Test

class StockCatalogLogicTest {
    private val rows = listOf(
        StockSearchResult("AAA", "Alpha", "NYSE", "Technology", "STOCK", 10.0, 1.0, "AVAILABLE"),
        StockSearchResult("BBB", "Beta", "NASDAQ", "Technology", "STOCK", 30.0, -1.0, "AVAILABLE"),
        StockSearchResult("CCC", "Gamma", "NYSE", "Financial", "STOCK", 20.0, 0.5, "AVAILABLE"),
        StockSearchResult("MISS", "Missing", "NYSE", "Technology", "STOCK", null, null, "UNAVAILABLE"),
    )

    @Test fun priceHighLowKeepsMissingLast() {
        assertEquals(listOf("BBB", "CCC", "AAA", "MISS"), applyCatalogFiltersAndSort(rows, sort = CatalogSort.PRICE_HIGH_LOW).map { it.ticker })
    }

    @Test fun priceLowHighKeepsMissingLast() {
        assertEquals(listOf("AAA", "CCC", "BBB", "MISS"), applyCatalogFiltersAndSort(rows, sort = CatalogSort.PRICE_LOW_HIGH).map { it.ticker })
    }

    @Test fun filtersComposeWithPriceSort() {
        assertEquals(
            listOf("AAA", "MISS"),
            applyCatalogFiltersAndSort(rows, exchange = "NYSE", sector = "Technology", sort = CatalogSort.PRICE_LOW_HIGH).map { it.ticker }
        )
    }
}
