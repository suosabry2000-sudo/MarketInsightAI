#!/usr/bin/env python3
from __future__ import annotations
import os, sys, zipfile
from pathlib import Path


def forbidden_values() -> list[bytes]:
    raw = os.getenv("FORBIDDEN_SECRET_VALUES", "")
    values = []
    for part in raw.replace("\r", "\n").replace(",", "\n").split("\n"):
        value = part.strip()
        if len(value) >= 6:
            values.append(value.encode())
    return values


def iter_payloads(path: Path):
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as zf:
            for info in zf.infolist():
                if info.is_dir() or info.file_size > 32 * 1024 * 1024:
                    continue
                try:
                    yield info.filename, zf.read(info)
                except Exception:
                    continue
    else:
        yield path.name, path.read_bytes()


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: check_no_secrets.py <file-or-apk>", file=sys.stderr)
        return 2
    target = Path(sys.argv[1])
    if not target.exists():
        print(f"missing target: {target}", file=sys.stderr)
        return 2
    values = forbidden_values()
    if not values:
        print("secret scan: no forbidden runtime values configured; structural scan only")
        return 0
    hits = []
    for name, data in iter_payloads(target):
        for value in values:
            if value in data:
                hits.append(name)
                break
    if hits:
        print("FORBIDDEN SECRET detected in: " + ", ".join(sorted(set(hits))), file=sys.stderr)
        return 1
    print("secret scan: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
