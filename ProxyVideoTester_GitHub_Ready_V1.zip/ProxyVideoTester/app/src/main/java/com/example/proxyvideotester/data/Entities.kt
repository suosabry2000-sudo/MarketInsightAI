package com.example.proxyvideotester.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "proxy_endpoints")
data class ProxyEndpointEntity(
    @PrimaryKey val id: String,
    val label: String?,
    val host: String,
    val port: Int,
    val type: String,
    val username: String?,
    val enabled: Boolean,
    val lastDetectedPublicIp: String?,
    val lastStatus: String?,
    val lastLatencyMs: Long?,
    val lastTestedAtEpochMs: Long?,
)

@Entity(tableName = "test_sessions")
data class TestSessionEntity(
    @PrimaryKey val id: String,
    val targetDisplay: String,
    val requestedWatchMs: Long,
    val startedAtEpochMs: Long,
    val finishedAtEpochMs: Long?,
)

@Entity(tableName = "endpoint_results")
data class EndpointResultEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val proxyId: String,
    val targetDisplay: String,
    val startedAtEpochMs: Long,
    val finishedAtEpochMs: Long,
    val requestedWatchMs: Long,
    val actualPlayingMs: Long,
    val wallClockMs: Long,
    val detectedPublicIp: String?,
    val connectLatencyMs: Long?,
    val timeToFirstPlaybackMs: Long?,
    val bufferingMs: Long,
    val bufferEventCount: Int,
    val status: String,
    val errorDetail: String?,
)
