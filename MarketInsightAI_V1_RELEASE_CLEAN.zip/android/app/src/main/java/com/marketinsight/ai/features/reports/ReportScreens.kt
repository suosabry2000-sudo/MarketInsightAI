package com.marketinsight.ai.features.reports

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.*
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*

enum class ReportKind(val title: String) {
    TECHNICAL("Technical"), FUNDAMENTALS("Fundamentals"), NEWS("News"), VERIFICATION("Source Verification"), ACCURACY("Model Accuracy")
}

@Composable
fun ReportScreen(kind: ReportKind, ticker: String, repository: MarketRepository) {
    var payload by remember(kind, ticker) { mutableStateOf<Any?>(null) }
    var offline by remember { mutableStateOf(false) }
    var demo by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(kind, ticker) {
        when (kind) {
            ReportKind.TECHNICAL -> repository.technical(ticker)
            ReportKind.FUNDAMENTALS -> repository.fundamentals(ticker)
            ReportKind.NEWS -> repository.news(ticker)
            ReportKind.VERIFICATION -> repository.verification(ticker)
            ReportKind.ACCURACY -> repository.accuracy(ticker)
        }.also { result -> payload = result.data; offline = result.isOffline; demo = result.isDemo; error = result.error }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("$ticker ${kind.title}", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
        item { StatusBanner(offline, demo, error) }
        if (payload == null) item { CircularProgressIndicator() }
        when (val p = payload) {
            is TechnicalReport -> item {
                SectionCard("Technical Score") {
                    MetricRow("Score", "%.0f / 100".format(p.score))
                    MetricRow("Completeness", "%.0f%%".format(p.completeness * 100))
                    listOf("RSI", "MACD", "EMA", "SMA", "VWAP", "Bollinger", "ATR", "ADX", "Volume", "Momentum", "Support / Resistance").forEach { name ->
                        val found = p.indicators.entries.firstOrNull { it.key.contains(name.substringBefore(' '), true) }
                        MetricRow(name, found?.value?.let { "%.3f".format(it) } ?: "—")
                    }
                }
            }
            is FundamentalReport -> item {
                SectionCard("Fundamentals") {
                    MetricRow("Score", "%.0f / 100".format(p.score))
                    MetricRow("Category", p.category)
                    MetricRow("Source", p.source.ifBlank { "Unavailable" })
                    listOf("Revenue", "EPS", "Margins", "Free Cash Flow", "Cash", "Debt", "P/E", "Forward P/E", "PEG", "P/S", "Dividend", "Buybacks").forEach { label ->
                        val found = p.metrics.entries.firstOrNull { it.key.contains(label.substringBefore(' '), true) }
                        MetricRow(label, found?.value?.let { "%.3f".format(it) } ?: "—")
                    }
                }
            }
            is NewsReport -> {
                item {
                    SectionCard("News Sentiment") {
                        MetricRow("Positive", "%.0f%%".format(p.positivePct))
                        MetricRow("Neutral", "%.0f%%".format(p.neutralPct))
                        MetricRow("Negative", "%.0f%%".format(p.negativePct))
                        MetricRow("Sentiment Score", "%.2f".format(p.sentimentScore))
                    }
                }
                item {
                    SectionCard("News") {
                        if (p.events.isEmpty()) Text("No verified recent articles available.")
                        p.events.take(15).forEach { event ->
                            Text(event.headline, fontWeight = FontWeight.Bold)
                            Text("${event.publisher} • sentiment ${"%.2f".format(event.sentiment)} • importance ${"%.2f".format(event.importance)}", style = MaterialTheme.typography.bodySmall)
                            Divider()
                        }
                    }
                }
            }
            is VerificationReport -> item {
                SectionCard("Source Verification") {
                    MetricRow("Provider", p.provider)
                    MetricRow("Feed", p.feedLabel)
                    MetricRow("Scope", p.feedScope)
                    MetricRow("Consolidated", if (p.consolidated) "YES" else "NO")
                    MetricRow("Source Agreement", "%.0f%%".format(p.sourceAgreement))
                    MetricRow("Freshness", "%.0f sec".format(p.freshnessSeconds))
                    MetricRow("Completeness", "%.0f%%".format(p.completeness * 100))
                    QualityBadge(p.dataQuality)
                    p.reasons.forEach { Text("• $it") }
                }
            }
            is AccuracyReport -> item {
                SectionCard("Model Accuracy") {
                    Text("Historical performance does not guarantee future results.", style = MaterialTheme.typography.bodySmall)
                    MetricRow("7-day Direction", "%.1f%%".format(p.direction7))
                    MetricRow("30-day Direction", "%.1f%%".format(p.direction30))
                    MetricRow("90-day Direction", "%.1f%%".format(p.direction90))
                    MetricRow("Average Target Error", "%.2f%%".format(p.averageError))
                    MetricRow("Median Target Error", "%.2f%%".format(p.medianError))
                    MetricRow("Range Capture", "%.1f%%".format(p.rangeCapture))
                    MetricRow("High-confidence Accuracy", "%.1f%%".format(p.highConfidenceAccuracy))
                    MetricRow("Samples", p.sampleCount.toString())
                }
            }
        }
    }
}
