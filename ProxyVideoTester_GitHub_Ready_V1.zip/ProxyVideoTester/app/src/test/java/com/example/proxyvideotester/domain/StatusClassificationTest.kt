package com.example.proxyvideotester.domain

import org.junit.Assert.assertEquals
import org.junit.Test

class StatusClassificationTest {
    @Test fun passRequiresVerifiedIpAndRequestedPlayback() {
        assertEquals(
            TestStatus.PASSED,
            ResultClassifier.classify(
                AttemptFacts(true, true, true, 60_000, 60_000)
            )
        )
    }

    @Test fun insufficientPlaybackAfterTimeoutIsTimeout() {
        assertEquals(
            TestStatus.PLAYBACK_TIMEOUT,
            ResultClassifier.classify(
                AttemptFacts(true, true, true, 59_999, 60_000, timedOut = true)
            )
        )
    }

    @Test fun unreachableProxyWinsBeforeIpVerification() {
        assertEquals(
            TestStatus.PROXY_UNREACHABLE,
            ResultClassifier.classify(
                AttemptFacts(false, false, false, 0, 60_000)
            )
        )
    }
}
