package com.example.proxyvideotester.domain

import java.net.URI

sealed interface ParseResult {
    data class Valid(val endpoint: ProxyEndpoint, val sourceLine: String) : ParseResult
    data class Invalid(val sourceLine: String, val reason: String) : ParseResult
}

object EndpointParser {
    fun parseLine(rawLine: String): ParseResult {
        val line = rawLine.trim()
        if (line.isBlank()) return ParseResult.Invalid(rawLine, "Endpoint is blank")

        val normalized = when {
            line.contains("://") -> line
            else -> "http://$line"
        }

        return try {
            val uri = URI(normalized)
            val scheme = uri.scheme?.lowercase()
            val type = when (scheme) {
                "http" -> ProxyType.HTTP
                "socks5" -> ProxyType.SOCKS5
                else -> return ParseResult.Invalid(rawLine, "Unsupported proxy scheme: ${scheme ?: "missing"}")
            }
            val host = uri.host?.takeIf { it.isNotBlank() }
                ?: return ParseResult.Invalid(rawLine, "Proxy host is missing")
            val port = uri.port
            if (port !in 1..65535) {
                return ParseResult.Invalid(rawLine, "Proxy port must be between 1 and 65535")
            }

            val userInfo = uri.userInfo
            val credentials = userInfo?.split(":", limit = 2)
            val username = credentials?.getOrNull(0)?.takeIf { it.isNotBlank() }
            val password = credentials?.getOrNull(1)

            ParseResult.Valid(
                endpoint = ProxyEndpoint(
                    host = host,
                    port = port,
                    type = type,
                    username = username,
                    password = password,
                ),
                sourceLine = rawLine,
            )
        } catch (error: Exception) {
            ParseResult.Invalid(rawLine, error.message ?: "Malformed endpoint")
        }
    }

    fun parseMultiline(text: String): List<ParseResult> = text
        .lineSequence()
        .filter { it.isNotBlank() }
        .map(::parseLine)
        .toList()

    fun preflightError(endpoint: ProxyEndpoint): String? {
        if (endpoint.type == ProxyType.SOCKS5 && !endpoint.username.isNullOrBlank()) {
            return "Authenticated SOCKS5 is not supported in V1"
        }
        return null
    }
}
