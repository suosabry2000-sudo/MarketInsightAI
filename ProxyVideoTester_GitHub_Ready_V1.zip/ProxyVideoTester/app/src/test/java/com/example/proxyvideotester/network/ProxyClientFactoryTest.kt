package com.example.proxyvideotester.network

import com.example.proxyvideotester.domain.ProxyEndpoint
import com.example.proxyvideotester.domain.ProxyType
import java.net.Proxy
import org.junit.Assert.assertEquals
import org.junit.Test

class ProxyClientFactoryTest {
    @Test fun httpEndpointCreatesHttpProxy() {
        val client = ProxyClientFactory.create(
            ProxyEndpoint(host = "127.0.0.1", port = 8080, type = ProxyType.HTTP),
            5_000,
        )
        assertEquals(Proxy.Type.HTTP, client.proxy?.type())
    }

    @Test(expected = IllegalArgumentException::class)
    fun authenticatedSocksIsRejectedInV1() {
        ProxyClientFactory.create(
                ProxyEndpoint(
                    host = "127.0.0.1",
                    port = 1080,
                    type = ProxyType.SOCKS5,
                    username = "u",
                    password = "p",
                ),
                5_000,
            )
    }
}
