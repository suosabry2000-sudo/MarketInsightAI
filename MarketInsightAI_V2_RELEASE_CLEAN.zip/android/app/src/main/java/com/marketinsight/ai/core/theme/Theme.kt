package com.marketinsight.ai.core.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Accent = Color(0xFF00D45A)
private val Light = lightColorScheme(
    primary = Color(0xFF00B84C),
    secondary = Color(0xFF0A7D38),
    background = Color(0xFFF6F8F7),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEEF2F0),
    outline = Color(0xFFD7DDDA),
    onPrimary = Color(0xFF06140B),
    onBackground = Color(0xFF101412),
    onSurface = Color(0xFF101412),
    onSurfaceVariant = Color(0xFF59625E),
)
private val Dark = darkColorScheme(
    primary = Color(0xFF35E875),
    secondary = Color(0xFF8AF0A9),
    background = Color(0xFF090B0C),
    surface = Color(0xFF111416),
    surfaceVariant = Color(0xFF1A1E20),
    outline = Color(0xFF353C3F),
    onPrimary = Color(0xFF031109),
    onBackground = Color(0xFFF3F7F5),
    onSurface = Color(0xFFF3F7F5),
    onSurfaceVariant = Color(0xFFB9C2BE),
)

@Composable
fun MarketInsightTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
