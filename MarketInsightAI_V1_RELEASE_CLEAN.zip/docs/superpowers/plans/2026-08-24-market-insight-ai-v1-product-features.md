# Market Insight AI V1 Android Product Features Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Expand the validated vertical slice into the complete V1 Android experience: Home, Markets, stock search/detail, forecasts, Monday→Friday scanner, technical/fundamental/news/verification/accuracy screens, watchlist, settings, offline cache, and alerts.

**Architecture:** Feature-focused Compose packages consume repository interfaces that hide Retrofit/Room details. Cached data is shown first with explicit freshness state, then refreshed from backend. Scanner sort/filter runs locally on the latest precomputed server response where practical.

**Tech Stack:** Kotlin, Jetpack Compose, Material 3, Navigation Compose, MVVM, Retrofit/OkHttp, Room, Coroutines/Flow, WorkManager, Firebase Cloud Messaging.

**Spec:** `docs/superpowers/specs/2026-08-24-market-insight-ai-v1-design.md`

## Global Constraints

- Bottom navigation: Home, Markets, Forecasts, Watchlist, Profile.
- Theme choices: System, Light, Dark.
- Home includes a prominent `MON → FRI STOCK LIST` action.
- Cached/offline values must never be represented as live.
- Every forecast view shows uncertainty, confidence, risk, and data-quality state.
- Scanner filters and sorts must match the approved spec exactly.
- U.S. equities only in V1.

---

## File Structure Locked by This Plan

- `android/app/src/main/java/com/marketinsight/ai/navigation/AppNav.kt` — bottom navigation/routes.
- `.../data/repository/MarketRepository.kt` — single client data boundary.
- `.../core/database/AppDatabase.kt` — Room database.
- `.../core/database/Entities.kt` — cached stock/forecast/watchlist/settings entities.
- `.../features/home/*` — dashboard.
- `.../features/markets/*` — market lists.
- `.../features/search/*` — stock search.
- `.../features/stockdetails/*` — detail + chart.
- `.../features/forecast/*` — tomorrow/weekly forecast and explanation.
- `.../features/weeklyscanner/*` — full scanner/filter/sort.
- `.../features/technical/*`, `fundamentals/*`, `news/*`, `verification/*`, `accuracy/*` — report tabs/screens.
- `.../features/watchlist/*` — watchlist.
- `.../features/settings/*` — theme/chart/forecast/notification preferences.
- `.../features/alerts/*` — local alert preferences + push token registration.

---

### Task 1: Navigation Shell

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/navigation/AppNav.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/navigation/NavigationTest.kt`
- Modify: `android/app/src/main/java/com/marketinsight/ai/MainActivity.kt`

**Interfaces:**
- Produces routes: `home`, `markets`, `forecasts`, `watchlist`, `profile`, `stock/{ticker}`, `scanner`, `technical/{ticker}`, `fundamentals/{ticker}`, `news/{ticker}`, `verification/{ticker}`, `accuracy/{ticker}`.

- [ ] **Step 1: Write navigation test**

Assert all five bottom destinations are present and tapping Markets/Watchlist changes visible screen semantics.

- [ ] **Step 2: Run and confirm failure**

Run: `cd android && ./gradlew connectedDebugAndroidTest -Pandroid.testInstrumentationRunnerArguments.class=com.marketinsight.ai.navigation.NavigationTest`

- [ ] **Step 3: Implement Navigation Compose host**

Bottom bar remains visible only on primary destinations; detail/report routes get back navigation.

- [ ] **Step 4: Run test**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add android
git commit -m "feat: add app navigation shell"
```

---

### Task 2: Repository and Room Cache

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/data/repository/MarketRepository.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/core/database/AppDatabase.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/core/database/Entities.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/core/database/Daos.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/data/repository/MarketRepositoryTest.kt`

**Interfaces:**
- Produces flows: `observeStock`, `observeForecast`, `observeScanner`, `observeWatchlist`.
- Produces refresh methods that write backend responses with `cachedAt` and source timestamps.

- [ ] **Step 1: Write cache-first behavior tests**

Assert cached content emits immediately, network refresh replaces it, network failure leaves cached content but sets `isOffline=true`, and cached data never returns `isLive=true`.

- [ ] **Step 2: Run and confirm failure**

Run: `cd android && ./gradlew testDebugUnitTest --tests '*MarketRepositoryTest*'`

- [ ] **Step 3: Implement Room entities/DAOs and repository**

Persist quote/chart summary, latest forecast, scanner snapshot, watchlist, and settings. Full raw intraday retention is bounded by a cleanup policy to avoid unbounded phone storage.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/data android/app/src/main/java/com/marketinsight/ai/core/database android/app/src/test
git commit -m "feat: add offline aware market repository"
```

---

### Task 3: Home Dashboard

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/home/HomeViewModel.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/home/HomeScreen.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/home/HomeScreenTest.kt`

**Interfaces:**
- Consumes `GET /markets/overview` and watchlist/scanner summaries.

- [ ] **Step 1: Write UI test for required sections**

Assert Search, S&P 500, Nasdaq, Dow, market status, Top Gainers, Top Losers, Most Active, Watchlist, Strongest AI Signals, and `MON → FRI STOCK LIST` are visible or reachable by scroll.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement responsive dashboard**

The `MON → FRI STOCK LIST` button navigates to `scanner`. Market-session state is visually distinct but never inferred on-device when backend supplies it.

- [ ] **Step 4: Run Compose test**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/home android/app/src/androidTest
git commit -m "feat: build market home dashboard"
```

---

### Task 4: Stock Search

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/search/SearchViewModel.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/search/SearchScreen.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/search/SearchViewModelTest.kt`

**Interfaces:**
- Consumes: `GET /stocks/search?q=`.

- [ ] **Step 1: Write debounce/search tests**

Typing `app` must request once after 300ms debounce and render matching ticker/company results; blank query clears results without API call.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement search and navigation to stock detail**

Search supports ticker, company name, partial company name. Selecting a result opens `stock/{ticker}`.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/search android/app/src/test
git commit -m "feat: add us stock search"
```

---

### Task 5: Markets Screen

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/markets/MarketsViewModel.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/markets/MarketsScreen.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/markets/MarketsViewModelTest.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/markets/MarketsScreenTest.kt`

**Interfaces:**
- Consumes `GET /markets/overview` and scanner category metadata.
- Produces sections/categories: Top Gainers, Top Losers, Most Active, Mega Cap, Technology, Financial, Healthcare, Energy, Consumer, Industrials, AI Stocks, Semiconductors.

- [ ] **Step 1: Write category and navigation tests**

Assert the required categories render from deterministic market fixtures and tapping a stock opens `stock/{ticker}`.

- [ ] **Step 2: Run and confirm failure**

Run: `cd android && ./gradlew testDebugUnitTest --tests '*MarketsViewModelTest*'`

- [ ] **Step 3: Implement Markets screen**

Use cached market overview first, then refresh. Category rows must carry explicit data timestamps so cached market lists cannot appear live.

- [ ] **Step 4: Run unit/UI tests**

Run: `cd android && ./gradlew testDebugUnitTest connectedDebugAndroidTest`

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/markets android/app/src/test android/app/src/androidTest
git commit -m "feat: add us markets discovery screen"
```

---

### Task 6: Full Stock Details and Chart Modes

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/stockdetails/StockDetailsScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/stockdetails/StockDetailsViewModel.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/charts/PriceChart.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/stockdetails/StockDetailsTest.kt`

**Interfaces:**
- Consumes quote, stock metadata, and chart APIs.

- [ ] **Step 1: Write required-metrics/range-selector test**

Verify 1D/1W/1M/3M/6M/1Y/5Y/MAX, line/candlestick selector, volume section, open/high/low/previous close/market cap/volume/average volume/52-week high-low.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement details and chart rendering**

Chart interaction must remain usable at 320dp width; live updates are throttled in ViewModel before Compose state emission.

- [ ] **Step 4: Run UI tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/stockdetails android/app/src/main/java/com/marketinsight/ai/features/charts android/app/src/androidTest
git commit -m "feat: add full stock detail and charts"
```

---

### Task 7: Forecast and Explanation Screens

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/forecast/ForecastScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/forecast/ForecastViewModel.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/forecast/ForecastScreenTest.kt`

**Interfaces:**
- Consumes forecast API including tomorrow OHLC expectations, daily weekly rows, bear/base/bull, probabilities, confidence, risk, explanation.

- [ ] **Step 1: Write forecast semantics test**

Assert `Confidence` and `Bull probability` are shown as separate labels and base target is never labeled guaranteed/expected certainty.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement forecast cards and “Why this forecast?” section**

Warnings for earnings/event risk, LIMITED, STALE, DATA CONFLICT, and NO RELIABLE FORECAST must be explicit.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/forecast android/app/src/androidTest
git commit -m "feat: add transparent forecast report"
```

---

### Task 8: Full Monday → Friday Scanner

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/weeklyscanner/WeeklyScannerViewModel.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/weeklyscanner/WeeklyScannerScreen.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/weeklyscanner/WeeklyScannerViewModelTest.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/weeklyscanner/WeeklyScannerScreenTest.kt`

**Interfaces:**
- Consumes `GET /scanner/weekly` precomputed response.
- Supports all filters and sorts in spec.

- [ ] **Step 1: Write filter/sort tests**

Use a fixed list to verify All U.S., S&P 500, Nasdaq, Dow, Technology, AI, Semiconductors, Mega Cap, Most Active, Watchlist; verify nine approved sort modes including highest drop and ticker A–Z.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement scanner screen**

Each card shows first-session reference, live price, final-session bear/base/bull, expected move from reference and live, bull/bear probabilities, confidence, risk, opportunity score, signal, data quality. Tapping opens full stock analysis.

- [ ] **Step 4: Run unit/UI tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/weeklyscanner android/app/src/test android/app/src/androidTest
git commit -m "feat: build full monday friday scanner"
```

---

### Task 9: Technical/Fundamental/News/Verification Report Screens

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/technical/TechnicalScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/fundamentals/FundamentalsScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/news/NewsScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/verification/VerificationScreen.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/reports/ReportScreensTest.kt`

**Interfaces:**
- Consumes technical/fundamental/news/verification backend endpoints.

- [ ] **Step 1: Write report-field presence tests**

Assert technical indicators from spec, fundamental metrics + category labels, news sentiment split/article metadata, and source verification/freshness states are all represented.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement four focused report screens**

Do not duplicate calculation logic on Android; display backend evidence only.

- [ ] **Step 4: Run UI tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/technical android/app/src/main/java/com/marketinsight/ai/features/fundamentals android/app/src/main/java/com/marketinsight/ai/features/news android/app/src/main/java/com/marketinsight/ai/features/verification android/app/src/androidTest
git commit -m "feat: add analysis evidence screens"
```

---

### Task 10: Model Accuracy Screen

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/accuracy/AccuracyScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/accuracy/AccuracyViewModel.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/accuracy/AccuracyScreenTest.kt`

**Interfaces:**
- Consumes `GET /accuracy/{ticker}`.

- [ ] **Step 1: Write metrics-display test**

Assert 7/30/90-day directional accuracy, average/median target error, range capture, high-confidence accuracy, per-stock performance, and historical prediction vs actual.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement accuracy screen**

Clearly distinguish historical performance from future guarantees.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/accuracy android/app/src/androidTest
git commit -m "feat: show model performance history"
```

---

### Task 11: Watchlist

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/watchlist/WatchlistViewModel.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/watchlist/WatchlistScreen.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/watchlist/WatchlistTest.kt`

**Interfaces:**
- Consumes `POST /watchlist`, `DELETE /watchlist/{ticker}` and local cache.

- [ ] **Step 1: Write add/remove/offline queue tests**

Assert local UI updates immediately and failed sync is retained as pending without losing the user's local watchlist choice.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement watchlist and star action on stock detail**

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/watchlist android/app/src/test
git commit -m "feat: add persistent watchlist"
```

---

### Task 12: Settings and Theme Persistence

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/settings/SettingsScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/settings/SettingsRepository.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/settings/SettingsTest.kt`

**Interfaces:**
- Persists theme, default chart type, default forecast period, notification settings, confidence threshold, minimum expected move, data refresh preference.

- [ ] **Step 1: Write persistence tests**

Set Dark, recreate repository, assert Dark remains; repeat for chart/forecast and thresholds.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement settings using DataStore**

Privacy/About/Prediction disclaimer entries are static informational screens.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/settings android/app/src/test
git commit -m "feat: persist user market preferences"
```

---

### Task 13: Offline/Stale UX Regression

**Files:**
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/offline/OfflineBehaviorTest.kt`
- Modify: relevant screens to use shared freshness components.

**Interfaces:**
- Produces shared `FreshnessBadge` and `OfflineBanner`.

- [ ] **Step 1: Write instrumentation scenarios**

Force repository offline with cached data. Assert `OFFLINE`, last-updated timestamp, no `LIVE` badge, cached chart/forecast/watchlist visible. Force stale-but-online response and assert `STALE` label.

- [ ] **Step 2: Run and confirm any failures**

- [ ] **Step 3: Centralize freshness presentation**

Every quote/forecast/scanner surface must use the same freshness mapping.

- [ ] **Step 4: Run all Android tests**

Run: `cd android && ./gradlew testDebugUnitTest connectedDebugAndroidTest`

- [ ] **Step 5: Commit**

```bash
git add android
git commit -m "test: enforce offline and stale labeling"
```

---

### Task 14: Alert Preferences and Push Token Registration

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/alerts/AlertsScreen.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/alerts/PushTokenManager.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/alerts/AlertsTest.kt`

**Interfaces:**
- Supports price above/below, signal change, confidence threshold, weekly opportunity, breaking news, earnings approaching.

- [ ] **Step 1: Write preference payload tests**

Assert each alert category serializes correctly with minimum confidence and expected move thresholds.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement FCM token capture and backend registration interface**

No notification is generated locally from stale market data; push payload must carry server timestamp and alert type.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/alerts android/app/src/test
git commit -m "feat: add market alert preferences"
```

---

### Task 15: Product Feature Regression Build

**Files:**
- Modify: `README.md`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/V1UserJourneyTest.kt`

**Interfaces:**
- Verifies core success path from Home -> Scanner -> Stock -> Forecast -> Evidence -> Watchlist.

- [ ] **Step 1: Write V1 user journey instrumentation test**

Use deterministic backend/stub responses and assert navigation plus freshness/uncertainty labels.

- [ ] **Step 2: Run complete Android test suite**

Run: `cd android && ./gradlew testDebugUnitTest connectedDebugAndroidTest`

Expected: PASS.

- [ ] **Step 3: Build debug APK**

Run: `cd android && ./gradlew clean assembleDebug`

Expected: `android/app/build/outputs/apk/debug/app-debug.apk`.

- [ ] **Step 4: Update README with exact debug install command**

```bash
adb install -r android/app/build/outputs/apk/debug/app-debug.apk
```

- [ ] **Step 5: Commit**

```bash
git add android README.md
git commit -m "test: verify v1 android user journey"
```

