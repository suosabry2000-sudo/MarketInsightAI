# Market Insight AI V2 Market Universe Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a large paged U.S. market universe with backend-enriched prices and client-side filters/sorts including Price High→Low and Low→High.

**Architecture:** Extend the market provider with an optional bulk-quote interface, enrich catalog pages on the backend, and expose typed rows to Android. Android keeps only the current catalog page plus local filters/sort state and never requests one quote per row.

**Tech Stack:** Python 3.13, FastAPI, httpx, Kotlin 2.0.21, Jetpack Compose, OkHttp, Material 3.

**Spec:** `docs/superpowers/specs/2026-08-25-market-insight-ai-v2-design.md`

## Global Constraints
- Public Yahoo data must remain labeled LIMITED/delayed.
- Unknown prices sort last.
- Catalog endpoints must preserve pagination and tolerate upstream quote failures.
- Do not claim exact Robinhood availability without authoritative tradability evidence.

---

### Task 1: Enriched catalog model and sorting API

**Files:**
- Modify: `backend/app/api/stocks.py`
- Modify: `backend/app/market_data/provider.py`
- Modify: `backend/app/market_data/yahoo_provider.py`
- Test: `backend/tests/api/test_api.py`
- Test: `backend/tests/market_data/test_public_provider.py`

**Interfaces:**
- Produces: `GET /stocks/catalog?offset=&limit=&sort=&direction=&q=&exchange=&sector=` returning rows with `ticker`, `company`, `exchange`, `sector`, `asset_type`, `price`, `change_pct`, `price_status`.
- Produces optional provider method `get_quotes(tickers: list[str]) -> dict[str, Quote]`.

- [ ] **Step 1: Write failing backend tests** for price-enriched rows, high/low sorting, unknown-price-last, and filter composition.
- [ ] **Step 2: Run targeted tests and confirm they fail** for missing enriched sorting behavior.
- [ ] **Step 3: Implement minimal bulk quote support** in Yahoo provider using bounded concurrency and existing `get_quote` behavior when batch transport is unavailable.
- [ ] **Step 4: Implement catalog enrichment/filter/sort** in `stocks.py`, preserving existing pagination metadata.
- [ ] **Step 5: Run targeted tests and full backend suite**.

### Task 2: Android catalog row model and sort logic

**Files:**
- Modify: `android/app/src/main/java/com/marketinsight/ai/core/model/Models.kt`
- Modify: `android/app/src/main/java/com/marketinsight/ai/core/network/MarketApi.kt`
- Modify: `android/app/src/main/java/com/marketinsight/ai/data/repository/MarketRepository.kt`
- Modify: `android/app/src/main/java/com/marketinsight/ai/features/markets/StockCatalogLogic.kt`
- Modify: `android/smoke/SmokeMain.kt`
- Test: `android/app/src/test/java/com/marketinsight/ai/features/markets/StockCatalogLogicTest.kt`

**Interfaces:**
- Produces: `CatalogStock` model with nullable price/change.
- Produces: `CatalogSort` enum and `applyCatalogFiltersAndSort(...)`.

- [ ] **Step 1: Write failing Kotlin tests** for Price High→Low, Price Low→High, unknown-price-last, query/exchange/sector composition.
- [ ] **Step 2: Run Kotlin smoke/unit checks and confirm failure**.
- [ ] **Step 3: Implement typed parsing/repository paging params**.
- [ ] **Step 4: Implement deterministic filters/sorts**.
- [ ] **Step 5: Run Kotlin smoke and Android unit tests**.

### Task 3: Markets pagination and UI controls

**Files:**
- Modify: `android/app/src/main/java/com/marketinsight/ai/features/markets/MarketsScreen.kt`

**Interfaces:**
- Consumes: enriched catalog rows and `CatalogSort`.
- Produces: filter chips, sort menu, lazy paged stock rows.

- [ ] **Step 1: Add source-contract assertions** for the required V2 controls.
- [ ] **Step 2: Confirm contract check fails** before UI change.
- [ ] **Step 3: Implement modern controls and row rendering**.
- [ ] **Step 4: Run Android contract + unit checks**.
