package com.marketinsight.ai.features.markets

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.MarketOverview
import com.marketinsight.ai.core.model.StockSearchResult
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*

@Composable
fun MarketsScreen(repository: MarketRepository, onOpenStock: (String) -> Unit, onOpenScanner: () -> Unit) {
    var state by remember { mutableStateOf<FetchResult<MarketOverview>?>(null) }
    var catalog by remember { mutableStateOf<FetchResult<List<StockSearchResult>>?>(null) }
    var query by remember { mutableStateOf("") }
    var exchange by remember { mutableStateOf("ALL") }

    LaunchedEffect(Unit) {
        state = repository.marketOverview()
        catalog = repository.catalog()
    }

    val allStocks = catalog?.data.orEmpty()
    val filtered = remember(allStocks, query, exchange) { filterStockCatalog(allStocks, query, exchange) }
    val exchanges = remember(allStocks) {
        listOf("ALL") + allStocks.map { it.exchange }.filter { it.isNotBlank() }.distinct().sorted()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item { Text("U.S. Markets", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
        item { StatusBanner(state?.isOffline == true || catalog?.isOffline == true, state?.isDemo == true || catalog?.isDemo == true, state?.error ?: catalog?.error) }
        item { SectionCard("Top Gainers") { state?.data?.topGainers.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } } } }
        item { SectionCard("Top Losers") { state?.data?.topLosers.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } } } }
        item { SectionCard("Most Active") { state?.data?.mostActive.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } } } }
        item {
            Button(onClick = onOpenScanner, modifier = Modifier.fillMaxWidth()) {
                Text("OPEN MON → FRI STOCK SCANNER", fontWeight = FontWeight.Bold)
            }
        }
        item {
            Text("All U.S. Stocks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Text(
                if (catalog?.isDemo == true) "${allStocks.size} built-in fallback stocks • full active U.S. catalog loads from the live backend"
                else "${allStocks.size} active stocks loaded",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Search thousands of stocks") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
            )
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(exchanges) { value ->
                    FilterChip(selected = exchange == value, onClick = { exchange = value }, label = { Text(value) })
                }
            }
        }
        item { Text("Showing ${filtered.size} of ${allStocks.size}", style = MaterialTheme.typography.labelMedium) }
        items(filtered, key = { it.ticker }) { stock ->
            Card(Modifier.fillMaxWidth().clickable { onOpenStock(stock.ticker) }) {
                Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(stock.ticker, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleMedium)
                        Text(stock.company, style = MaterialTheme.typography.bodyMedium)
                        stock.sector?.takeIf { it.isNotBlank() }?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    }
                    if (stock.exchange.isNotBlank()) AssistChip(onClick = {}, label = { Text(stock.exchange) })
                }
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
