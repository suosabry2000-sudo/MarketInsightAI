package com.example.proxyvideotester.data

import com.example.proxyvideotester.domain.EndpointTestResult
import com.example.proxyvideotester.domain.ProxyEndpoint
import com.example.proxyvideotester.domain.ProxyType
import com.example.proxyvideotester.domain.TestStatus
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TesterRepository(
    private val db: AppDatabase,
    private val credentials: CredentialStore,
) {
    fun observeEndpoints(): Flow<List<ProxyEndpoint>> = db.proxyDao().observeAll().map { rows ->
        rows.map(::toDomain)
    }

    suspend fun listEndpoints(): List<ProxyEndpoint> = db.proxyDao().listAll().map(::toDomain)

    suspend fun upsertEndpoint(endpoint: ProxyEndpoint) {
        db.proxyDao().upsert(endpoint.toEntity())
        credentials.savePassword(endpoint.id, endpoint.password)
    }

    suspend fun deleteEndpoint(id: String) {
        db.proxyDao().deleteById(id)
        credentials.delete(id)
    }

    suspend fun createSession(id: String, targetDisplay: String, requestedWatchMs: Long, startedAt: Long) {
        db.sessionDao().insert(TestSessionEntity(id, targetDisplay, requestedWatchMs, startedAt, null))
    }

    suspend fun finishSession(id: String, finishedAt: Long) = db.sessionDao().finish(id, finishedAt)

    suspend fun saveResult(result: EndpointTestResult) = db.resultDao().insert(result.toEntity())

    fun observeResults(): Flow<List<EndpointTestResult>> = db.resultDao().observeAll().map { rows ->
        rows.mapNotNull { it.toDomainOrNull() }
    }

    suspend fun clearResults() = db.resultDao().clearAll()

    private fun toDomain(row: ProxyEndpointEntity) = ProxyEndpoint(
        id = row.id,
        label = row.label,
        host = row.host,
        port = row.port,
        type = runCatching { ProxyType.valueOf(row.type) }.getOrDefault(ProxyType.HTTP),
        username = row.username,
        password = credentials.getPassword(row.id),
        enabled = row.enabled,
        lastDetectedPublicIp = row.lastDetectedPublicIp,
        lastStatus = row.lastStatus,
        lastLatencyMs = row.lastLatencyMs,
        lastTestedAtEpochMs = row.lastTestedAtEpochMs,
    )
}

private fun ProxyEndpoint.toEntity() = ProxyEndpointEntity(
    id = id,
    label = label,
    host = host,
    port = port,
    type = type.name,
    username = username,
    enabled = enabled,
    lastDetectedPublicIp = lastDetectedPublicIp,
    lastStatus = lastStatus,
    lastLatencyMs = lastLatencyMs,
    lastTestedAtEpochMs = lastTestedAtEpochMs,
)

private fun EndpointTestResult.toEntity() = EndpointResultEntity(
    id = id,
    sessionId = sessionId,
    proxyId = proxyId,
    targetDisplay = targetDisplay,
    startedAtEpochMs = startedAtEpochMs,
    finishedAtEpochMs = finishedAtEpochMs,
    requestedWatchMs = requestedWatchMs,
    actualPlayingMs = actualPlayingMs,
    wallClockMs = wallClockMs,
    detectedPublicIp = detectedPublicIp,
    connectLatencyMs = connectLatencyMs,
    timeToFirstPlaybackMs = timeToFirstPlaybackMs,
    bufferingMs = bufferingMs,
    bufferEventCount = bufferEventCount,
    status = status.name,
    errorDetail = errorDetail,
)

private fun EndpointResultEntity.toDomainOrNull(): EndpointTestResult? {
    val parsedStatus = runCatching { TestStatus.valueOf(status) }.getOrNull() ?: return null
    return EndpointTestResult(
        id = id,
        sessionId = sessionId,
        proxyId = proxyId,
        targetDisplay = targetDisplay,
        startedAtEpochMs = startedAtEpochMs,
        finishedAtEpochMs = finishedAtEpochMs,
        requestedWatchMs = requestedWatchMs,
        actualPlayingMs = actualPlayingMs,
        wallClockMs = wallClockMs,
        detectedPublicIp = detectedPublicIp,
        connectLatencyMs = connectLatencyMs,
        timeToFirstPlaybackMs = timeToFirstPlaybackMs,
        bufferingMs = bufferingMs,
        bufferEventCount = bufferEventCount,
        status = parsedStatus,
        errorDetail = errorDetail,
    )
}
