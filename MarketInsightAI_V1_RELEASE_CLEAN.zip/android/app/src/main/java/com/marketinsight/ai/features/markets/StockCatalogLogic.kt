package com.marketinsight.ai.features.markets

import com.marketinsight.ai.core.model.StockSearchResult

fun filterStockCatalog(
    stocks: List<StockSearchResult>,
    query: String,
    exchange: String? = null,
): List<StockSearchResult> {
    val needle = query.trim().lowercase()
    return stocks.asSequence()
        .filter { exchange.isNullOrBlank() || exchange.equals("ALL", true) || it.exchange.equals(exchange, true) }
        .filter {
            needle.isBlank() || it.ticker.lowercase().contains(needle) || it.company.lowercase().contains(needle)
        }
        .sortedWith(compareBy<StockSearchResult> { it.ticker })
        .toList()
}
