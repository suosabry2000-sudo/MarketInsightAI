package com.marketinsight.ai.core.network

import com.marketinsight.ai.BuildConfig
import com.marketinsight.ai.core.model.Quote
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

class QuoteSocket(
    private val client: OkHttpClient,
    private val wsBaseUrl: String = BuildConfig.WS_BASE_URL,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _quotes = MutableSharedFlow<Quote>(extraBufferCapacity = 32, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    val quotes: SharedFlow<Quote> = _quotes
    private var webSocket: WebSocket? = null
    private var tickers: List<String> = emptyList()
    private var retry = 0
    private val closed = AtomicBoolean(false)

    fun subscribe(symbols: List<String>) {
        tickers = symbols.map { it.uppercase() }.distinct().take(50)
        closed.set(false)
        webSocket?.close(1000, "resubscribe")
        connect()
    }

    private fun connect() {
        if (closed.get() || tickers.isEmpty()) return
        val url = wsBaseUrl.trimEnd('/') + "/ws/quotes"
        webSocket = client.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                retry = 0
                val array = tickers.joinToString(prefix = "[", postfix = "]") { "\"$it\"" }
                webSocket.send("{\"type\":\"subscribe\",\"tickers\":$array}")
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                runCatching { MarketApi.parseQuote(JSONObject(text)) }.onSuccess { _quotes.tryEmit(it) }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) = reconnect()
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { if (!closed.get()) reconnect() }
        })
    }

    private fun reconnect() {
        if (closed.get()) return
        val delayMs = min(30_000L, 1_000L * (1 shl min(retry++, 5)))
        scope.launch { delay(delayMs); connect() }
    }

    fun close() {
        closed.set(true)
        webSocket?.close(1000, "lifecycle end")
        webSocket = null
        scope.cancel()
    }
}
