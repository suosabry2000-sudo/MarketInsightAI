package com.marketinsight.ai.security

import com.marketinsight.ai.BuildConfig
import org.junit.Assert.assertFalse
import org.junit.Test

class NoSecretsTest {
    @Test fun build_config_does_not_contain_market_provider_credentials() {
        val values = listOf(BuildConfig.API_BASE_URL, BuildConfig.WS_BASE_URL).joinToString(" ").uppercase()
        listOf("APCA_API_SECRET_KEY", "APCA_API_KEY_ID", "FRED_API_KEY", "TOKEN_SECRET", "DATABASE_URL").forEach {
            assertFalse(values.contains(it))
        }
    }
}
