# GitHub Setup — One Repository

This folder is already arranged as one complete GitHub Android repository.

## Fast setup

1. Create a new empty GitHub repository, for example `ProxyVideoTester`.
2. Upload **all files and folders from this project** to the repository root, including the hidden `.github` folder.
3. Open the repository's **Actions** tab and run/open **Android CI**.
4. When the workflow finishes, open the build run → **Artifacts** → download `proxy-video-tester-debug-apk`.

The workflow installs JDK 17, Android SDK 35 and Gradle 8.9 automatically, then runs:

```text
gradle test
gradle lint
gradle assembleDebug
```

The resulting APK is `app-debug.apk` inside the downloaded Actions artifact.

## Repository layout

```text
.github/workflows/android.yml   GitHub APK build automation
app/                            Android application
app/src/main/                   Production Kotlin/Compose code
app/src/test/                   JVM unit tests
app/src/androidTest/            Android/Compose/Room tests
docs/superpowers/specs/         Approved design
docs/superpowers/plans/         Implementation plan
tools/selftest/                 Pure Kotlin local verification tests
README.md                       Usage and scope
```

## Safety scope

The application is a proxy/network and authorized media playback QA tool. It does not implement public-platform view inflation, browser fingerprint spoofing, captcha bypass, account automation, or ad interaction automation.
