package com.example.proxyvideotester.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun ProxyVideoTesterApp(viewModel: MainViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsState()
    val player by viewModel.currentPlayer.collectAsState()

    MaterialTheme {
        Surface {
            Scaffold(
                bottomBar = {
                    NavigationBar {
                        listOf(
                            AppScreen.DASHBOARD to "Home",
                            AppScreen.PROXIES to "Proxies",
                            AppScreen.LIVE to "Live",
                            AppScreen.RESULTS to "Results",
                            AppScreen.SETTINGS to "Settings",
                        ).forEach { (screen, label) ->
                            NavigationBarItem(
                                selected = state.screen == screen,
                                onClick = { viewModel.setScreen(screen) },
                                icon = { Text(label.take(1)) },
                                label = { Text(label) },
                            )
                        }
                    }
                }
            ) { padding ->
                Surface(modifier = Modifier.padding(padding)) {
                    when (state.screen) {
                        AppScreen.DASHBOARD -> DashboardScreen(
                            state = state,
                            onMediaUrlChange = viewModel::setMediaUrl,
                            onDurationChange = viewModel::setDurationText,
                            onStart = viewModel::startTest,
                            onStop = viewModel::stopTest,
                        )
                        AppScreen.PROXIES -> ProxyListScreen(
                            state = state,
                            onImportTextChange = viewModel::setImportText,
                            onImport = viewModel::importEndpoints,
                            onToggle = viewModel::setEndpointEnabled,
                            onDelete = viewModel::deleteEndpoint,
                            onTestOne = viewModel::testOneEndpoint,
                        )
                        AppScreen.LIVE -> LiveTestScreen(state, player, viewModel::stopTest)
                        AppScreen.RESULTS -> ResultsScreen(
                            state = state,
                            onExportCsv = viewModel::exportCsv,
                            onExportJson = viewModel::exportJson,
                            onClear = viewModel::clearResults,
                        )
                        AppScreen.SETTINGS -> SettingsScreen(state, viewModel::updateSettings, viewModel::saveSettings)
                    }
                }
            }
        }
    }
}
