#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIST="$ROOT/dist"
mkdir -p "$DIST"

echo "[1/7] Backend tests"
(cd "$ROOT/backend" && python -m pytest -q)

echo "[2/7] Kotlin smoke checks"
"$ROOT/scripts/kotlin_smoke_test.sh"

echo "[3/7] Android source contract"
python "$ROOT/scripts/check_android_contract.py"

echo "[4/7] Android unit tests and APK build"
(cd "$ROOT/android" && ./gradlew testDebugUnitTest assembleDebug assembleRelease)

DEBUG_APK="$ROOT/android/app/build/outputs/apk/debug/app-debug.apk"
RELEASE_APK="$ROOT/android/app/build/outputs/apk/release/app-release.apk"
[[ -s "$DEBUG_APK" ]] || { echo "missing debug APK" >&2; exit 1; }
[[ -s "$RELEASE_APK" ]] || { echo "missing release APK" >&2; exit 1; }

echo "[5/7] Signature verification"
if command -v apksigner >/dev/null 2>&1; then
  apksigner verify --verbose "$RELEASE_APK"
else
  APKSIGNER="$(find "${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/opt/android-sdk}}/build-tools" -type f -name apksigner 2>/dev/null | sort -V | tail -1)"
  [[ -n "$APKSIGNER" ]] || { echo "apksigner not found" >&2; exit 1; }
  "$APKSIGNER" verify --verbose "$RELEASE_APK"
fi

echo "[6/7] APK secret scan"
python "$ROOT/scripts/check_no_secrets.py" "$RELEASE_APK"

echo "[7/7] Final artifacts + checksums"
cp "$DEBUG_APK" "$DIST/MarketInsightAI-debug.apk"
cp "$RELEASE_APK" "$DIST/MarketInsightAI-v2.0.apk"
(
  cd "$DIST"
  sha256sum MarketInsightAI-debug.apk MarketInsightAI-v2.0.apk > SHA256SUMS.txt
)
echo "Release verification PASS"
