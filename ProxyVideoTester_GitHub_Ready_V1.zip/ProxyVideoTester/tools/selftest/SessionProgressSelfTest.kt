import com.example.proxyvideotester.domain.SessionProgress
import com.example.proxyvideotester.domain.TestStatus

fun main() {
    val p = SessionProgress(total = 3)
    check(p.remaining == 3)
    p.record(TestStatus.PASSED)
    check(p.passed == 1 && p.failed == 0 && p.remaining == 2)
    p.record(TestStatus.IP_VERIFY_FAILED)
    check(p.passed == 1 && p.failed == 1 && p.remaining == 1)
    p.record(TestStatus.USER_CANCELLED)
    check(p.passed == 1 && p.failed == 2 && p.remaining == 0)
}
