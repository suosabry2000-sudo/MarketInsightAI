package com.example.proxyvideotester.domain

import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class IpCheckOutcome(
    val reachable: Boolean,
    val verified: Boolean,
    val ip: String? = null,
    val latencyMs: Long? = null,
    val error: String? = null,
    val retryable: Boolean = false,
)

data class PlaybackOutcome(
    val mediaPrepared: Boolean,
    val actualPlayingMs: Long,
    val wallClockMs: Long,
    val timeToFirstPlaybackMs: Long?,
    val bufferingMs: Long,
    val bufferEventCount: Int,
    val playbackFailed: Boolean = false,
    val timedOut: Boolean = false,
    val cancelled: Boolean = false,
    val errorDetail: String? = null,
)

fun interface IpCheckPort {
    suspend fun verify(endpoint: ProxyEndpoint): IpCheckOutcome
}

fun interface PlaybackPort {
    suspend fun play(
        endpoint: ProxyEndpoint,
        mediaUrl: String,
        requestedPlayingMs: Long,
        shouldStop: () -> Boolean,
    ): PlaybackOutcome
}

data class TestSessionRequest(
    val sessionId: String = UUID.randomUUID().toString(),
    val mediaUrl: String,
    val targetDisplay: String,
    val requestedPlayingMs: Long,
    val endpoints: List<ProxyEndpoint>,
)

class SessionProgress(val total: Int) {
    var passed: Int = 0
        private set
    var failed: Int = 0
        private set
    var remaining: Int = total
        private set

    fun record(status: TestStatus) {
        if (status == TestStatus.PASSED) passed += 1 else failed += 1
        remaining = (remaining - 1).coerceAtLeast(0)
    }
}

class TestSessionEngine(
    private val ipCheck: IpCheckPort,
    private val playback: PlaybackPort,
    private val nowEpochMs: () -> Long = { System.currentTimeMillis() },
) {
    private val stopRequested = AtomicBoolean(false)
    private val _state = MutableStateFlow(
        SessionSummary(
            sessionId = "",
            total = 0,
            passed = 0,
            failed = 0,
            remaining = 0,
            running = false,
        )
    )
    val state: StateFlow<SessionSummary> = _state.asStateFlow()

    fun requestStop() {
        stopRequested.set(true)
    }

    suspend fun run(
        request: TestSessionRequest,
        onResult: suspend (EndpointTestResult) -> Unit = {},
    ): List<EndpointTestResult> {
        require(request.requestedPlayingMs > 0) { "Requested playback duration must be positive" }
        require(request.mediaUrl.startsWith("http://") || request.mediaUrl.startsWith("https://")) {
            "Media URL must use HTTP or HTTPS"
        }

        stopRequested.set(false)
        val endpoints = request.endpoints.filter { it.enabled }
        val progress = SessionProgress(endpoints.size)
        val results = mutableListOf<EndpointTestResult>()
        publish(request, progress, running = true)

        for (endpoint in endpoints) {
            if (stopRequested.get()) break
            val startedAt = nowEpochMs()
            publish(request, progress, running = true, current = endpoint.id)

            val preflightError = EndpointParser.preflightError(endpoint)
            if (preflightError != null) {
                val result = baseResult(
                    request = request,
                    endpoint = endpoint,
                    startedAt = startedAt,
                    status = TestStatus.PROXY_UNREACHABLE,
                    error = preflightError,
                )
                results += result
                progress.record(result.status)
                onResult(result)
                publish(request, progress, running = true)
                continue
            }

            var ip = ipCheck.verify(endpoint)
            if (!ip.verified && ip.retryable && !stopRequested.get()) {
                ip = ipCheck.verify(endpoint)
            }

            if (stopRequested.get()) {
                val result = baseResult(
                    request = request,
                    endpoint = endpoint,
                    startedAt = startedAt,
                    status = TestStatus.USER_CANCELLED,
                    detectedIp = ip.ip,
                    latencyMs = ip.latencyMs,
                    error = "Stopped by user",
                )
                results += result
                progress.record(result.status)
                onResult(result)
                publish(request, progress, running = false)
                break
            }

            if (ip.verified) {
                publish(
                    request = request,
                    progress = progress,
                    running = true,
                    current = endpoint.id,
                    detectedIp = ip.ip,
                )
            }

            if (!ip.verified) {
                val status = if (ip.reachable) TestStatus.IP_VERIFY_FAILED else TestStatus.PROXY_UNREACHABLE
                val result = baseResult(
                    request = request,
                    endpoint = endpoint,
                    startedAt = startedAt,
                    status = status,
                    detectedIp = ip.ip,
                    latencyMs = ip.latencyMs,
                    error = ip.error,
                )
                results += result
                progress.record(result.status)
                onResult(result)
                publish(request, progress, running = true)
                continue
            }

            val played = playback.play(
                endpoint = endpoint,
                mediaUrl = request.mediaUrl,
                requestedPlayingMs = request.requestedPlayingMs,
                shouldStop = { stopRequested.get() },
            )
            val facts = AttemptFacts(
                proxyReachable = true,
                ipVerified = true,
                mediaPrepared = played.mediaPrepared,
                actualPlayingMs = played.actualPlayingMs,
                requestedPlayingMs = request.requestedPlayingMs,
                playbackFailed = played.playbackFailed,
                timedOut = played.timedOut,
                cancelled = played.cancelled || stopRequested.get(),
            )
            val status = ResultClassifier.classify(facts)
            val result = EndpointTestResult(
                sessionId = request.sessionId,
                proxyId = endpoint.id,
                targetDisplay = request.targetDisplay,
                startedAtEpochMs = startedAt,
                finishedAtEpochMs = nowEpochMs(),
                requestedWatchMs = request.requestedPlayingMs,
                actualPlayingMs = played.actualPlayingMs,
                wallClockMs = played.wallClockMs,
                detectedPublicIp = ip.ip,
                connectLatencyMs = ip.latencyMs,
                timeToFirstPlaybackMs = played.timeToFirstPlaybackMs,
                bufferingMs = played.bufferingMs,
                bufferEventCount = played.bufferEventCount,
                status = status,
                errorDetail = if (status == TestStatus.USER_CANCELLED) "Stopped by user" else played.errorDetail,
            )
            results += result
            progress.record(result.status)
            onResult(result)
            publish(
                request = request,
                progress = progress,
                running = status != TestStatus.USER_CANCELLED,
                detectedIp = ip.ip,
                actualPlayingMs = played.actualPlayingMs,
            )
            if (status == TestStatus.USER_CANCELLED) break
        }

        publish(request, progress, running = false)
        return results
    }

    private fun baseResult(
        request: TestSessionRequest,
        endpoint: ProxyEndpoint,
        startedAt: Long,
        status: TestStatus,
        detectedIp: String? = null,
        latencyMs: Long? = null,
        error: String? = null,
    ) = EndpointTestResult(
        sessionId = request.sessionId,
        proxyId = endpoint.id,
        targetDisplay = request.targetDisplay,
        startedAtEpochMs = startedAt,
        finishedAtEpochMs = nowEpochMs(),
        requestedWatchMs = request.requestedPlayingMs,
        actualPlayingMs = 0,
        wallClockMs = (nowEpochMs() - startedAt).coerceAtLeast(0),
        detectedPublicIp = detectedIp,
        connectLatencyMs = latencyMs,
        timeToFirstPlaybackMs = null,
        bufferingMs = 0,
        bufferEventCount = 0,
        status = status,
        errorDetail = error,
    )

    private fun publish(
        request: TestSessionRequest,
        progress: SessionProgress,
        running: Boolean,
        current: String? = null,
        detectedIp: String? = null,
        actualPlayingMs: Long = 0,
    ) {
        _state.value = SessionSummary(
            sessionId = request.sessionId,
            total = progress.total,
            passed = progress.passed,
            failed = progress.failed,
            remaining = progress.remaining,
            currentProxyId = current,
            detectedIp = detectedIp,
            actualPlayingMs = actualPlayingMs,
            requestedPlayingMs = request.requestedPlayingMs,
            running = running,
        )
    }
}
