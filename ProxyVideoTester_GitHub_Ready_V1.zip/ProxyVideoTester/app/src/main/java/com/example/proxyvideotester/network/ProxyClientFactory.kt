package com.example.proxyvideotester.network

import com.example.proxyvideotester.domain.ProxyEndpoint
import com.example.proxyvideotester.domain.ProxyType
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit
import okhttp3.Credentials
import okhttp3.OkHttpClient

object ProxyClientFactory {
    fun create(endpoint: ProxyEndpoint, timeoutMs: Long): OkHttpClient {
        require(timeoutMs > 0) { "Timeout must be positive" }
        require(endpoint.type != ProxyType.SOCKS5 || endpoint.username.isNullOrBlank()) {
            "Authenticated SOCKS5 is not supported in V1"
        }

        val javaType = when (endpoint.type) {
            ProxyType.HTTP -> Proxy.Type.HTTP
            ProxyType.SOCKS5 -> Proxy.Type.SOCKS
        }
        val proxy = Proxy(javaType, InetSocketAddress(endpoint.host, endpoint.port))
        val builder = OkHttpClient.Builder()
            .proxy(proxy)
            .connectTimeout(timeoutMs, TimeUnit.MILLISECONDS)
            .readTimeout(timeoutMs, TimeUnit.MILLISECONDS)
            .writeTimeout(timeoutMs, TimeUnit.MILLISECONDS)
            .callTimeout(timeoutMs * 2, TimeUnit.MILLISECONDS)

        if (endpoint.type == ProxyType.HTTP && !endpoint.username.isNullOrBlank()) {
            val username = endpoint.username
            val password = endpoint.password.orEmpty()
            builder.proxyAuthenticator { _, response ->
                if (response.request.header("Proxy-Authorization") != null) {
                    null
                } else {
                    response.request.newBuilder()
                        .header("Proxy-Authorization", Credentials.basic(username, password))
                        .build()
                }
            }
        }

        return builder.build()
    }
}
