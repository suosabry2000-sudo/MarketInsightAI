package com.marketinsight.ai.features.weeklyscanner

import com.marketinsight.ai.core.model.ScannerRow

enum class ScannerFilter(val label: String) {
    ALL("All U.S."), SP500("S&P 500"), NASDAQ("Nasdaq"), DOW("Dow"), TECHNOLOGY("Technology"), AI("AI"),
    SEMICONDUCTORS("Semiconductors"), MEGA_CAP("Mega Cap"), MOST_ACTIVE("Most Active"), WATCHLIST("Watchlist")
}

enum class ScannerSort(val label: String) {
    BEST_OPPORTUNITY("Best Opportunity"), HIGHEST_GAIN("Highest Gain"), HIGHEST_DROP("Highest Drop"),
    HIGHEST_CONFIDENCE("Highest Confidence"), STRONGEST_BULLISH("Strongest Bullish"), STRONGEST_BEARISH("Strongest Bearish"),
    LOWEST_RISK("Lowest Risk"), HIGHEST_VOLATILITY("Highest Volatility"), TICKER_AZ("Ticker A–Z")
}

fun applyScannerFilter(rows: List<ScannerRow>, filter: ScannerFilter, watchlist: Set<String> = emptySet()): List<ScannerRow> = when (filter) {
    ScannerFilter.ALL -> rows
    ScannerFilter.SP500 -> rows.filter { it.indexMemberships.any { x -> x.equals("S&P 500", true) } }
    ScannerFilter.NASDAQ -> rows.filter { it.exchange?.contains("NASDAQ", true) == true || it.indexMemberships.any { x -> x.contains("Nasdaq", true) } }
    ScannerFilter.DOW -> rows.filter { it.indexMemberships.any { x -> x.contains("Dow", true) } }
    ScannerFilter.TECHNOLOGY -> rows.filter { it.sector?.contains("Technology", true) == true || it.themes.any { x -> x.contains("Technology", true) } }
    ScannerFilter.AI -> rows.filter { it.themes.any { x -> x.equals("AI", true) } }
    ScannerFilter.SEMICONDUCTORS -> rows.filter { it.themes.any { x -> x.contains("Semiconductor", true) } }
    ScannerFilter.MEGA_CAP -> rows.filter { it.marketCapBucket?.equals("Mega Cap", true) == true }
    ScannerFilter.MOST_ACTIVE -> rows.filter { it.mostActive }
    ScannerFilter.WATCHLIST -> rows.filter { it.ticker in watchlist }
}

private fun riskRank(value: String): Int = when (value.uppercase()) {
    "LOW" -> 0
    "MEDIUM" -> 1
    "HIGH" -> 2
    else -> 3
}

fun applyScannerSort(rows: List<ScannerRow>, sort: ScannerSort): List<ScannerRow> = when (sort) {
    ScannerSort.BEST_OPPORTUNITY -> rows.sortedByDescending { it.opportunityScore }
    ScannerSort.HIGHEST_GAIN -> rows.sortedByDescending { it.expectedMovePct }
    ScannerSort.HIGHEST_DROP -> rows.sortedBy { it.expectedMovePct }
    ScannerSort.HIGHEST_CONFIDENCE -> rows.sortedByDescending { it.confidence }
    ScannerSort.STRONGEST_BULLISH -> rows.sortedByDescending { it.bullProbability }
    ScannerSort.STRONGEST_BEARISH -> rows.sortedByDescending { it.bearProbability }
    ScannerSort.LOWEST_RISK -> rows.sortedWith(compareBy<ScannerRow> { riskRank(it.risk) }.thenByDescending { it.confidence })
    ScannerSort.HIGHEST_VOLATILITY -> rows.sortedByDescending { it.volatility }
    ScannerSort.TICKER_AZ -> rows.sortedBy { it.ticker }
}
