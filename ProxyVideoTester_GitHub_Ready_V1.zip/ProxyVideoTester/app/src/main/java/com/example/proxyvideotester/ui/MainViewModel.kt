package com.example.proxyvideotester.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.proxyvideotester.data.AppDatabase
import com.example.proxyvideotester.data.CredentialStore
import com.example.proxyvideotester.data.SettingsStore
import com.example.proxyvideotester.data.TesterRepository
import com.example.proxyvideotester.data.TesterSettings
import com.example.proxyvideotester.domain.EndpointParser
import com.example.proxyvideotester.domain.EndpointTestResult
import com.example.proxyvideotester.domain.IpCheckOutcome
import com.example.proxyvideotester.domain.IpCheckPort
import com.example.proxyvideotester.domain.PlaybackOutcome
import com.example.proxyvideotester.domain.PlaybackPort
import com.example.proxyvideotester.domain.ProxyEndpoint
import com.example.proxyvideotester.domain.SessionSummary
import com.example.proxyvideotester.domain.TestSessionEngine
import com.example.proxyvideotester.domain.TestSessionRequest
import com.example.proxyvideotester.export.ExportRecord
import com.example.proxyvideotester.export.ResultExporter
import com.example.proxyvideotester.network.IpVerifier
import com.example.proxyvideotester.network.ProxyClientFactory
import com.example.proxyvideotester.player.MediaPlaybackRunner
import com.example.proxyvideotester.player.PlaybackRequest
import com.example.proxyvideotester.player.PlaybackSnapshot
import java.util.UUID
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppScreen { DASHBOARD, PROXIES, LIVE, RESULTS, SETTINGS }

data class MainUiState(
    val screen: AppScreen = AppScreen.DASHBOARD,
    val mediaUrl: String = "",
    val durationText: String = "60",
    val endpoints: List<ProxyEndpoint> = emptyList(),
    val results: List<EndpointTestResult> = emptyList(),
    val session: SessionSummary = SessionSummary("", 0, 0, 0, 0),
    val importText: String = "",
    val importErrors: List<String> = emptyList(),
    val settings: TesterSettings = TesterSettings(),
    val livePlayback: PlaybackSnapshot? = null,
    val message: String? = null,
) {
    val durationSeconds: Int? get() = durationText.toIntOrNull()?.takeIf { it in 1..3600 }
    val mediaUrlValid: Boolean get() = mediaUrl.startsWith("https://") || mediaUrl.startsWith("http://")
    val enabledEndpoints: List<ProxyEndpoint> get() = endpoints.filter { it.enabled }
    val canStart: Boolean get() = !session.running && mediaUrlValid && durationSeconds != null &&
        enabledEndpoints.isNotEmpty() && enabledEndpoints.none { EndpointParser.preflightError(it) != null }
    val currentEndpoint: ProxyEndpoint? get() = endpoints.firstOrNull { it.id == session.currentProxyId }
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val repository = TesterRepository(AppDatabase.get(context), CredentialStore(context))
    private val settingsStore = SettingsStore(context)
    private val runner = MediaPlaybackRunner(context)
    val currentPlayer = runner.currentPlayer

    @Volatile private var latestSettings = TesterSettings()
    private var settingsInitialized = false
    private var runJob: Job? = null

    private val engine = TestSessionEngine(
        ipCheck = IpCheckPort { endpoint ->
            val settings = latestSettings
            runCatching {
                val client = ProxyClientFactory.create(endpoint, settings.connectionTimeoutMs)
                val result = IpVerifier.verify(client, settings.ipCheckEndpoint)
                IpCheckOutcome(
                    reachable = result.reachable,
                    verified = result.success,
                    ip = result.ip,
                    latencyMs = result.latencyMs,
                    error = result.error,
                    retryable = result.retryable,
                )
            }.getOrElse { error ->
                IpCheckOutcome(
                    reachable = false,
                    verified = false,
                    error = error.message ?: error.javaClass.simpleName,
                    retryable = false,
                )
            }
        },
        playback = PlaybackPort { endpoint, mediaUrl, requestedPlayingMs, shouldStop ->
            val settings = latestSettings
            val metrics = runner.run(
                PlaybackRequest(
                    mediaUrl = mediaUrl,
                    endpoint = endpoint,
                    requestedPlayingMs = requestedPlayingMs,
                    connectionTimeoutMs = settings.connectionTimeoutMs,
                    startupTimeoutMs = settings.startupTimeoutMs,
                    shouldStop = shouldStop,
                )
            )
            PlaybackOutcome(
                mediaPrepared = metrics.mediaPrepared,
                actualPlayingMs = metrics.actualPlayingMs,
                wallClockMs = metrics.wallClockMs,
                timeToFirstPlaybackMs = metrics.timeToFirstPlaybackMs,
                bufferingMs = metrics.bufferingMs,
                bufferEventCount = metrics.bufferEventCount,
                playbackFailed = metrics.playbackFailed,
                timedOut = metrics.timedOut,
                cancelled = metrics.cancelled,
                errorDetail = metrics.errorDetail,
            )
        },
    )

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.observeEndpoints().collect { endpoints ->
                _uiState.update { it.copy(endpoints = endpoints) }
            }
        }
        viewModelScope.launch {
            repository.observeResults().collect { results ->
                _uiState.update { it.copy(results = results) }
            }
        }
        viewModelScope.launch {
            engine.state.collect { session ->
                _uiState.update { it.copy(session = session) }
            }
        }
        viewModelScope.launch {
            runner.liveSnapshot.collect { snapshot ->
                _uiState.update { it.copy(livePlayback = snapshot) }
            }
        }
        viewModelScope.launch {
            settingsStore.settings.collect { settings ->
                latestSettings = settings
                _uiState.update { state ->
                    state.copy(
                        settings = settings,
                        durationText = if (settingsInitialized) state.durationText else settings.defaultDurationSeconds.toString(),
                    )
                }
                settingsInitialized = true
            }
        }
    }

    fun setScreen(screen: AppScreen) = _uiState.update { it.copy(screen = screen) }
    fun setMediaUrl(value: String) = _uiState.update { it.copy(mediaUrl = value, message = null) }
    fun setDurationText(value: String) = _uiState.update { it.copy(durationText = value.filter(Char::isDigit).take(4)) }
    fun setImportText(value: String) = _uiState.update { it.copy(importText = value) }
    fun clearMessage() = _uiState.update { it.copy(message = null) }

    fun importEndpoints() {
        val parsed = EndpointParser.parseMultiline(_uiState.value.importText)
        val valid = parsed.mapNotNull { (it as? com.example.proxyvideotester.domain.ParseResult.Valid)?.endpoint }
        val errors = parsed.mapNotNull { (it as? com.example.proxyvideotester.domain.ParseResult.Invalid)?.let { bad -> "${bad.sourceLine}: ${bad.reason}" } }
        viewModelScope.launch {
            valid.forEach { repository.upsertEndpoint(it) }
            _uiState.update {
                it.copy(
                    importText = if (errors.isEmpty()) "" else it.importText,
                    importErrors = errors,
                    message = if (valid.isNotEmpty()) "Imported ${valid.size} endpoint(s)" else "No valid endpoints imported",
                )
            }
        }
    }

    fun setEndpointEnabled(endpoint: ProxyEndpoint, enabled: Boolean) {
        viewModelScope.launch { repository.upsertEndpoint(endpoint.copy(enabled = enabled)) }
    }

    fun deleteEndpoint(endpoint: ProxyEndpoint) {
        if (_uiState.value.session.running) return
        viewModelScope.launch { repository.deleteEndpoint(endpoint.id) }
    }

    fun startTest() = startInternal(_uiState.value.enabledEndpoints)

    fun testOneEndpoint(endpoint: ProxyEndpoint) = startInternal(listOf(endpoint.copy(enabled = true)))

    private fun startInternal(endpoints: List<ProxyEndpoint>) {
        val state = _uiState.value
        val seconds = state.durationSeconds
        if (!state.mediaUrlValid || seconds == null || endpoints.isEmpty() || state.session.running) {
            _uiState.update { it.copy(message = "Enter a valid direct media URL, duration, and enabled endpoint") }
            return
        }
        val unsupported = endpoints.firstNotNullOfOrNull { EndpointParser.preflightError(it) }
        if (unsupported != null) {
            _uiState.update { it.copy(message = unsupported) }
            return
        }

        val sessionId = UUID.randomUUID().toString()
        val requestedMs = seconds * 1_000L
        val targetDisplay = ResultExporter.redactUrl(state.mediaUrl)
        _uiState.update { it.copy(screen = AppScreen.LIVE, message = null) }
        runJob = viewModelScope.launch {
            val started = System.currentTimeMillis()
            repository.createSession(sessionId, targetDisplay, requestedMs, started)
            try {
                engine.run(
                    TestSessionRequest(
                        sessionId = sessionId,
                        mediaUrl = state.mediaUrl,
                        targetDisplay = targetDisplay,
                        requestedPlayingMs = requestedMs,
                        endpoints = endpoints,
                    ),
                    onResult = { repository.saveResult(it) },
                )
            } finally {
                repository.finishSession(sessionId, System.currentTimeMillis())
            }
        }
    }

    fun stopTest() = engine.requestStop()

    fun updateSettings(settings: TesterSettings) = _uiState.update { it.copy(settings = settings) }

    fun saveSettings() {
        val settings = _uiState.value.settings
        viewModelScope.launch {
            settingsStore.update(settings)
            _uiState.update { it.copy(message = "Settings saved") }
        }
    }

    fun clearResults() {
        if (_uiState.value.session.running) return
        viewModelScope.launch { repository.clearResults() }
    }

    fun exportCsv(): String = ResultExporter.toCsv(exportRecords())
    fun exportJson(): String = ResultExporter.toJson(exportRecords())

    private fun exportRecords(): List<ExportRecord> {
        val state = _uiState.value
        val endpointById = state.endpoints.associateBy { it.id }
        return state.results.map { result ->
            ExportRecord(
                endpointDisplay = endpointById[result.proxyId]?.toString() ?: result.proxyId,
                result = result,
            )
        }
    }
}
