package com.example.proxyvideotester.player

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MediaPlaybackRunnerLogicTest {
    @Test fun bufferingDoesNotAdvanceActualPlayback() {
        val a = PlaybackStateAccumulator(0)
        a.onPrepared(1_000)
        a.onPlayingChanged(true, 2_000)
        a.onBufferingChanged(true, 22_000)
        a.onPlayingChanged(false, 22_000)
        a.onBufferingChanged(false, 32_000)
        a.onPlayingChanged(true, 32_000)
        val s = a.snapshot(72_000)
        assertEquals(60_000, s.actualPlayingMs)
        assertEquals(10_000, s.bufferingMs)
        assertEquals(1, s.bufferEventCount)
        assertEquals(2_000, s.timeToFirstPlaybackMs)
        assertTrue(s.mediaPrepared)
    }
}
