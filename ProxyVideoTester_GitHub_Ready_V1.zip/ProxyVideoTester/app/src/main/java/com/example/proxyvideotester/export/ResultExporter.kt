package com.example.proxyvideotester.export

import com.example.proxyvideotester.domain.EndpointTestResult
import java.net.URI

data class ExportRecord(
    val endpointDisplay: String,
    val result: EndpointTestResult,
)

object ResultExporter {
    fun redactUrl(raw: String): String {
        return runCatching {
            val uri = URI(raw)
            val scheme = uri.scheme ?: return@runCatching "invalid-url"
            val host = uri.host ?: return@runCatching "invalid-url"
            val port = if (uri.port >= 0) ":${uri.port}" else ""
            val path = uri.rawPath?.ifBlank { "/" } ?: "/"
            val query = if (uri.rawQuery != null) "?redacted" else ""
            "$scheme://$host$port$path$query"
        }.getOrDefault("invalid-url")
    }

    fun toCsv(records: List<ExportRecord>): String {
        val header = listOf(
            "session_id",
            "proxy_id",
            "endpoint",
            "target",
            "status",
            "detected_ip",
            "requested_watch_ms",
            "actual_playing_ms",
            "wall_clock_ms",
            "connect_latency_ms",
            "time_to_first_playback_ms",
            "buffering_ms",
            "buffer_event_count",
            "started_at_epoch_ms",
            "finished_at_epoch_ms",
            "error_detail",
        )
        return buildString {
            append(header.joinToString(","))
            append('\n')
            records.forEach { record ->
                val r = record.result
                val values = listOf(
                    r.sessionId,
                    r.proxyId,
                    record.endpointDisplay,
                    redactUrl(r.targetDisplay),
                    r.status.name,
                    r.detectedPublicIp.orEmpty(),
                    r.requestedWatchMs.toString(),
                    r.actualPlayingMs.toString(),
                    r.wallClockMs.toString(),
                    r.connectLatencyMs?.toString().orEmpty(),
                    r.timeToFirstPlaybackMs?.toString().orEmpty(),
                    r.bufferingMs.toString(),
                    r.bufferEventCount.toString(),
                    r.startedAtEpochMs.toString(),
                    r.finishedAtEpochMs.toString(),
                    r.errorDetail.orEmpty(),
                )
                append(values.joinToString(",") { csvEscape(it) })
                append('\n')
            }
        }
    }

    fun toJson(records: List<ExportRecord>): String = buildString {
        append('[')
        records.forEachIndexed { index, record ->
            if (index > 0) append(',')
            val r = record.result
            append('{')
            appendJsonField("sessionId", r.sessionId); append(',')
            appendJsonField("proxyId", r.proxyId); append(',')
            appendJsonField("endpoint", record.endpointDisplay); append(',')
            appendJsonField("target", redactUrl(r.targetDisplay)); append(',')
            appendJsonField("status", r.status.name); append(',')
            appendJsonNullable("detectedIp", r.detectedPublicIp); append(',')
            appendJsonNumber("requestedWatchMs", r.requestedWatchMs); append(',')
            appendJsonNumber("actualPlayingMs", r.actualPlayingMs); append(',')
            appendJsonNumber("wallClockMs", r.wallClockMs); append(',')
            appendJsonNullableNumber("connectLatencyMs", r.connectLatencyMs); append(',')
            appendJsonNullableNumber("timeToFirstPlaybackMs", r.timeToFirstPlaybackMs); append(',')
            appendJsonNumber("bufferingMs", r.bufferingMs); append(',')
            appendJsonNumber("bufferEventCount", r.bufferEventCount.toLong()); append(',')
            appendJsonNumber("startedAtEpochMs", r.startedAtEpochMs); append(',')
            appendJsonNumber("finishedAtEpochMs", r.finishedAtEpochMs); append(',')
            appendJsonNullable("errorDetail", r.errorDetail)
            append('}')
        }
        append(']')
    }

    private fun csvEscape(value: String): String {
        val escaped = value.replace("\"", "\"\"")
        return if (value.any { it == ',' || it == '\n' || it == '\r' || it == '"' }) {
            "\"$escaped\""
        } else escaped
    }

    private fun StringBuilder.appendJsonField(name: String, value: String) {
        append('"').append(jsonEscape(name)).append("\":\"")
            .append(jsonEscape(value)).append('"')
    }

    private fun StringBuilder.appendJsonNullable(name: String, value: String?) {
        append('"').append(jsonEscape(name)).append("\":")
        if (value == null) append("null") else append('"').append(jsonEscape(value)).append('"')
    }

    private fun StringBuilder.appendJsonNumber(name: String, value: Long) {
        append('"').append(jsonEscape(name)).append("\":").append(value)
    }

    private fun StringBuilder.appendJsonNullableNumber(name: String, value: Long?) {
        append('"').append(jsonEscape(name)).append("\":")
        if (value == null) append("null") else append(value)
    }

    private fun jsonEscape(value: String): String = buildString {
        value.forEach { ch ->
            when (ch) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                '\t' -> append("\\t")
                else -> if (ch.code < 0x20) append("\\u%04x".format(ch.code)) else append(ch)
            }
        }
    }
}
