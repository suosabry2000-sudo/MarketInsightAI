package com.example.proxyvideotester.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EndpointParserTest {
    @Test fun parsesBareHostPortAsHttp() {
        val result = EndpointParser.parseLine("127.0.0.1:8080") as ParseResult.Valid
        assertEquals("127.0.0.1", result.endpoint.host)
        assertEquals(8080, result.endpoint.port)
        assertEquals(ProxyType.HTTP, result.endpoint.type)
    }

    @Test fun parsesHttpCredentialsWithoutLeakingPassword() {
        val result = EndpointParser.parseLine("http://sam:secret@proxy.example:3128") as ParseResult.Valid
        assertEquals("sam", result.endpoint.username)
        assertEquals("secret", result.endpoint.password)
        assertFalse(result.endpoint.toString().contains("secret"))
    }

    @Test fun rejectsInvalidPort() {
        assertTrue(EndpointParser.parseLine("proxy.example:99999") is ParseResult.Invalid)
    }

    @Test fun preservesOneHundredImportedEndpointsInOrder() {
        val text = (1..100).joinToString("\n") { "10.0.0.$it:8080" }
        val results = EndpointParser.parseMultiline(text)
        assertEquals(100, results.size)
        assertEquals("10.0.0.1", (results.first() as ParseResult.Valid).endpoint.host)
        assertEquals("10.0.0.100", (results.last() as ParseResult.Valid).endpoint.host)
    }
}
