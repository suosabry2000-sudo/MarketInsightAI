package com.example.proxyvideotester.export

import com.example.proxyvideotester.domain.EndpointTestResult
import com.example.proxyvideotester.domain.TestStatus
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResultExporterTest {
    private val result = EndpointTestResult(
        id = "r1", sessionId = "s1", proxyId = "p1",
        targetDisplay = "https://example.test/video.mp4?token=secret",
        startedAtEpochMs = 1, finishedAtEpochMs = 2,
        requestedWatchMs = 60_000, actualPlayingMs = 60_000, wallClockMs = 65_000,
        detectedPublicIp = "203.0.113.1", connectLatencyMs = 15,
        timeToFirstPlaybackMs = 500, bufferingMs = 4_500, bufferEventCount = 1,
        status = TestStatus.PASSED, errorDetail = null,
    )

    @Test fun exportsDoNotContainSensitiveQueryValues() {
        val safe = result.copy(targetDisplay = ResultExporter.redactUrl(result.targetDisplay))
        val records = listOf(ExportRecord("http://sam@proxy.example:8080", safe))
        assertFalse(ResultExporter.toCsv(records).contains("secret"))
        assertFalse(ResultExporter.toJson(records).contains("secret"))
        assertTrue(ResultExporter.toCsv(records).contains("?redacted"))
    }
}
