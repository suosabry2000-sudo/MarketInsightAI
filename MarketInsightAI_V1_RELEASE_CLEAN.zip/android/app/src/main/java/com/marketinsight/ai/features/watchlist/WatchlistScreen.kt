package com.marketinsight.ai.features.watchlist

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.StatusBanner
import kotlinx.coroutines.launch

@Composable
fun WatchlistScreen(repository: MarketRepository, onOpenStock: (String) -> Unit) {
    var values by remember { mutableStateOf(repository.localWatchlist()) }
    var offline by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        val result: FetchResult<Set<String>> = repository.syncWatchlist(); values = result.data ?: values; offline = result.isOffline; error = result.error
    }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Watchlist", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
        item { StatusBanner(offline, false, error) }
        if (values.isEmpty()) item { Text("Your watchlist is empty. Add a stock with the star button on its stock page.") }
        items(values.sorted(), key = { it }) { ticker ->
            Card(onClick = { onOpenStock(ticker) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(ticker, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { scope.launch { values = repository.removeWatchlist(ticker) } }) { Icon(Icons.Default.Delete, "Remove") }
                }
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
