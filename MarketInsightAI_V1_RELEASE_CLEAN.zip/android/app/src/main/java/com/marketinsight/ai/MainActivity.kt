package com.marketinsight.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.*
import com.marketinsight.ai.core.theme.MarketInsightTheme
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.navigation.MarketInsightApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = MarketRepository(applicationContext)
        setContent {
            var theme by remember { mutableStateOf(repository.themeMode()) }
            val systemDark = isSystemInDarkTheme()
            val dark = when (theme) { "Dark" -> true; "Light" -> false; else -> systemDark }
            MarketInsightTheme(dark = dark) {
                MarketInsightApp(
                    repository = repository,
                    themeMode = theme,
                    onThemeChanged = { theme = it; repository.setThemeMode(it) },
                )
            }
        }
    }
}
