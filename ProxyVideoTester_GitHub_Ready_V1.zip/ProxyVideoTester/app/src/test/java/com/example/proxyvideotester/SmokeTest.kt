package com.example.proxyvideotester

import org.junit.Assert.assertTrue
import org.junit.Test

class SmokeTest {
    @Test
    fun projectLoads() = assertTrue(true)
}
