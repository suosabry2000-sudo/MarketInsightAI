package com.example.proxyvideotester.player

import android.content.Context
import android.os.SystemClock
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import com.example.proxyvideotester.domain.ProxyEndpoint
import com.example.proxyvideotester.network.ProxyClientFactory
import java.util.concurrent.atomic.AtomicReference
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.coroutines.coroutineContext

data class PlaybackRequest(
    val mediaUrl: String,
    val endpoint: ProxyEndpoint,
    val requestedPlayingMs: Long,
    val connectionTimeoutMs: Long = 10_000,
    val startupTimeoutMs: Long = 20_000,
    val overallExtraTimeoutMs: Long = 120_000,
    val shouldStop: () -> Boolean = { false },
)

data class PlaybackMetrics(
    val mediaPrepared: Boolean,
    val actualPlayingMs: Long,
    val wallClockMs: Long,
    val timeToFirstPlaybackMs: Long?,
    val bufferingMs: Long,
    val bufferEventCount: Int,
    val playbackFailed: Boolean,
    val timedOut: Boolean,
    val endedEarly: Boolean,
    val cancelled: Boolean,
    val errorDetail: String? = null,
)

class MediaPlaybackRunner(
    private val context: Context,
    private val nowMs: () -> Long = { SystemClock.elapsedRealtime() },
) {
    private val currentPlayerRef = AtomicReference<ExoPlayer?>(null)
    private val _currentPlayer = MutableStateFlow<Player?>(null)
    val currentPlayer: StateFlow<Player?> = _currentPlayer.asStateFlow()
    private val _liveSnapshot = MutableStateFlow<PlaybackSnapshot?>(null)
    val liveSnapshot: StateFlow<PlaybackSnapshot?> = _liveSnapshot.asStateFlow()

    fun currentPlayerNow(): Player? = currentPlayerRef.get()

    suspend fun run(request: PlaybackRequest): PlaybackMetrics = withContext(Dispatchers.Main.immediate) {
        require(request.mediaUrl.startsWith("http://") || request.mediaUrl.startsWith("https://")) {
            "Media URL must use HTTP or HTTPS"
        }
        require(request.requestedPlayingMs > 0) { "Requested playback duration must be positive" }

        val started = nowMs()
        val accumulator = PlaybackStateAccumulator(started)
        val errorRef = AtomicReference<String?>(null)
        var endedEarly = false
        var timedOut = false
        var cancelledByUser = false

        val client = ProxyClientFactory.create(request.endpoint, request.connectionTimeoutMs)
        val dataSourceFactory = OkHttpDataSource.Factory(client)
        val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
        val player = ExoPlayer.Builder(context)
            .setMediaSourceFactory(mediaSourceFactory)
            .build()
        currentPlayerRef.set(player)
        _currentPlayer.value = player
        _liveSnapshot.value = accumulator.snapshot(started)

        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val now = nowMs()
                when (playbackState) {
                    Player.STATE_READY -> {
                        accumulator.onPrepared(now)
                        accumulator.onBufferingChanged(false, now)
                    }
                    Player.STATE_BUFFERING -> accumulator.onBufferingChanged(true, now)
                    Player.STATE_ENDED -> {
                        accumulator.onPlayingChanged(false, now)
                        accumulator.onBufferingChanged(false, now)
                        if (accumulator.snapshot(now).actualPlayingMs < request.requestedPlayingMs) {
                            endedEarly = true
                        }
                    }
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                accumulator.onPlayingChanged(isPlaying, nowMs())
            }

            override fun onPlayerError(error: PlaybackException) {
                errorRef.set(error.errorCodeName)
            }
        }

        try {
            player.addListener(listener)
            player.setMediaItem(MediaItem.fromUri(request.mediaUrl))
            player.prepare()
            player.playWhenReady = true

            while (true) {
                coroutineContext.ensureActive()
                val now = nowMs()
                if (request.shouldStop()) {
                    cancelledByUser = true
                    break
                }
                val snapshot = accumulator.snapshot(now)
                _liveSnapshot.value = snapshot
                if (snapshot.actualPlayingMs >= request.requestedPlayingMs) break
                if (errorRef.get() != null || endedEarly) break

                if (!snapshot.mediaPrepared && snapshot.wallClockMs >= request.startupTimeoutMs) {
                    timedOut = true
                    break
                }
                val overallLimit = request.requestedPlayingMs + request.overallExtraTimeoutMs
                if (snapshot.wallClockMs >= overallLimit) {
                    timedOut = true
                    break
                }
                delay(100)
            }

            val finalSnapshot = accumulator.snapshot(nowMs())
            _liveSnapshot.value = finalSnapshot
            PlaybackMetrics(
                mediaPrepared = finalSnapshot.mediaPrepared,
                actualPlayingMs = finalSnapshot.actualPlayingMs,
                wallClockMs = finalSnapshot.wallClockMs,
                timeToFirstPlaybackMs = finalSnapshot.timeToFirstPlaybackMs,
                bufferingMs = finalSnapshot.bufferingMs,
                bufferEventCount = finalSnapshot.bufferEventCount,
                playbackFailed = errorRef.get() != null || endedEarly,
                timedOut = timedOut,
                endedEarly = endedEarly,
                cancelled = cancelledByUser,
                errorDetail = errorRef.get() ?: if (endedEarly) "Media ended before requested playback duration" else null,
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } finally {
            val now = nowMs()
            accumulator.onPlayingChanged(false, now)
            accumulator.onBufferingChanged(false, now)
            player.removeListener(listener)
            player.stop()
            player.release()
            currentPlayerRef.compareAndSet(player, null)
            _currentPlayer.value = null
            _liveSnapshot.value = null
        }
    }
}
