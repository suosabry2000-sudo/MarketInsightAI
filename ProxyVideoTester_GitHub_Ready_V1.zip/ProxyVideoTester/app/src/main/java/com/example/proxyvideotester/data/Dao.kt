package com.example.proxyvideotester.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface ProxyDao {
    @Query("SELECT * FROM proxy_endpoints ORDER BY rowid ASC")
    fun observeAll(): Flow<List<ProxyEndpointEntity>>

    @Query("SELECT * FROM proxy_endpoints ORDER BY rowid ASC")
    suspend fun listAll(): List<ProxyEndpointEntity>

    @Query("SELECT * FROM proxy_endpoints WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ProxyEndpointEntity?

    @Upsert
    suspend fun upsert(entity: ProxyEndpointEntity)

    @Query("DELETE FROM proxy_endpoints WHERE id = :id")
    suspend fun deleteById(id: String)
}

@Dao
interface SessionDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: TestSessionEntity)

    @Query("UPDATE test_sessions SET finishedAtEpochMs = :finishedAt WHERE id = :sessionId")
    suspend fun finish(sessionId: String, finishedAt: Long)
}

@Dao
interface ResultDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entity: EndpointResultEntity)

    @Query("SELECT * FROM endpoint_results ORDER BY startedAtEpochMs DESC")
    fun observeAll(): Flow<List<EndpointResultEntity>>

    @Query("SELECT * FROM endpoint_results WHERE sessionId = :sessionId ORDER BY startedAtEpochMs ASC")
    suspend fun listForSession(sessionId: String): List<EndpointResultEntity>

    @Query("DELETE FROM endpoint_results")
    suspend fun clearAll()
}
