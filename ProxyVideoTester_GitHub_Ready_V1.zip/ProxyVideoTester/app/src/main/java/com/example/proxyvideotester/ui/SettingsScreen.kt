package com.example.proxyvideotester.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.proxyvideotester.data.TesterSettings

@Composable
fun SettingsScreen(
    state: MainUiState,
    onChange: (TesterSettings) -> Unit,
    onSave: () -> Unit,
) {
    val s = state.settings
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("Settings")
        OutlinedTextField(
            value = s.defaultDurationSeconds.toString(),
            onValueChange = { value -> value.toIntOrNull()?.let { onChange(s.copy(defaultDurationSeconds = it.coerceIn(1, 3600))) } },
            label = { Text("Default duration (seconds)") },
            enabled = !state.session.running,
        )
        OutlinedTextField(
            value = s.connectionTimeoutMs.toString(),
            onValueChange = { value -> value.toLongOrNull()?.let { onChange(s.copy(connectionTimeoutMs = it.coerceIn(1_000, 120_000))) } },
            label = { Text("Connection timeout (ms)") },
            enabled = !state.session.running,
        )
        OutlinedTextField(
            value = s.startupTimeoutMs.toString(),
            onValueChange = { value -> value.toLongOrNull()?.let { onChange(s.copy(startupTimeoutMs = it.coerceIn(1_000, 120_000))) } },
            label = { Text("Playback startup timeout (ms)") },
            enabled = !state.session.running,
        )
        OutlinedTextField(
            value = s.ipCheckEndpoint,
            onValueChange = { onChange(s.copy(ipCheckEndpoint = it)) },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("IP check endpoint") },
            enabled = !state.session.running,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Switch(
                checked = s.showPlayerPreview,
                onCheckedChange = { onChange(s.copy(showPlayerPreview = it)) },
                enabled = !state.session.running,
            )
            Text("Show live player preview")
        }
        Button(onClick = onSave, enabled = !state.session.running) { Text("Save Settings") }
    }
}
