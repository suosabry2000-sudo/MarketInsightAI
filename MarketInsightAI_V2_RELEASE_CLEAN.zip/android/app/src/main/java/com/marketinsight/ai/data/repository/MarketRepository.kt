package com.marketinsight.ai.data.repository

import android.content.Context
import com.marketinsight.ai.core.model.*
import com.marketinsight.ai.core.network.MarketApi
import com.marketinsight.ai.core.network.QuoteSocket
import com.marketinsight.ai.features.markets.CatalogSort
import com.marketinsight.ai.features.markets.applyCatalogFiltersAndSort
import com.marketinsight.ai.features.markets.builtInStockCatalog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID


data class FetchResult<T>(
    val data: T?,
    val isOffline: Boolean,
    val cachedAt: Long? = null,
    val error: String? = null,
    val isDemo: Boolean = false,
)

class MarketRepository(context: Context) {
    private val prefs = context.getSharedPreferences("market_insight", Context.MODE_PRIVATE)
    private val api = MarketApi()
    val quoteSocket = QuoteSocket(api.client)
    private val cache = context.getSharedPreferences("market_cache", Context.MODE_PRIVATE)

    fun themeMode(): String = prefs.getString("theme", "System") ?: "System"
    fun setThemeMode(value: String) { prefs.edit().putString("theme", value).apply() }
    fun stringPreference(key: String, default: String): String = prefs.getString(key, default) ?: default
    fun setStringPreference(key: String, value: String) { prefs.edit().putString(key, value).apply() }
    fun intPreference(key: String, default: Int): Int = prefs.getInt(key, default)
    fun setIntPreference(key: String, value: Int) { prefs.edit().putInt(key, value).apply() }

    fun localWatchlist(): Set<String> = prefs.getStringSet("watchlist", setOf("AAPL", "NVDA"))?.toSet() ?: emptySet()
    private fun setLocalWatchlist(values: Set<String>) { prefs.edit().putStringSet("watchlist", values).apply() }

    suspend fun ensureToken(): String? {
        val existing = prefs.getString("token", null)
        val expiry = prefs.getLong("token_expiry", 0L)
        if (!existing.isNullOrBlank() && expiry > System.currentTimeMillis() + 30_000L) return existing
        val installation = prefs.getString("installation_id", null) ?: UUID.randomUUID().toString().also {
            prefs.edit().putString("installation_id", it).apply()
        }
        return runCatching {
            val raw = api.post("/auth/device", JSONObject().put("installation_id", installation).toString())
            val o = JSONObject(raw); val token = o.getString("access_token"); val ttl = o.optLong("expires_in", 900L)
            prefs.edit().putString("token", token).putLong("token_expiry", System.currentTimeMillis() + ttl * 1000L).apply()
            token
        }.getOrNull()
    }

    private suspend fun <T> cached(key: String, parser: (String) -> T, network: suspend () -> String, demo: (() -> T)? = null): FetchResult<T> {
        return try {
            val raw = network(); val now = System.currentTimeMillis()
            cache.edit().putString(key, raw).putLong("${key}_at", now).apply()
            FetchResult(parser(raw), false, now)
        } catch (e: Exception) {
            val raw = cache.getString(key, null); val at = cache.getLong("${key}_at", 0L).takeIf { it > 0 }
            if (raw != null) FetchResult(runCatching { parser(raw) }.getOrNull(), true, at, e.message)
            else if (demo != null) FetchResult(demo(), true, System.currentTimeMillis(), e.message, isDemo = true)
            else FetchResult(null, true, null, e.message)
        }
    }

    suspend fun marketOverview(): FetchResult<MarketOverview> = cached("markets", MarketApi::parseMarketOverview, { api.get("/markets/overview") }, ::demoOverview)

    suspend fun catalog(limit: Int = 5000): FetchResult<List<StockSearchResult>> =
        cached("stock_catalog", MarketApi::parseSearch, { api.get("/stocks/catalog?offset=0&limit=${limit.coerceIn(1, 5000)}") }, { builtInStockCatalog })

    suspend fun catalogPage(
        offset: Int = 0,
        limit: Int = 80,
        sort: CatalogSort = CatalogSort.SYMBOL_A_Z,
        query: String = "",
        exchange: String = "ALL",
        sector: String = "ALL",
        assetType: String = "ALL",
    ): FetchResult<CatalogPage> {
        val safeOffset = offset.coerceAtLeast(0)
        val safeLimit = limit.coerceIn(1, 250)
        val path = buildString {
            append("/stocks/catalog?offset=$safeOffset&limit=$safeLimit")
            append("&sort=${sort.wireSort}&direction=${sort.wireDirection}")
            append("&q=${MarketApi.encode(query)}")
            append("&exchange=${MarketApi.encode(exchange)}")
            append("&sector=${MarketApi.encode(sector)}")
            append("&asset_type=${MarketApi.encode(assetType)}")
        }
        val key = "catalog_page_${safeOffset}_${safeLimit}_${sort.name}_${query.lowercase()}_${exchange}_${sector}_${assetType}"
        return cached(key, MarketApi::parseCatalogPage, { api.get(path) }) {
            val filtered = applyCatalogFiltersAndSort(
                builtInStockCatalog, query = query, exchange = exchange, sector = sector, assetType = assetType, sort = sort
            )
            val page = filtered.drop(safeOffset).take(safeLimit)
            CatalogPage(page, filtered.size, safeOffset, safeLimit, safeOffset + page.size < filtered.size)
        }
    }

    suspend fun search(query: String): FetchResult<List<StockSearchResult>> {
        if (query.isBlank()) return FetchResult(emptyList(), false)
        return cached("search_${query.lowercase()}", MarketApi::parseSearch, { api.get("/stocks/search?q=${MarketApi.encode(query)}") }, { demoSearch(query) })
    }

    suspend fun quote(ticker: String): FetchResult<Quote> = cached("quote_${ticker.uppercase()}", { MarketApi.parseQuote(JSONObject(it)) }, { api.get("/quotes/${ticker.uppercase()}") }, { demoQuote(ticker) })

    suspend fun chart(ticker: String, range: String): FetchResult<List<PriceBar>> = cached("chart_${ticker.uppercase()}_$range", MarketApi::parseChart, { api.get("/charts/${ticker.uppercase()}?range=$range") }, { demoChart(ticker) })

    suspend fun forecast(ticker: String): FetchResult<Forecast> = cached("forecast_${ticker.uppercase()}", MarketApi::parseForecast, { api.get("/forecasts/${ticker.uppercase()}") }, { demoForecast(ticker) })

    suspend fun scanner(tickers: List<String> = defaultUniverse): FetchResult<ScannerResponse> {
        val list = tickers.distinct().take(100).joinToString(",")
        return cached("scanner", MarketApi::parseScanner, { api.get("/scanner/weekly?tickers=${MarketApi.encode(list)}&sort=opportunity") }, ::demoScanner)
    }

    suspend fun technical(ticker: String) = cached("technical_${ticker.uppercase()}", MarketApi::parseTechnical, { api.get("/technical/${ticker.uppercase()}") }, { demoTechnical(ticker) })
    suspend fun fundamentals(ticker: String) = cached("fundamentals_${ticker.uppercase()}", MarketApi::parseFundamentals, { api.get("/fundamentals/${ticker.uppercase()}") }, { demoFundamentals(ticker) })
    suspend fun news(ticker: String) = cached("news_${ticker.uppercase()}", MarketApi::parseNews, { api.get("/news/${ticker.uppercase()}") }, { demoNews(ticker) })
    suspend fun verification(ticker: String) = cached("verification_${ticker.uppercase()}", MarketApi::parseVerification, { api.get("/verification/${ticker.uppercase()}") }, { demoVerification(ticker) })
    suspend fun accuracy(ticker: String) = cached("accuracy_${ticker.uppercase()}", MarketApi::parseAccuracy, { api.get("/accuracy/${ticker.uppercase()}") }, { demoAccuracy(ticker) })

    suspend fun syncWatchlist(): FetchResult<Set<String>> {
        val token = ensureToken() ?: return FetchResult(localWatchlist(), true, error = "Authentication unavailable")
        return try {
            val raw = api.get("/watchlist", token); val arr = JSONObject(raw).optJSONArray("tickers") ?: JSONArray();
            val values = (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }.toSet(); setLocalWatchlist(values)
            FetchResult(values, false, System.currentTimeMillis())
        } catch (e: Exception) { FetchResult(localWatchlist(), true, error = e.message) }
    }

    suspend fun addWatchlist(ticker: String): Set<String> {
        val updated = localWatchlist() + ticker.uppercase(); setLocalWatchlist(updated)
        val token = ensureToken(); if (token != null) runCatching { api.post("/watchlist", JSONObject().put("ticker", ticker.uppercase()).toString(), token) }
        return updated
    }

    suspend fun removeWatchlist(ticker: String): Set<String> {
        val updated = localWatchlist() - ticker.uppercase(); setLocalWatchlist(updated)
        val token = ensureToken(); if (token != null) runCatching { api.delete("/watchlist/${ticker.uppercase()}", token) }
        return updated
    }

    suspend fun registerPushToken(tokenValue: String): Boolean {
        val token = ensureToken() ?: return false
        return runCatching { api.post("/alerts/push-token", JSONObject().put("token", tokenValue).put("platform", "android").toString(), token); true }.getOrDefault(false)
    }

    suspend fun saveAlert(ticker: String?, type: String, price: Double? = null, confidence: Int = 75, expectedMove: Double = 3.0): Boolean {
        val token = ensureToken() ?: return false
        val body = JSONObject().put("ticker", ticker).put("alert_type", type).put("enabled", true).put("minimum_confidence", confidence).put("minimum_expected_move_pct", expectedMove)
        if (price != null) body.put("price_threshold", price)
        return runCatching { api.post("/alerts/preferences", body.toString(), token); true }.getOrDefault(false)
    }

    companion object {
        val defaultUniverse = listOf("AAPL", "MSFT", "NVDA", "AMD", "TSLA", "AMZN")
    }
}

private fun demoOverview() = MarketOverview(
    indexes = listOf(IndexRow("SPY", "S&P 500", 0.42), IndexRow("QQQ", "Nasdaq 100", 0.71), IndexRow("DIA", "Dow Jones", 0.18)),
    marketStatus = "DEMO / OFFLINE",
    topGainers = listOf(MarketRow("NVDA", 194.10, 2.7), MarketRow("AAPL", 310.80, 1.2), MarketRow("AMD", 173.20, .9)),
    topLosers = listOf(MarketRow("TSLA", 347.80, -1.8), MarketRow("AMZN", 228.40, -.7)),
    mostActive = listOf(MarketRow("NVDA", 194.10, 2.7, 88_000_000.0), MarketRow("AMD", 173.20, .9, 61_000_000.0)),
    generatedAt = Instant.now().toString(),
)
private fun demoSearch(q: String): List<StockSearchResult> = builtInStockCatalog
    .filter { it.ticker.contains(q, true) || it.company.contains(q, true) }
    .take(25)
private fun demoQuote(ticker: String): Quote {
    val px = mapOf("AAPL" to 313.10, "NVDA" to 194.10, "AMD" to 173.20, "MSFT" to 522.30, "TSLA" to 347.80, "AMZN" to 228.40)[ticker.uppercase()] ?: 100.0
    return Quote(ticker.uppercase(), px, provider = "demo", providerTimestamp = Instant.now().toString(), normalizedTimestamp = Instant.now().toString(), marketSession = "DEMO", freshnessSeconds = 9999.0, dataQuality = DataQuality.STALE, feedScope = "DEMO", feedLabel = "Demo data — not live", consolidated = false)
}
private fun demoChart(ticker: String): List<PriceBar> {
    val base = demoQuote(ticker).price
    return (0 until 30).map { i ->
        val close = base * (0.96 + i * 0.0015 + kotlin.math.sin(i / 3.0) * 0.008)
        PriceBar("D${i + 1}", close * .995, close * 1.01, close * .99, close, 25_000_000.0 + i * 250_000)
    }
}
private fun demoForecast(ticker: String): Forecast {
    val p = demoQuote(ticker).price
    return Forecast(ticker.uppercase(), "demo-hybrid", Instant.now().toString(), p * .96, p * 1.04, p * .96, p * 1.007, p * 1.035, .58, .42, 62.0, "MEDIUM", DataQuality.LIMITED, "Demo forecast shown because the production backend is unreachable. It is not live market analysis.", p, p * .985, p * 1.018, p * 1.006)
}
private fun demoScanner(): ScannerResponse = ScannerResponse("DEMO / OFFLINE", Instant.now().toString(), "Monday", "Friday", MarketRepository.defaultUniverse.mapIndexed { i, s ->
    val p = demoQuote(s).price; val move = listOf(1.5, .8, 2.1, -1.2, -2.0, .4)[i]
    ScannerRow(s, p * .995, p, p * .96, p * (1 + move / 100), p * 1.04, move, move * .8, if (move >= 0) .6 else .38, if (move >= 0) .4 else .62, 55.0 + i, 45.0 + kotlin.math.abs(move) * 8, if (move > 1) "BULLISH" else if (move < -1) "BEARISH" else "NEUTRAL", if (kotlin.math.abs(move) > 1.8) "HIGH" else "MEDIUM", DataQuality.LIMITED, "NASDAQ", if (s in listOf("AAPL","MSFT","NVDA","AMD")) "Technology" else "Consumer", listOf("S&P 500", "Nasdaq"), if (s in listOf("NVDA","AMD")) listOf("Technology","AI","Semiconductors") else if (s in listOf("AAPL","MSFT")) listOf("Technology","AI") else emptyList(), "Mega Cap", true, .25 + i * .03)
})
private fun demoTechnical(ticker: String) = TechnicalReport(ticker.uppercase(), Instant.now().toString(), 62.0, .7, mapOf("RSI" to 56.0, "MACD" to .8, "EMA_20" to 1.0, "EMA_50" to .7, "ATR" to 2.3, "VWAP" to 1.1), listOf("Demo technical evidence"))
private fun demoFundamentals(ticker: String) = FundamentalReport(ticker.uppercase(), Instant.now().toString(), 70.0, "GOOD", .6, mapOf("Revenue Growth" to 8.2, "EPS Growth" to 10.4, "P/E" to 31.0, "Debt/Equity" to 1.2), listOf("Demo fundamentals"), "DEMO")
private fun demoNews(ticker: String) = NewsReport(ticker.uppercase(), Instant.now().toString(), .1, 40.0, 45.0, 15.0, listOf(NewsEvent("Demo news feed unavailable", "Market Insight AI", Instant.now().toString(), 0.0, 0.0)), listOf("Connect production backend for live news"))
private fun demoVerification(ticker: String) = VerificationReport(ticker.uppercase(), Instant.now().toString(), "demo", "DEMO", "Demo data — not live", false, 0.0, 9999.0, DataQuality.LIMITED, .2, listOf("Production market source is unavailable"))
private fun demoAccuracy(ticker: String) = AccuracyReport(ticker.uppercase(), Instant.now().toString(), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0)
