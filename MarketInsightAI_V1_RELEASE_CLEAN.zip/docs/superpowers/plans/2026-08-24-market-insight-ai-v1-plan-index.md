# Market Insight AI V1 Implementation Plan Index

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement these plans task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Sequence the approved V1 specification into independently reviewable, testable execution plans that culminate in a signed Android APK and production backend.

**Architecture:** Implementation proceeds in vertical slices. First prove Android → backend → real/provider-backed quote → chart → forecast → scanner. Then replace the placeholder forecast with the full hybrid engine, expand the Android product surface, and finally productionize streaming, workers, security, notifications, deployment, and release verification.

**Tech Stack:** Kotlin/Jetpack Compose Android client; Python/FastAPI backend; PostgreSQL, Redis, WebSockets, Docker; FCM; production licensed U.S. equity feed behind adapter interface.

**Spec:** `docs/superpowers/specs/2026-08-24-market-insight-ai-v1-design.md`

## Execution Order

1. `docs/superpowers/plans/2026-08-24-market-insight-ai-v1-foundation-vertical-slice.md`
   - Delivers first installable debug APK and end-to-end AAPL path.
2. `docs/superpowers/plans/2026-08-24-market-insight-ai-v1-analysis-prediction.md`
   - Delivers hybrid analysis, confidence/risk, weekly logic, backtesting, calibration.
3. `docs/superpowers/plans/2026-08-24-market-insight-ai-v1-product-features.md`
   - Delivers complete approved Android V1 screens, scanner, cache, watchlist, settings, alerts UX.
4. `docs/superpowers/plans/2026-08-24-market-insight-ai-v1-production-release.md`
   - Delivers streaming, precompute workers, auth/rate limits, FCM, deployment, signed release APK, final verification.

## Cross-Plan Gates

- Do not start Plan 2 until Plan 1's backend and Android automated tests pass and the debug APK builds.
- Do not start Plan 3 until the hybrid forecast API contract is stable and regression-tested.
- Do not start Plan 4 until the Android V1 user-journey test passes against deterministic backend fixtures.
- Do not call V1 ready until Plan 4 device acceptance and `scripts/verify_release.sh` both pass.

## External Inputs Required Before Production Release

These are deployment inputs, not code embedded in the APK:

- Backend hosting destination/domain with HTTPS capability.
- Production U.S. market-data provider credentials and entitlement sufficient for the live/consolidated labeling desired.
- Licensed news-provider credentials if news is enabled in production.
- FRED/other supplemental provider credentials when required by the chosen provider.
- Firebase project/service credentials for push notifications.
- Android release signing keystore and passwords, stored outside source control.

The implementation must remain fully testable without these secrets by using deterministic providers/fixtures. Production acceptance is blocked until the corresponding real credentials are supplied server-side and the live integration checks pass.
