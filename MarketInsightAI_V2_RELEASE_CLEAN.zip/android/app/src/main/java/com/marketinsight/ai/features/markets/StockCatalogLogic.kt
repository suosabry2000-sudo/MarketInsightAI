package com.marketinsight.ai.features.markets

import com.marketinsight.ai.core.model.StockSearchResult

enum class CatalogSort(val label: String, val wireSort: String, val wireDirection: String) {
    PRICE_HIGH_LOW("Price: High → Low", "price", "desc"),
    PRICE_LOW_HIGH("Price: Low → High", "price", "asc"),
    CHANGE_HIGH_LOW("% Change: Highest", "change", "desc"),
    CHANGE_LOW_HIGH("% Change: Lowest", "change", "asc"),
    SYMBOL_A_Z("Symbol: A → Z", "symbol", "asc"),
    SYMBOL_Z_A("Symbol: Z → A", "symbol", "desc"),
}

fun applyCatalogFiltersAndSort(
    stocks: List<StockSearchResult>,
    query: String = "",
    exchange: String? = null,
    sector: String? = null,
    assetType: String? = null,
    sort: CatalogSort = CatalogSort.SYMBOL_A_Z,
): List<StockSearchResult> {
    val needle = query.trim().lowercase()
    val filtered = stocks.asSequence()
        .filter { exchange.isNullOrBlank() || exchange.equals("ALL", true) || it.exchange.equals(exchange, true) }
        .filter { sector.isNullOrBlank() || sector.equals("ALL", true) || it.sector.equals(sector, true) }
        .filter { assetType.isNullOrBlank() || assetType.equals("ALL", true) || it.assetType.equals(assetType, true) }
        .filter { needle.isBlank() || it.ticker.lowercase().contains(needle) || it.company.lowercase().contains(needle) }
        .toList()

    return when (sort) {
        CatalogSort.PRICE_HIGH_LOW -> filtered.sortedWith(
            compareBy<StockSearchResult> { it.price == null }
                .thenByDescending { it.price ?: Double.NEGATIVE_INFINITY }
                .thenBy { it.ticker }
        )
        CatalogSort.PRICE_LOW_HIGH -> filtered.sortedWith(
            compareBy<StockSearchResult> { it.price == null }
                .thenBy { it.price ?: Double.POSITIVE_INFINITY }
                .thenBy { it.ticker }
        )
        CatalogSort.CHANGE_HIGH_LOW -> filtered.sortedWith(
            compareBy<StockSearchResult> { it.changePct == null }
                .thenByDescending { it.changePct ?: Double.NEGATIVE_INFINITY }
                .thenBy { it.ticker }
        )
        CatalogSort.CHANGE_LOW_HIGH -> filtered.sortedWith(
            compareBy<StockSearchResult> { it.changePct == null }
                .thenBy { it.changePct ?: Double.POSITIVE_INFINITY }
                .thenBy { it.ticker }
        )
        CatalogSort.SYMBOL_A_Z -> filtered.sortedBy { it.ticker }
        CatalogSort.SYMBOL_Z_A -> filtered.sortedByDescending { it.ticker }
    }
}

fun filterStockCatalog(
    stocks: List<StockSearchResult>,
    query: String,
    exchange: String? = null,
): List<StockSearchResult> = applyCatalogFiltersAndSort(
    stocks = stocks,
    query = query,
    exchange = exchange,
    sort = CatalogSort.SYMBOL_A_Z,
)
