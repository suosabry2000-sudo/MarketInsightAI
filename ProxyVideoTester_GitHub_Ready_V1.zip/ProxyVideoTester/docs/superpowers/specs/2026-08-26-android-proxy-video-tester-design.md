# Android Proxy Video Tester — V1 Design

Date: 2026-08-26
Status: Approved design direction; ready for implementation planning after user review

## 1. Purpose

Build an Android application that tests real video playback through a user-supplied list of proxy endpoints. The app verifies the externally visible IP address for each proxy, plays a permitted test video for a configured duration, records playback/network quality, then advances to the next endpoint.

The application is a network/video QA tool. It must not contain functionality whose purpose is to manipulate or inflate public engagement metrics on third-party platforms.

## 2. Reference Project

The design is inspired by the control flow of `Bitwise-01/YouTubeViews-`: iterate targets, change network identity, perform a timed operation, and track results. The legacy implementation uses Python, mechanize, and Tor; it is not suitable for a modern Android media app and does not provide proof of real JavaScript/video-player playback.

Reusable concepts:
- endpoint rotation
- current public-IP verification
- sequential job execution
- per-run success/failure counters
- recent-endpoint tracking

Not carried forward:
- artificial visit/view counters
- YouTube/public-engagement automation
- browser fingerprint randomization intended to simulate viewers
- automatic Tor identity rotation for engagement generation

## 3. Recommended Architecture

### Android stack
- Kotlin
- Jetpack Compose UI
- AndroidX lifecycle + ViewModel
- Kotlin coroutines / Flow
- Media3 ExoPlayer for actual video playback
- OkHttp for IP verification, health checks, and HTTP(S) proxy transport where supported
- Room for local endpoint/test history
- DataStore for lightweight settings

### Main modules

#### `ui`
Owns Compose screens and presentation state only.

#### `domain`
Contains test-session rules, queue advancement, validation, result models, and use cases.

#### `network`
Validates proxy configuration, creates per-endpoint network clients, verifies visible public IP, and measures latency/failures.

#### `player`
Wraps Media3 and reports actual player state: prepared, playing, buffering, playback position, ended, or failed.

#### `data`
Persists endpoints, sessions, settings, and exportable results.

This separation keeps the proxy engine independent from the UI and the media player independent from result storage.

## 4. V1 User Flow

1. User enters or imports a direct test-video URL they are authorized to use.
2. User adds proxy endpoints manually or imports them from text.
3. User selects a playback duration, default 60 seconds.
4. App validates endpoint syntax before starting.
5. User presses **Start Test**.
6. For the current endpoint:
   - create an isolated proxy/network configuration;
   - perform a connectivity check;
   - call a public-IP echo endpoint and record the detected address;
   - initialize the player through the selected network path;
   - confirm the player reaches a real `playing` state;
   - accumulate actual playing time, excluding buffering/paused time;
   - stop when the requested played duration is reached or a failure/timeout occurs.
7. Store the result.
8. Release player/network resources.
9. Advance to the next endpoint.
10. At completion, show totals and allow CSV/JSON export.

## 5. Endpoint Model

Each proxy record contains:

- id
- display label (optional)
- host
- port
- type: HTTP or SOCKS (only types actually supported by the selected Android transport path)
- username (optional)
- password (optional, stored using Android secure storage rather than plain Room text)
- enabled
- last detected public IP
- last status
- last latency
- last tested timestamp

V1 will process endpoints sequentially by default. This avoids resource pressure, simplifies isolation, and makes playback measurements easier to interpret.

## 6. Test Result Model

Each endpoint attempt records:

- session ID
- proxy ID
- target URL fingerprint/display value
- started/finished timestamps
- requested watch duration
- actual playing duration
- total wall-clock duration
- detected public IP
- connect latency
- time to first frame / first playback where available
- buffering duration
- buffer event count
- bytes/network stats where available without invasive instrumentation
- final status
- error category
- human-readable error detail

Statuses:
- PASSED
- PROXY_UNREACHABLE
- IP_VERIFY_FAILED
- MEDIA_PREPARE_FAILED
- PLAYBACK_FAILED
- PLAYBACK_TIMEOUT
- USER_CANCELLED

A PASS requires both successful proxy/IP verification and the requested amount of actual playing time.

## 7. Main Screens

### Dashboard
- Video URL
- Watch duration
- Endpoint count
- Start / Stop
- Current endpoint
- Detected IP
- current playback timer
- current state
- Passed / Failed / Remaining counters

### Proxy List
- add single endpoint
- paste/import multiline list
- enable/disable
- test one endpoint
- remove/edit
- validation errors shown inline

### Live Test
- compact player preview
- endpoint identity
- detected IP
- playback progress
- buffering indicator
- latency
- current attempt log
- skip / stop controls

### Results
- filter by passed/failed
- session summary
- endpoint-level metrics
- export CSV
- export JSON

### Settings
- default duration
- connection timeout
- playback startup timeout
- IP-check endpoint
- whether to keep a minimal player preview visible

## 8. Proxy Input Formats

Support these normalized forms in V1:

- `host:port`
- `http://host:port`
- `http://user:pass@host:port`
- `socks5://host:port` only if the selected Media3 networking stack is verified to support it end-to-end

Malformed lines are rejected before the session starts and reported individually.

## 9. Playback Correctness

The legacy reference script equates waiting after an HTTP page load with “watching.” V1 must not do that.

The test timer advances only while Media3 reports active playback. Buffering time does not count toward the requested watch duration. This makes a 60-second test mean 60 seconds of actual media playback.

The app should use a direct MP4/HLS/DASH test stream or another authorized media endpoint that Media3 can play directly.

## 10. Security and Privacy

- Proxy credentials must not appear in logs or exports unless the user explicitly requests credential export.
- Passwords must not be stored as plain text.
- Logs redact credentials and sensitive query parameters.
- TLS certificate validation remains enabled; V1 does not add trust-all-certificate behavior.
- The app does not silently run tests in the background after the user stops a session.

## 11. Error Handling

Each endpoint is isolated. A failure on one endpoint records a result and proceeds to the next unless the user stops the run.

Retries in V1:
- one connectivity retry for transient connection errors
- no automatic repeated playback retries by default

Global stop conditions:
- user cancels
- target media URL is invalid for every endpoint and a preflight direct check proves the media itself is unavailable
- unrecoverable app/player initialization failure

## 12. Testing Strategy

### Unit tests
- endpoint parser
- credential redaction
- queue ordering
- duration accounting
- result status classification
- session state machine

### Instrumentation tests
- Compose form validation
- start/stop behavior
- process recreation where practical
- Room persistence

### Network integration tests
Use controlled test endpoints/proxies where possible:
- valid proxy
- bad credentials
- dead port
- slow proxy
- IP echo timeout
- media startup failure

### Playback tests
- actual 60 seconds of playing time
- buffering pauses the counted watch timer
- media error returns PLAYBACK_FAILED
- stop releases player and connection resources

## 13. V1 Non-Goals

- artificial YouTube/TikTok/Instagram/etc. view generation
- defeating anti-bot or fraud-detection systems
- browser fingerprint spoofing
- account automation
- mass concurrent viewer simulation
- captcha bypass
- ad interaction automation

Load/performance testing against infrastructure owned or explicitly authorized by the user can be designed later as a separate mode with explicit rate and concurrency controls.

## 14. Build and CI

The repository should include:

- Gradle Kotlin DSL
- Android lint
- unit tests
- debug APK build in GitHub Actions
- release build workflow using repository secrets for signing, added only when the user is ready to distribute builds

Initial CI acceptance criteria:

1. `./gradlew test` passes.
2. `./gradlew lint` passes.
3. `./gradlew assembleDebug` passes.
4. Debug APK is uploaded as a GitHub Actions artifact.

## 15. V1 Acceptance Criteria

V1 is complete when:

1. A user can paste/import at least 100 proxy endpoints without losing entries.
2. Invalid endpoints are identified before the run.
3. A valid endpoint can be used to verify its externally visible IP.
4. A permitted test video actually plays through the configured network path.
5. The watch timer counts real playing time rather than wall-clock sleep.
6. Each endpoint receives a deterministic pass/fail result with reason.
7. The app proceeds through the entire enabled endpoint queue.
8. The user can stop safely at any time.
9. Results survive app restart.
10. Results can be exported to CSV and JSON.
11. Unit tests, lint, and debug APK build pass in CI.

## 16. Implementation Direction

Recommended first implementation slice:

1. Android project + Compose shell
2. endpoint parser + Room storage
3. proxy-aware HTTP IP verification
4. Media3 playback wrapper
5. sequential session state machine
6. dashboard/live-result UI
7. persistence/export
8. GitHub Actions APK build

This ordering proves the riskiest technical point—real media playback through the selected proxy transport—before polishing secondary UI features.
