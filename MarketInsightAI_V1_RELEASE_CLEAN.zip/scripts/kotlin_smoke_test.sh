#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/.tmp-kotlin-smoke"
rm -rf "$OUT" && mkdir -p "$OUT"
kotlinc \
  "$ROOT/android/app/src/main/java/com/marketinsight/ai/core/model/Models.kt" \
  "$ROOT/android/app/src/main/java/com/marketinsight/ai/core/state/Freshness.kt" \
  "$ROOT/android/app/src/main/java/com/marketinsight/ai/features/weeklyscanner/ScannerLogic.kt" \
  "$ROOT/android/smoke/SmokeMain.kt" \
  -include-runtime -d "$OUT/smoke.jar"
java -jar "$OUT/smoke.jar"
