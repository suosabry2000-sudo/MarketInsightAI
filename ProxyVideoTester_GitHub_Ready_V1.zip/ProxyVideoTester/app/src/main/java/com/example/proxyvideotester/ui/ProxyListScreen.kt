package com.example.proxyvideotester.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.proxyvideotester.domain.ProxyEndpoint

@Composable
fun ProxyListScreen(
    state: MainUiState,
    onImportTextChange: (String) -> Unit,
    onImport: () -> Unit,
    onToggle: (ProxyEndpoint, Boolean) -> Unit,
    onDelete: (ProxyEndpoint) -> Unit,
    onTestOne: (ProxyEndpoint) -> Unit,
) {
    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("Proxy List")
            Text("Paste one endpoint per line. HTTP is the primary V1 playback path.")
            OutlinedTextField(
                value = state.importText,
                onValueChange = onImportTextChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("host:port or proxy URL") },
                minLines = 4,
                enabled = !state.session.running,
            )
            Button(onClick = onImport, enabled = state.importText.isNotBlank() && !state.session.running) {
                Text("Import Endpoints")
            }
            state.importErrors.take(10).forEach { Text(it) }
        }
        items(state.endpoints, key = { it.id }) { endpoint ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(endpoint.label ?: endpoint.toString())
                            Text("Last IP: ${endpoint.lastDetectedPublicIp ?: "—"}")
                        }
                        Switch(
                            checked = endpoint.enabled,
                            onCheckedChange = { onToggle(endpoint, it) },
                            enabled = !state.session.running,
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onTestOne(endpoint) },
                            enabled = !state.session.running && state.mediaUrlValid && state.durationSeconds != null,
                        ) { Text("Test One") }
                        Button(onClick = { onDelete(endpoint) }, enabled = !state.session.running) {
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }
}
