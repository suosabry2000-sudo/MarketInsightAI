package com.marketinsight.ai.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.DataQuality
import com.marketinsight.ai.core.model.StockSearchResult
import com.marketinsight.ai.core.state.FreshnessState
import java.text.NumberFormat
import java.util.Locale

private val usd = NumberFormat.getCurrencyInstance(Locale.US)
fun money(value: Double): String = if (value.isFinite()) usd.format(value) else "—"
fun moneyOrDash(value: Double?): String = value?.takeIf { it.isFinite() }?.let(::money) ?: "—"
fun pct(value: Double): String = if (value.isFinite()) "%+.2f%%".format(value) else "—"
fun pctOrDash(value: Double?): String = value?.takeIf { it.isFinite() }?.let(::pct) ?: "—"
fun probability(value: Double): String = "%.0f%%".format(if (value <= 1.0) value * 100 else value)

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
fun ModernSectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 0.dp),
    ) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
            content()
        }
    }
}

@Composable
fun MarketPill(text: String, emphasized: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = if (emphasized) MaterialTheme.colorScheme.primary.copy(alpha = .16f) else MaterialTheme.colorScheme.surfaceVariant,
        border = if (emphasized) BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .5f)) else null,
    ) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            style = MaterialTheme.typography.labelMedium,
            color = if (emphasized) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.SemiBold,
        )
    }
}

@Composable
fun ModernStockRow(
    stock: StockSearchResult,
    isWatchlisted: Boolean,
    onToggleWatchlist: () -> Unit,
    onClick: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stock.ticker, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Black)
                    if (stock.exchange.isNotBlank()) MarketPill(stock.exchange)
                    if (stock.assetType.equals("ETF", true)) MarketPill("ETF", emphasized = true)
                }
                Text(
                    stock.company,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                stock.sector?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(moneyOrDash(stock.price), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                val change = stock.changePct
                Text(
                    pctOrDash(change),
                    style = MaterialTheme.typography.labelLarge,
                    color = when {
                        change == null -> MaterialTheme.colorScheme.onSurfaceVariant
                        change >= 0 -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.error
                    },
                    fontWeight = FontWeight.SemiBold,
                )
                IconButton(onClick = onToggleWatchlist, modifier = Modifier.size(30.dp)) {
                    Icon(if (isWatchlisted) Icons.Filled.Star else Icons.Outlined.StarBorder, contentDescription = if (isWatchlisted) "Remove from watchlist" else "Add to watchlist")
                }
            }
        }
    }
}

@Composable
fun StatusBanner(offline: Boolean, demo: Boolean, error: String? = null) {
    if (!offline && !demo) return
    val label = if (demo) "DEMO / OFFLINE — values shown are sample data, not live market prices." else "OFFLINE / CACHED — live status removed until verified data returns."
    Surface(shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(label, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            if (!error.isNullOrBlank()) Text(error.take(180), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun QualityBadge(quality: DataQuality, freshness: FreshnessState? = null) {
    val label = freshness?.name ?: quality.name.replace('_', ' ')
    AssistChip(onClick = {}, label = { Text(label) })
}

@Composable
fun MetricRow(label: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TickerRow(ticker: String, price: Double, changePct: Double? = null, subtitle: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column {
            Text(ticker, fontWeight = FontWeight.Bold)
            if (!subtitle.isNullOrBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(money(price), fontWeight = FontWeight.SemiBold)
            if (changePct != null) Text(pct(changePct), color = if (changePct >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        }
    }
}
