package com.marketinsight.ai.core.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Accent = Color(0xFF00C853)
private val Light = lightColorScheme(
    primary = Accent,
    secondary = Color(0xFF087F23),
    background = Color(0xFFF7F8F9),
    surface = Color.White,
    onPrimary = Color.Black,
    onBackground = Color(0xFF141719),
    onSurface = Color(0xFF141719),
)
private val Dark = darkColorScheme(
    primary = Color(0xFF36E36C),
    secondary = Color(0xFF8AF0A9),
    background = Color(0xFF0D0F10),
    surface = Color(0xFF171A1C),
    onPrimary = Color.Black,
    onBackground = Color(0xFFF1F4F3),
    onSurface = Color(0xFFF1F4F3),
)

@Composable
fun MarketInsightTheme(dark: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
}
