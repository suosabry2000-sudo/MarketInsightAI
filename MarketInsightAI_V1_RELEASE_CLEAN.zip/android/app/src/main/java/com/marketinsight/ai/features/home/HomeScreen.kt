package com.marketinsight.ai.features.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.MarketOverview
import com.marketinsight.ai.core.model.StockSearchResult
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(repository: MarketRepository, onOpenStock: (String) -> Unit, onOpenScanner: () -> Unit) {
    var overview by remember { mutableStateOf<FetchResult<MarketOverview>?>(null) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<StockSearchResult>>(emptyList()) }
    LaunchedEffect(Unit) { overview = repository.marketOverview() }
    LaunchedEffect(query) {
        if (query.isBlank()) { results = emptyList(); return@LaunchedEffect }
        delay(300)
        results = repository.search(query).data.orEmpty()
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Text("Market Insight AI", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            Text("U.S. equities • evidence-first probabilistic forecasts", style = MaterialTheme.typography.bodyMedium)
        }
        item {
            OutlinedTextField(
                value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                label = { Text("Search ticker or company") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
            )
        }
        if (results.isNotEmpty()) {
            item {
                SectionCard("Search Results") {
                    results.take(8).forEach { r -> TickerRow(r.ticker, 0.0, subtitle = r.company) { onOpenStock(r.ticker) } }
                }
            }
        }
        item { StatusBanner(overview?.isOffline == true, overview?.isDemo == true, overview?.error) }
        item {
            Button(onClick = onOpenScanner, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                Text("MON → FRI STOCK LIST", fontWeight = FontWeight.Black)
            }
        }
        item {
            SectionCard("Market Status") {
                Text(overview?.data?.marketStatus ?: "Loading…", fontWeight = FontWeight.Bold)
                Text("Backend session state is authoritative; cached values are never labeled live.", style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SectionCard("Indexes") {
                val indexes = overview?.data?.indexes.orEmpty()
                if (indexes.isEmpty()) Text("Loading S&P 500, Nasdaq and Dow…")
                indexes.forEach { x -> MetricRow("${x.name} (${x.symbol})", pct(x.changePct)) }
            }
        }
        item {
            SectionCard("Top Gainers") {
                overview?.data?.topGainers.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } }
            }
        }
        item {
            SectionCard("Top Losers") {
                overview?.data?.topLosers.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } }
            }
        }
        item {
            SectionCard("Most Active") {
                overview?.data?.mostActive.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } }
            }
        }
        item {
            SectionCard("Watchlist") {
                val watch = repository.localWatchlist()
                if (watch.isEmpty()) Text("Add stocks from a stock page.") else watch.sorted().forEach { ticker ->
                    TextButton(onClick = { onOpenStock(ticker) }) { Text(ticker) }
                }
            }
        }
        item {
            SectionCard("Strongest AI Signals") {
                Text("Open the MON → FRI scanner to rank opportunity by expected move × confidence × data quality × risk adjustment.")
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
