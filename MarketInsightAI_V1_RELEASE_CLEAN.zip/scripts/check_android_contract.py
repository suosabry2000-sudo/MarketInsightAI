from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "android/app/src/main/java/com/marketinsight/ai"
required = {
    "MainActivity.kt": ["MarketInsightApp"],
    "navigation/AppNav.kt": ["MON → FRI STOCK LIST", "Watchlist", "Profile"],
    "core/network/MarketApi.kt": ["/scanner/weekly", "/forecasts/", "/stocks/search", "/auth/device"],
    "core/network/QuoteSocket.kt": ["WebSocket", "subscribe"],
    "data/repository/MarketRepository.kt": ["cache", "watchlist", "ensureToken"],
    "features/home/HomeScreen.kt": ["Top Gainers", "Top Losers", "Most Active"],
    "features/weeklyscanner/WeeklyScannerScreen.kt": ["Monday Ref", "Friday Base", "Confidence"],
    "features/stockdetails/StockDetailsScreen.kt": ["1D", "1W", "1M", "3M", "6M", "1Y", "5Y", "MAX"],
    "features/forecast/ForecastScreen.kt": ["Bear", "Base", "Bull", "Why this forecast?"],
    "features/reports/ReportScreens.kt": ["Technical", "Fundamentals", "News", "Source Verification", "Model Accuracy"],
    "features/watchlist/WatchlistScreen.kt": ["Watchlist"],
    "features/settings/SettingsScreen.kt": ["System", "Light", "Dark", "Disclaimer"],
    "features/alerts/AlertsScreen.kt": ["Price Above", "Signal Change", "Breaking News"],
}
for rel, needles in required.items():
    path = SRC / rel
    assert path.exists(), f"missing {rel}"
    text = path.read_text()
    for needle in needles:
        assert needle in text, f"{rel} missing {needle!r}"
print("Android source contract checks passed")

# Regression: debug cleartext override must be explicit so Android manifest merge
# can override the release-safe main manifest value.
debug_manifest = ROOT / "android/app/src/debug/AndroidManifest.xml"
debug_text = debug_manifest.read_text()
assert 'xmlns:tools="http://schemas.android.com/tools"' in debug_text, "debug manifest missing tools namespace"
assert 'tools:replace="android:usesCleartextTraffic"' in debug_text, "debug manifest must explicitly replace usesCleartextTraffic"
