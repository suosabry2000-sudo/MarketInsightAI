# Market Insight AI V1 Foundation Vertical Slice Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the first end-to-end Android-to-backend slice: themeable APK shell, one real U.S. ticker, live/current quote, chart data, one hybrid forecast response, and one weekly-scanner row.

**Architecture:** A native Kotlin/Jetpack Compose Android client talks only to a Python/FastAPI backend. The backend owns all provider credentials and exposes normalized REST models; provider-specific data is hidden behind adapters. Tests use deterministic fakes while manual integration can use Alpaca market-data credentials supplied only through backend environment variables.

**Tech Stack:** Kotlin, Jetpack Compose, Material 3, MVVM, Retrofit/OkHttp, Room, Coroutines/Flow; Python 3.12, FastAPI, Pydantic v2, pytest, httpx, pandas, numpy; Docker Compose; PostgreSQL and Redis are scaffolded but only Redis quote cache is activated in this slice.

**Spec:** `docs/superpowers/specs/2026-08-24-market-insight-ai-v1-design.md`

## Global Constraints

- Product name: `Market Insight AI`.
- Working Android package name: `com.marketinsight.ai`.
- Market scope: U.S. equities only.
- APK must contain no market-provider secrets, news-provider secrets, database credentials, or backend administration secrets.
- Backend market logic uses `America/New_York` for U.S. exchange sessions.
- Forecasts are probabilistic estimates and must never be presented as guaranteed future prices.
- Cached data must never be labeled `LIVE`.
- Development data may use a lower-cost/single-exchange feed, but the UI must not label it as consolidated U.S. market data.
- All external market sources must sit behind provider adapter interfaces.

---

## File Structure Locked by This Plan

### Backend

- `backend/pyproject.toml` — Python dependencies and pytest configuration.
- `backend/app/main.py` — FastAPI application factory and router registration.
- `backend/app/settings.py` — environment-driven backend configuration.
- `backend/app/domain/models.py` — provider-independent quote/chart/forecast/scanner domain models.
- `backend/app/market_data/provider.py` — `MarketDataProvider` protocol.
- `backend/app/market_data/fake_provider.py` — deterministic test provider.
- `backend/app/market_data/alpaca_provider.py` — development/live U.S. quote and bar adapter.
- `backend/app/market_data/service.py` — normalization, freshness, and provider labeling.
- `backend/app/prediction/simple_hybrid.py` — deterministic V1 vertical-slice forecast implementation.
- `backend/app/api/quotes.py` — quote endpoint.
- `backend/app/api/charts.py` — chart endpoint.
- `backend/app/api/forecasts.py` — forecast endpoint.
- `backend/app/api/scanner.py` — one-row scanner endpoint.
- `backend/tests/...` — unit/API tests.

### Android

- `android/settings.gradle.kts` — project modules.
- `android/build.gradle.kts` — project plugins.
- `android/app/build.gradle.kts` — Android dependencies and build config.
- `android/app/src/main/AndroidManifest.xml` — permissions/application metadata.
- `android/app/src/main/java/com/marketinsight/ai/MainActivity.kt` — root Compose host.
- `android/app/src/main/java/com/marketinsight/ai/core/model/Models.kt` — network/domain DTOs used by first slice.
- `android/app/src/main/java/com/marketinsight/ai/core/network/MarketInsightApi.kt` — Retrofit interface.
- `android/app/src/main/java/com/marketinsight/ai/core/network/ApiModule.kt` — OkHttp/Retrofit construction.
- `android/app/src/main/java/com/marketinsight/ai/core/theme/Theme.kt` — System/Light/Dark theme.
- `android/app/src/main/java/com/marketinsight/ai/features/stock/StockViewModel.kt` — first slice state holder.
- `android/app/src/main/java/com/marketinsight/ai/features/stock/StockScreen.kt` — AAPL quote/chart/forecast UI.
- `android/app/src/main/java/com/marketinsight/ai/features/scanner/WeeklyScannerCard.kt` — scanner row UI.
- `android/app/src/test/...` — JVM tests.
- `android/app/src/androidTest/...` — Compose instrumentation tests.

### Root

- `docker-compose.yml` — backend, Redis, PostgreSQL development services.
- `.env.example` — non-secret variable names only.
- `README.md` — run/build commands and production-data caveat.

---

### Task 1: Backend Application Skeleton and Health Contract

**Files:**
- Create: `backend/pyproject.toml`
- Create: `backend/app/__init__.py`
- Create: `backend/app/main.py`
- Create: `backend/app/settings.py`
- Create: `backend/tests/test_health.py`

**Interfaces:**
- Produces: `create_app() -> FastAPI`
- Produces: `GET /health -> {"status":"ok"}`

- [ ] **Step 1: Write the failing health test**

```python
from fastapi.testclient import TestClient
from app.main import create_app


def test_health_returns_ok():
    client = TestClient(create_app())
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
```

- [ ] **Step 2: Run the isolated test and confirm failure**

Run: `cd backend && python -m pytest tests/test_health.py -v`

Expected: import failure because `app.main` does not exist yet.

- [ ] **Step 3: Add minimal FastAPI app factory and settings**

`backend/app/main.py` must expose exactly:

```python
from fastapi import FastAPI


def create_app() -> FastAPI:
    app = FastAPI(title="Market Insight AI API", version="1.0.0")

    @app.get("/health")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    return app


app = create_app()
```

`backend/app/settings.py` must use Pydantic settings and define these environment names without defaults for secrets: `MARKET_PROVIDER`, `APCA_API_KEY_ID`, `APCA_API_SECRET_KEY`, `ALPACA_DATA_FEED`, `REDIS_URL`, `DATABASE_URL`.

- [ ] **Step 4: Run test and static import check**

Run: `cd backend && python -m pytest tests/test_health.py -v && python -c "from app.main import app; print(app.title)"`

Expected: PASS and `Market Insight AI API`.

- [ ] **Step 5: Commit**

```bash
git add backend
 git commit -m "feat: scaffold market insight backend"
```

---

### Task 2: Provider-Independent Market Models

**Files:**
- Create: `backend/app/domain/models.py`
- Create: `backend/tests/domain/test_models.py`

**Interfaces:**
- Produces: `Quote`, `PriceBar`, `ChartSeries`, `Forecast`, `WeeklyScannerRow`, `DataQuality`.

- [ ] **Step 1: Write model validation tests**

Tests must assert that `Quote(ticker="AAPL", price=310.8, ...)` accepts positive prices, rejects non-positive prices, normalizes ticker to uppercase, and serializes timestamps as ISO-8601. `WeeklyScannerRow` must reject confidence outside `0..100` and probabilities outside `0..1`.

- [ ] **Step 2: Run tests and confirm missing-model failure**

Run: `cd backend && python -m pytest tests/domain/test_models.py -v`

Expected: import failure for `app.domain.models`.

- [ ] **Step 3: Implement exact domain types**

Use Pydantic v2 models with enums:

```python
class DataQuality(str, Enum):
    VERIFIED = "VERIFIED"
    LIMITED = "LIMITED"
    STALE = "STALE"
    DATA_CONFLICT = "DATA_CONFLICT"
    NO_RELIABLE_FORECAST = "NO RELIABLE FORECAST"
```

`Quote` fields: `ticker`, `price`, `currency="USD"`, `provider`, `provider_timestamp`, `normalized_timestamp`, `market_session`, `freshness_seconds`, `data_quality`, `feed_scope`.

`PriceBar` fields: `timestamp`, `open`, `high`, `low`, `close`, `volume`.

`Forecast` fields: `ticker`, `as_of`, `expected_low`, `expected_high`, `bear_target`, `base_target`, `bull_target`, `bull_probability`, `bear_probability`, `confidence`, `risk`, `data_quality`, `explanation`.

`WeeklyScannerRow` fields must match the scanner response shape in section 15 of the spec.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/domain/test_models.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/domain backend/tests/domain
git commit -m "feat: define market domain contracts"
```

---

### Task 3: Market Data Provider Adapter and Deterministic Fake

**Files:**
- Create: `backend/app/market_data/provider.py`
- Create: `backend/app/market_data/fake_provider.py`
- Create: `backend/tests/market_data/test_fake_provider.py`

**Interfaces:**
- Produces protocol:

```python
class MarketDataProvider(Protocol):
    async def get_quote(self, ticker: str) -> Quote: ...
    async def get_bars(self, ticker: str, timeframe: str, limit: int) -> list[PriceBar]: ...
```

- [ ] **Step 1: Write fake-provider tests**

Create a fixture with AAPL price `310.80` and five deterministic minute bars. Assert `get_quote("aapl")` returns ticker `AAPL`, provider `fixture`, and `feed_scope="TEST_FIXTURE"`.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/market_data/test_fake_provider.py -v`

Expected: missing provider modules.

- [ ] **Step 3: Implement protocol and fake provider**

The fake must take fixture data in its constructor and perform no network access.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/market_data/test_fake_provider.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/market_data backend/tests/market_data
git commit -m "feat: add market data provider abstraction"
```

---

### Task 4: Alpaca Development Market Adapter

**Files:**
- Create: `backend/app/market_data/alpaca_provider.py`
- Create: `backend/tests/market_data/test_alpaca_provider.py`
- Modify: `backend/app/settings.py`

**Interfaces:**
- Implements: `MarketDataProvider`.
- Consumes backend-only environment variables: `APCA_API_KEY_ID`, `APCA_API_SECRET_KEY`, `ALPACA_DATA_FEED`.

- [ ] **Step 1: Write transport-mocked adapter tests**

Mock `httpx.AsyncClient` responses for latest quote/trade and bars. Assert the adapter maps them into `Quote`/`PriceBar`, preserves provider timestamps, and marks `feed_scope="IEX_SINGLE_EXCHANGE"` when `ALPACA_DATA_FEED=iex`, `feed_scope="SIP_CONSOLIDATED"` when `sip`.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/market_data/test_alpaca_provider.py -v`

Expected: missing adapter.

- [ ] **Step 3: Implement adapter with injected HTTP client**

Do not log keys. Raise a typed `ProviderUnavailableError` for 5xx/timeouts and `ProviderAuthenticationError` for 401/403. Do not fallback to stale values inside the adapter.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/market_data/test_alpaca_provider.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/market_data/alpaca_provider.py backend/app/settings.py backend/tests/market_data/test_alpaca_provider.py
git commit -m "feat: add alpaca development market adapter"
```

---

### Task 5: Quote Freshness Service and Quote API

**Files:**
- Create: `backend/app/market_data/service.py`
- Create: `backend/app/api/quotes.py`
- Create: `backend/tests/api/test_quotes.py`
- Modify: `backend/app/main.py`

**Interfaces:**
- Produces: `GET /quotes/{ticker}` returning `Quote`.
- Freshness rule for this slice: `<=30s` during OPEN/PRE-MARKET/AFTER HOURS is fresh; older values become `STALE`. CLOSED session may return latest close but must not be marked `LIVE` by the client.

- [ ] **Step 1: Write API tests using dependency override fake**

Cover uppercase normalization, `404/422` for invalid ticker syntax, stale quote labeling, and preservation of `feed_scope`.

- [ ] **Step 2: Run tests and confirm failure**

Run: `cd backend && python -m pytest tests/api/test_quotes.py -v`

Expected: route missing.

- [ ] **Step 3: Implement `MarketDataService` and route**

Ticker validation regex: `^[A-Z][A-Z0-9.\-]{0,9}$` after uppercase normalization. Route returns typed Pydantic response and never exposes provider credentials.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/api/test_quotes.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/market_data/service.py backend/app/api/quotes.py backend/app/main.py backend/tests/api/test_quotes.py
git commit -m "feat: expose normalized quote api"
```

---

### Task 6: Chart API

**Files:**
- Create: `backend/app/api/charts.py`
- Create: `backend/tests/api/test_charts.py`
- Modify: `backend/app/main.py`

**Interfaces:**
- Produces: `GET /charts/{ticker}?range=1D&mode=line`.
- Supported initial ranges: `1D`, `1W`, `1M`, `3M`, `6M`, `1Y`, `5Y`, `MAX`.

- [ ] **Step 1: Write range validation and serialization tests**

Assert `1D` returns ordered bars and unsupported `2D` returns `422`.

- [ ] **Step 2: Run tests and confirm failure**

Run: `cd backend && python -m pytest tests/api/test_charts.py -v`

- [ ] **Step 3: Implement range-to-provider mapping**

Use an explicit mapping table. The route must return timestamps, OHLC, and volume; line/candlestick is a client rendering concern and must not alter raw bars.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/api/test_charts.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/api/charts.py backend/app/main.py backend/tests/api/test_charts.py
git commit -m "feat: add chart data endpoint"
```

---

### Task 7: First Hybrid Forecast Contract

**Files:**
- Create: `backend/app/prediction/simple_hybrid.py`
- Create: `backend/app/api/forecasts.py`
- Create: `backend/tests/prediction/test_simple_hybrid.py`
- Create: `backend/tests/api/test_forecasts.py`
- Modify: `backend/app/main.py`

**Interfaces:**
- Produces: `build_vertical_slice_forecast(ticker: str, quote: Quote, bars: list[PriceBar]) -> Forecast`.
- Produces: `GET /forecasts/{ticker}`.

- [ ] **Step 1: Write deterministic forecast tests**

Use fixed bars. Assert targets satisfy `bear_target <= expected_low <= base_target <= expected_high <= bull_target`, probabilities sum to `1.0 ± 1e-6`, confidence is `0..100`, and stale input cannot produce `VERIFIED` output.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/prediction/test_simple_hybrid.py tests/api/test_forecasts.py -v`

- [ ] **Step 3: Implement minimal transparent vertical-slice model**

Use only historical-bar trend and realized volatility in this slice. Compute log-return mean and standard deviation from available closes; project one session with capped z-scores `-1.5, 0, +1.5`; derive bull probability with a bounded logistic transform of recent mean return. Explanation must explicitly say this is the initial technical/price-only vertical-slice model so the UI does not imply fundamentals/news are active yet.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/prediction/test_simple_hybrid.py tests/api/test_forecasts.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/prediction backend/app/api/forecasts.py backend/app/main.py backend/tests/prediction backend/tests/api/test_forecasts.py
git commit -m "feat: add first transparent forecast response"
```

---

### Task 8: First Weekly Scanner Row

**Files:**
- Create: `backend/app/api/scanner.py`
- Create: `backend/tests/api/test_scanner.py`
- Modify: `backend/app/main.py`

**Interfaces:**
- Produces: `GET /scanner/weekly?tickers=AAPL` with the exact scanner response envelope from the spec.

- [ ] **Step 1: Write scanner response tests**

Assert response has `market_status`, `generated_at`, `reference_session`, `target_session`, and one AAPL row. For the first slice, use a deterministic weekly reference supplied by the fake provider test fixture.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/api/test_scanner.py -v`

- [ ] **Step 3: Implement one-row scanner composition**

Compose quote + forecast. Compute `expected_move_pct=(friday_base-monday_reference)/monday_reference*100` and `expected_move_from_live_pct=(friday_base-live_price)/live_price*100`. Initial opportunity score is a normalized `0..100` score from positive expected return and confidence; the production formula is replaced in the prediction-engine plan.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/api/test_scanner.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/api/scanner.py backend/app/main.py backend/tests/api/test_scanner.py
git commit -m "feat: expose weekly scanner vertical slice"
```

---

### Task 9: Android Project Shell and Theme

**Files:**
- Create: `android/settings.gradle.kts`
- Create: `android/build.gradle.kts`
- Create: `android/app/build.gradle.kts`
- Create: `android/app/src/main/AndroidManifest.xml`
- Create: `android/app/src/main/java/com/marketinsight/ai/MainActivity.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/core/theme/Theme.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/ThemeSmokeTest.kt`

**Interfaces:**
- Produces: installable debug APK package `com.marketinsight.ai`.
- Produces theme enum: `ThemeMode.SYSTEM`, `LIGHT`, `DARK`.

- [ ] **Step 1: Write Compose smoke test**

Test must launch `MainActivity`, assert text `Market Insight AI`, and verify a semantic theme-toggle control exists.

- [ ] **Step 2: Run test and confirm project is not yet buildable**

Run: `cd android && ./gradlew connectedDebugAndroidTest`

Expected: build/setup failure before project files exist.

- [ ] **Step 3: Scaffold minimal Compose app**

Use Material 3 and a top-level `MarketInsightTheme(mode)` with System/Light/Dark. MainActivity should render app name and a temporary stock-content host; do not embed secrets or backend URL literals beyond a local debug default supplied through `BuildConfig`.

- [ ] **Step 4: Build and run tests**

Run: `cd android && ./gradlew testDebugUnitTest assembleDebug`

Expected: PASS and `app/build/outputs/apk/debug/app-debug.apk`.

- [ ] **Step 5: Commit**

```bash
git add android
git commit -m "feat: scaffold android compose shell"
```

---

### Task 10: Android Networking and DTO Parsing

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/core/model/Models.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/core/network/MarketInsightApi.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/core/network/ApiModule.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/core/network/ApiParsingTest.kt`

**Interfaces:**
- Produces Retrofit methods: `getQuote(ticker)`, `getChart(ticker, range)`, `getForecast(ticker)`, `getWeeklyScanner(tickers)`.

- [ ] **Step 1: Write JSON fixture parsing tests**

Fixtures must include quote freshness/data-quality fields and one scanner row matching backend contracts. Assert enum parsing for `VERIFIED`, `STALE`, and `NO RELIABLE FORECAST`.

- [ ] **Step 2: Run and confirm failure**

Run: `cd android && ./gradlew testDebugUnitTest --tests '*ApiParsingTest*'`

- [ ] **Step 3: Implement serializable DTOs and Retrofit interface**

Use Kotlinx Serialization or Moshi consistently. Configure OkHttp timeouts and a debug-only logging interceptor that redacts `Authorization` and never logs backend secrets.

- [ ] **Step 4: Run tests**

Run: `cd android && ./gradlew testDebugUnitTest --tests '*ApiParsingTest*'`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/core android/app/src/test/java/com/marketinsight/ai/core
git commit -m "feat: connect android api contracts"
```

---

### Task 11: Stock Screen Vertical Slice

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/stock/StockViewModel.kt`
- Create: `android/app/src/main/java/com/marketinsight/ai/features/stock/StockScreen.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/stock/StockViewModelTest.kt`
- Create: `android/app/src/androidTest/java/com/marketinsight/ai/features/stock/StockScreenTest.kt`
- Modify: `android/app/src/main/java/com/marketinsight/ai/MainActivity.kt`

**Interfaces:**
- Consumes backend quote/chart/forecast endpoints.
- Produces sealed UI state: `Loading`, `Content`, `OfflineCached`, `Error`.

- [ ] **Step 1: Write ViewModel state tests with fake API**

Assert loading -> content for AAPL, stale quote removes `LIVE` label, and API failure emits explicit error state rather than retaining an unlabeled old quote.

- [ ] **Step 2: Run and confirm failure**

Run: `cd android && ./gradlew testDebugUnitTest --tests '*StockViewModelTest*'`

- [ ] **Step 3: Implement ViewModel and Compose screen**

Screen must show AAPL ticker/company, current price, freshness text, a simple line chart from bars, range selector, bear/base/bull targets, confidence, risk, and the forecast explanation. Use `VERIFIED` + fresh timestamp as the only path to visible `LIVE` badge.

- [ ] **Step 4: Run unit and Compose tests**

Run: `cd android && ./gradlew testDebugUnitTest connectedDebugAndroidTest`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/stock android/app/src/test android/app/src/androidTest android/app/src/main/java/com/marketinsight/ai/MainActivity.kt
git commit -m "feat: render first live stock analysis screen"
```

---

### Task 12: Weekly Scanner Card on Android

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/features/scanner/WeeklyScannerCard.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/features/scanner/WeeklyScannerFormattingTest.kt`
- Modify: `android/app/src/main/java/com/marketinsight/ai/features/stock/StockScreen.kt`

**Interfaces:**
- Consumes `WeeklyScannerRowDto`.
- Produces visible Monday reference, live price, Friday bear/base/bull, expected move, confidence, risk, opportunity score, and signal.

- [ ] **Step 1: Write formatting tests**

Assert positive expected move uses `+` sign, negative uses `-`, confidence is rendered as whole percent, and `STALE`/`DATA CONFLICT` rows show a warning instead of a `LIVE` badge.

- [ ] **Step 2: Run and confirm failure**

Run: `cd android && ./gradlew testDebugUnitTest --tests '*WeeklyScannerFormattingTest*'`

- [ ] **Step 3: Implement card and place it below stock forecast**

Use a horizontally compact card that remains readable at 320dp width. All tap targets must be at least 44dp.

- [ ] **Step 4: Run Android tests and build APK**

Run: `cd android && ./gradlew testDebugUnitTest assembleDebug`

Expected: PASS and debug APK generated.

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/features/scanner android/app/src/test android/app/src/main/java/com/marketinsight/ai/features/stock/StockScreen.kt
git commit -m "feat: show monday to friday scanner row"
```

---

### Task 13: Development Runtime and End-to-End Smoke Test

**Files:**
- Create: `docker-compose.yml`
- Create: `.env.example`
- Create: `backend/tests/integration/test_vertical_slice.py`
- Create: `README.md`

**Interfaces:**
- Produces local backend at `http://localhost:8000`.
- Produces emulator debug backend URL `http://10.0.2.2:8000`.

- [ ] **Step 1: Write integration test against FastAPI app with fake provider**

Test sequence: `/quotes/AAPL` -> `/charts/AAPL` -> `/forecasts/AAPL` -> `/scanner/weekly?tickers=AAPL`; assert the ticker and data-quality state remain consistent across all responses.

- [ ] **Step 2: Run and confirm failure until dependency wiring exists**

Run: `cd backend && python -m pytest tests/integration/test_vertical_slice.py -v`

- [ ] **Step 3: Add provider dependency wiring and Docker development services**

`.env.example` lists variable names only and must contain no usable secret values. README must include exact commands:

```bash
docker compose up -d redis postgres
cd backend && uvicorn app.main:app --reload --port 8000
cd android && ./gradlew assembleDebug
```

Document that live manual testing requires backend-only Alpaca credentials and that `iex` must be labeled single-exchange/development data.

- [ ] **Step 4: Run full slice verification**

Run:

```bash
cd backend && python -m pytest -q
cd ../android && ./gradlew testDebugUnitTest assembleDebug
```

Expected: all tests PASS and debug APK exists.

- [ ] **Step 5: Commit**

```bash
git add docker-compose.yml .env.example README.md backend android
git commit -m "test: verify first end to end market slice"
```

