package com.marketinsight.ai.core.model

enum class DataQuality { VERIFIED, LIMITED, STALE, DATA_CONFLICT, NO_RELIABLE_FORECAST;
    companion object {
        fun fromWire(value: String?): DataQuality = when (value?.uppercase()?.replace(' ', '_')) {
            "VERIFIED" -> VERIFIED
            "LIMITED" -> LIMITED
            "STALE" -> STALE
            "DATA_CONFLICT" -> DATA_CONFLICT
            "NO_RELIABLE_FORECAST" -> NO_RELIABLE_FORECAST
            else -> LIMITED
        }
    }
}

data class Quote(
    val ticker: String,
    val price: Double,
    val currency: String = "USD",
    val provider: String = "",
    val providerTimestamp: String = "",
    val normalizedTimestamp: String = "",
    val marketSession: String = "CLOSED",
    val freshnessSeconds: Double = 0.0,
    val dataQuality: DataQuality = DataQuality.LIMITED,
    val feedScope: String = "",
    val feedLabel: String = "",
    val consolidated: Boolean = false,
)

data class PriceBar(
    val timestamp: String,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
)

data class DailyForecastRow(
    val date: String,
    val low: Double,
    val high: Double,
    val base: Double,
    val bullProbability: Double,
    val confidence: Double,
)

data class Forecast(
    val ticker: String,
    val modelVersion: String = "",
    val asOf: String = "",
    val expectedLow: Double = 0.0,
    val expectedHigh: Double = 0.0,
    val bearTarget: Double = 0.0,
    val baseTarget: Double = 0.0,
    val bullTarget: Double = 0.0,
    val bullProbability: Double = 0.0,
    val bearProbability: Double = 0.0,
    val confidence: Double = 0.0,
    val risk: String = "UNKNOWN",
    val dataQuality: DataQuality = DataQuality.LIMITED,
    val explanation: String = "",
    val tomorrowOpen: Double? = null,
    val tomorrowLow: Double? = null,
    val tomorrowHigh: Double? = null,
    val tomorrowClose: Double? = null,
    val dailyRows: List<DailyForecastRow> = emptyList(),
)

data class ScannerRow(
    val ticker: String,
    val mondayReference: Double,
    val livePrice: Double,
    val fridayBear: Double,
    val fridayBase: Double,
    val fridayBull: Double,
    val expectedMovePct: Double,
    val expectedMoveFromLivePct: Double,
    val bullProbability: Double,
    val bearProbability: Double,
    val confidence: Double,
    val opportunityScore: Double,
    val signal: String,
    val risk: String,
    val dataQuality: DataQuality,
    val exchange: String? = null,
    val sector: String? = null,
    val indexMemberships: List<String> = emptyList(),
    val themes: List<String> = emptyList(),
    val marketCapBucket: String? = null,
    val mostActive: Boolean = false,
    val volatility: Double = 0.0,
)

data class ScannerResponse(
    val marketStatus: String,
    val generatedAt: String,
    val referenceSession: String,
    val targetSession: String,
    val stocks: List<ScannerRow>,
)

data class MarketRow(val ticker: String, val price: Double, val changePct: Double, val volume: Double = 0.0)
data class IndexRow(val symbol: String, val name: String, val changePct: Double)
data class MarketOverview(
    val indexes: List<IndexRow> = emptyList(),
    val marketStatus: String = "CLOSED",
    val topGainers: List<MarketRow> = emptyList(),
    val topLosers: List<MarketRow> = emptyList(),
    val mostActive: List<MarketRow> = emptyList(),
    val generatedAt: String = "",
)

data class StockSearchResult(
    val ticker: String,
    val company: String,
    val exchange: String = "",
    val sector: String? = null,
)

data class TechnicalReport(
    val ticker: String,
    val asOf: String,
    val score: Double,
    val completeness: Double,
    val indicators: Map<String, Double?>,
    val evidence: List<String> = emptyList(),
)

data class FundamentalReport(
    val ticker: String,
    val asOf: String,
    val score: Double,
    val category: String,
    val completeness: Double,
    val metrics: Map<String, Double?>,
    val evidence: List<String> = emptyList(),
    val source: String = "",
)

data class NewsEvent(
    val headline: String,
    val publisher: String = "",
    val publishedAt: String = "",
    val sentiment: Double = 0.0,
    val importance: Double = 0.0,
    val url: String = "",
)

data class NewsReport(
    val ticker: String,
    val asOf: String,
    val sentimentScore: Double,
    val positivePct: Double,
    val neutralPct: Double,
    val negativePct: Double,
    val events: List<NewsEvent> = emptyList(),
    val evidence: List<String> = emptyList(),
)

data class VerificationReport(
    val ticker: String,
    val asOf: String,
    val provider: String,
    val feedScope: String,
    val feedLabel: String,
    val consolidated: Boolean,
    val sourceAgreement: Double,
    val freshnessSeconds: Double,
    val dataQuality: DataQuality,
    val completeness: Double,
    val reasons: List<String> = emptyList(),
)

data class AccuracyReport(
    val ticker: String,
    val generatedAt: String,
    val direction7: Double,
    val direction30: Double,
    val direction90: Double,
    val averageError: Double,
    val medianError: Double,
    val rangeCapture: Double,
    val highConfidenceAccuracy: Double,
    val sampleCount: Int,
)
