package com.marketinsight.ai.features.markets

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.CatalogPage
import com.marketinsight.ai.core.model.MarketOverview
import com.marketinsight.ai.core.model.StockSearchResult
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val exchangeFilters = listOf("ALL", "NASDAQ", "NYSE", "NYSE AMERICAN")
private val typeFilters = listOf("ALL", "STOCK", "ETF")
private val sortOptions = listOf(
    CatalogSort.PRICE_HIGH_LOW,
    CatalogSort.PRICE_LOW_HIGH,
    CatalogSort.CHANGE_HIGH_LOW,
    CatalogSort.CHANGE_LOW_HIGH,
    CatalogSort.SYMBOL_A_Z,
    CatalogSort.SYMBOL_Z_A,
)

@Composable
fun MarketsScreen(repository: MarketRepository, onOpenStock: (String) -> Unit, onOpenScanner: () -> Unit) {
    var overview by remember { mutableStateOf<FetchResult<MarketOverview>?>(null) }
    var pageState by remember { mutableStateOf<FetchResult<CatalogPage>?>(null) }
    var stocks by remember { mutableStateOf<List<StockSearchResult>>(emptyList()) }
    var total by remember { mutableIntStateOf(0) }
    var hasMore by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var exchange by remember { mutableStateOf("ALL") }
    var sector by remember { mutableStateOf("ALL") }
    var assetType by remember { mutableStateOf("ALL") }
    var sort by remember { mutableStateOf(CatalogSort.SYMBOL_A_Z) }
    var sortExpanded by remember { mutableStateOf(false) }
    var loadingMore by remember { mutableStateOf(false) }
    var watchlist by remember { mutableStateOf(repository.localWatchlist()) }
    val scope = rememberCoroutineScope()

    suspend fun loadPage(offset: Int, append: Boolean) {
        if (append) loadingMore = true
        val result = repository.catalogPage(
            offset = offset,
            limit = 80,
            sort = sort,
            query = query,
            exchange = exchange,
            sector = sector,
            assetType = assetType,
        )
        pageState = result
        val page = result.data
        if (page != null) {
            stocks = if (append) (stocks + page.results).distinctBy { it.ticker } else page.results
            total = page.total
            hasMore = page.hasMore
        } else if (!append) {
            stocks = emptyList()
            total = 0
            hasMore = false
        }
        loadingMore = false
    }

    LaunchedEffect(Unit) { overview = repository.marketOverview() }
    LaunchedEffect(query, exchange, sector, assetType, sort) {
        if (query.isNotBlank()) delay(320)
        loadPage(0, append = false)
    }

    val sectors = remember(stocks) {
        listOf("ALL") + stocks.mapNotNull { it.sector?.takeIf(String::isNotBlank) }.distinct().sorted().take(12)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Markets", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Text("All Stocks • broad U.S. listed universe", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                MarketPill(overview?.data?.marketStatus ?: "LOADING", emphasized = true)
            }
        }

        item { StatusBanner(pageState?.isOffline == true || overview?.isOffline == true, pageState?.isDemo == true || overview?.isDemo == true, pageState?.error ?: overview?.error) }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                label = { Text("Search ticker or company") },
                placeholder = { Text("AAPL, gold, Nvidia…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
            )
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("All Stocks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
                    Text("${stocks.size} shown • $total matches", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    OutlinedButton(onClick = { sortExpanded = true }, shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Default.Sort, null)
                        Spacer(Modifier.width(6.dp))
                        Text(sort.label)
                    }
                    DropdownMenu(expanded = sortExpanded, onDismissRequest = { sortExpanded = false }) {
                        sortOptions.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option.label) },
                                onClick = { sort = option; sortExpanded = false },
                                trailingIcon = { if (sort == option) Text("✓", color = MaterialTheme.colorScheme.primary) },
                            )
                        }
                    }
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(end = 8.dp)) {
                items(exchangeFilters) { value ->
                    FilterChip(selected = exchange == value, onClick = { exchange = value }, label = { Text(if (value == "ALL") "All exchanges" else value) })
                }
            }
        }

        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(end = 8.dp)) {
                items(typeFilters) { value ->
                    FilterChip(selected = assetType == value, onClick = { assetType = value }, label = { Text(if (value == "ALL") "Stocks + ETFs" else value) })
                }
            }
        }

        if (sectors.size > 1) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(end = 8.dp)) {
                    items(sectors) { value ->
                        FilterChip(selected = sector == value, onClick = { sector = value }, label = { Text(if (value == "ALL") "All sectors" else value) })
                    }
                }
            }
        }

        item {
            ModernSectionCard("Market movers") {
                val movers = overview?.data?.topGainers.orEmpty().take(3)
                if (movers.isEmpty()) Text("Loading market movers…")
                movers.forEach { row -> TickerRow(row.ticker, row.price, row.changePct) { onOpenStock(row.ticker) } }
                TextButton(onClick = onOpenScanner) { Text("OPEN MON → FRI STOCK SCANNER") }
            }
        }

        if (stocks.isEmpty() && pageState == null) {
            item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        } else if (stocks.isEmpty()) {
            item {
                ModernSectionCard("No matches") {
                    Text("Try a different ticker, company name, exchange, or asset type.")
                }
            }
        }

        items(stocks, key = { it.ticker }) { stock ->
            ModernStockRow(
                stock = stock,
                isWatchlisted = stock.ticker in watchlist,
                onToggleWatchlist = {
                    scope.launch {
                        watchlist = if (stock.ticker in watchlist) repository.removeWatchlist(stock.ticker) else repository.addWatchlist(stock.ticker)
                    }
                },
                onClick = { onOpenStock(stock.ticker) },
            )
        }

        if (hasMore) {
            item {
                Button(
                    onClick = { scope.launch { loadPage(stocks.size, append = true) } },
                    enabled = !loadingMore,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(18.dp),
                ) {
                    if (loadingMore) {
                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("LOAD MORE", fontWeight = FontWeight.Bold)
                }
            }
        }

        item {
            Text(
                "Catalog represents the broad U.S. listed universe available from the connected market source. Exact Robinhood tradability is only shown when authoritative Robinhood tradability evidence is connected.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}
