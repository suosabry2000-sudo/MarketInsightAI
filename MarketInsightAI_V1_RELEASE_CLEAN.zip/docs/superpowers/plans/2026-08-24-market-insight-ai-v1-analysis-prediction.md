# Market Insight AI V1 Analysis and Prediction Engine Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the first-slice price-only forecast with the approved hybrid technical, price/momentum, fundamental, news/sentiment, market/macro, confidence, risk, source-validation, and walk-forward backtesting engine.

**Architecture:** Independent analyzers emit normalized `0..100` scores plus evidence. A hybrid forecaster combines the approved default weights (Technical 35%, Price/Momentum 20%, Fundamental 15%, News/Sentiment 15%, Market/Macro 15%), while data quality, confidence, risk, and forecast direction remain separate concepts. All forecast snapshots persist the feature/model versions required for reproducibility.

**Tech Stack:** Python 3.12, FastAPI, Pydantic v2, numpy, pandas, scikit-learn, SQLAlchemy 2, PostgreSQL, Redis, pytest.

**Spec:** `docs/superpowers/specs/2026-08-24-market-insight-ai-v1-design.md`

## Global Constraints

- Initial model weights: Technical 35%, Price/Momentum 20%, Fundamental 15%, News/Sentiment 15%, Market/Macro 15%.
- Confidence is separate from bullish/bearish direction probability.
- Backtesting is walk-forward and must not access data with timestamps later than the simulated decision time.
- The reference session price is immutable for the week after it is established.
- “Monday → Friday” means first valid U.S. trading session to final valid U.S. trading session.
- Data quality states: VERIFIED, LIMITED, STALE, DATA CONFLICT, NO RELIABLE FORECAST.
- Forecasts may be suspended when source disagreement or data quality breaches thresholds.
- U.S. market calendar calculations use `America/New_York`.

---

## File Structure Locked by This Plan

- `backend/app/analysis/technical.py` — indicator values and technical score.
- `backend/app/analysis/momentum.py` — return, relative strength, trend/momentum score.
- `backend/app/analysis/fundamentals.py` — SEC-normalized financial features and score.
- `backend/app/analysis/sentiment.py` — deduplicated news-event sentiment score.
- `backend/app/analysis/macro.py` — FRED/market-regime score.
- `backend/app/analysis/sector.py` — sector-relative context.
- `backend/app/market_data/source_validator.py` — freshness, agreement, corporate-action, halt checks.
- `backend/app/prediction/hybrid_model.py` — hybrid distribution forecast.
- `backend/app/prediction/confidence.py` — confidence score.
- `backend/app/prediction/risk.py` — risk/event state.
- `backend/app/prediction/weekly_model.py` — weekly reference/final-session logic.
- `backend/app/prediction/calibration.py` — periodic weight calibration.
- `backend/app/backtesting/walk_forward.py` — no-lookahead replay.
- `backend/app/database/models.py` — prediction snapshots/outcomes.
- `backend/app/database/repositories.py` — persistence APIs.
- `backend/tests/...` — deterministic unit/backtest tests.

---

### Task 1: Technical Indicator Engine

**Files:**
- Create: `backend/app/analysis/technical.py`
- Create: `backend/tests/analysis/test_technical.py`

**Interfaces:**
- Produces: `TechnicalAnalysisResult(score: float, indicators: dict[str, float|str], evidence: list[str])`.
- Produces: `analyze_technical(bars: pd.DataFrame) -> TechnicalAnalysisResult`.

- [ ] **Step 1: Write deterministic indicator tests**

Build synthetic increasing, decreasing, and flat OHLCV series. Assert EMA ordering, RSI bounds `0..100`, ATR non-negative, MACD sign for monotonic trends, and overall score bounds `0..100`.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/analysis/test_technical.py -v`

- [ ] **Step 3: Implement RSI, MACD, EMA 9/20/50/200, SMA 20/50/200, VWAP, Bollinger Bands, ATR, ADX, relative volume, momentum, rate of change, support/resistance, gap state, trend structure, 52-week position**

Each indicator contributes through an explicit score table kept in this module. Missing long-window history must reduce completeness rather than fabricate values.

- [ ] **Step 4: Run tests**

Run: `cd backend && python -m pytest tests/analysis/test_technical.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/analysis/technical.py backend/tests/analysis/test_technical.py
git commit -m "feat: add technical analysis engine"
```

---

### Task 2: Price/Momentum and Sector Relative Strength

**Files:**
- Create: `backend/app/analysis/momentum.py`
- Create: `backend/app/analysis/sector.py`
- Create: `backend/tests/analysis/test_momentum_sector.py`

**Interfaces:**
- Produces: `analyze_momentum(stock_bars, market_bars, sector_bars) -> MomentumResult`.

- [ ] **Step 1: Write relative-strength tests**

Create stock +5%, market +2%, sector +3% fixtures and assert positive relative-strength evidence; stock +1% against market +4% must reduce score.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/analysis/test_momentum_sector.py -v`

- [ ] **Step 3: Implement multi-horizon returns and relative-strength scoring**

Use 1d/5d/20d returns, normalized volatility, market-relative and sector-relative returns. Output score `0..100` plus evidence strings.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/analysis/momentum.py backend/app/analysis/sector.py backend/tests/analysis/test_momentum_sector.py
git commit -m "feat: add momentum and sector context"
```

---

### Task 3: Fundamental Normalization and Score

**Files:**
- Create: `backend/app/analysis/fundamentals.py`
- Create: `backend/app/providers/sec_provider.py`
- Create: `backend/tests/analysis/test_fundamentals.py`
- Create: `backend/tests/providers/test_sec_provider.py`

**Interfaces:**
- Produces normalized fields: revenue, revenue_growth, net_income, eps, eps_growth, gross_margin, operating_margin, free_cash_flow, cash, debt, pe, forward_pe, peg, price_to_sales, dividend_yield, buyback_context.
- Produces: `analyze_fundamentals(data) -> FundamentalResult(score, metrics, evidence, completeness)`.

- [ ] **Step 1: Write SEC parser tests from local JSON fixtures**

Fixtures represent companyfacts/submissions responses; tests must verify period selection uses filing/end dates no later than `as_of`.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/analysis/test_fundamentals.py tests/providers/test_sec_provider.py -v`

- [ ] **Step 3: Implement SEC adapter and score rules**

Official filing facts are the verification anchor. Supplemental valuation fields may be `None`; missing values reduce completeness instead of becoming zero.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/analysis/fundamentals.py backend/app/providers/sec_provider.py backend/tests
git commit -m "feat: add sec anchored fundamental analysis"
```

---

### Task 4: News Event Deduplication and Sentiment

**Files:**
- Create: `backend/app/analysis/sentiment.py`
- Create: `backend/app/providers/news_provider.py`
- Create: `backend/tests/analysis/test_sentiment.py`

**Interfaces:**
- Produces: `NewsEvent(id, ticker, headline, publisher, published_at, sentiment, relevance, importance, material, cluster_key)`.
- Produces: `analyze_news(events, as_of) -> SentimentResult`.

- [ ] **Step 1: Write duplicate-event tests**

Three headlines describing the same earnings event must collapse to one cluster contribution. An old low-relevance opinion headline must contribute less than a fresh material earnings headline.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/analysis/test_sentiment.py -v`

- [ ] **Step 3: Implement deterministic V1 classifier pipeline**

Normalize title text, cluster near-duplicates with token similarity, apply provider credibility weight, recency decay, ticker relevance, and event importance. Keep classifier interface pluggable so an NLP model can replace the deterministic rules later.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/analysis/sentiment.py backend/app/providers/news_provider.py backend/tests/analysis/test_sentiment.py
git commit -m "feat: add deduplicated news sentiment"
```

---

### Task 5: Macro and Market Regime Analyzer

**Files:**
- Create: `backend/app/analysis/macro.py`
- Create: `backend/app/providers/fred_provider.py`
- Create: `backend/tests/analysis/test_macro.py`

**Interfaces:**
- Produces regime enum: `STRONG_BULL`, `BULL`, `SIDEWAYS`, `HIGH_VOLATILITY`, `BEAR`, `EXTREME_RISK`.
- Produces `MacroResult(score, regime, evidence)`.

- [ ] **Step 1: Write regime classification tests**

Use fixtures for positive market trend/normal volatility, flat trend, high volatility, and strong negative trend. Assert deterministic regime labels.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/analysis/test_macro.py -v`

- [ ] **Step 3: Implement FRED adapter and regime rules**

Use market index returns/volatility plus configured FRED series values. All time-series reads must select observations with release timestamps available at `as_of` for backtest compatibility.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/analysis/macro.py backend/app/providers/fred_provider.py backend/tests/analysis/test_macro.py
git commit -m "feat: add macro regime analysis"
```

---

### Task 6: Source Validator and Forecast Gate

**Files:**
- Create: `backend/app/market_data/source_validator.py`
- Create: `backend/tests/market_data/test_source_validator.py`

**Interfaces:**
- Produces: `ValidationResult(data_quality, source_agreement, completeness, reasons)`.
- Default thresholds: verified if cross-source price spread `<=0.25%` and required data is fresh; conflict if spread `>1.00%`; `0.25%..1.00%` becomes LIMITED unless another hard failure applies.

- [ ] **Step 1: Write exact threshold tests**

Test 0.10%, 0.25%, 0.60%, 1.00%, and 1.01% spreads; stale timestamps; split flag; halt flag; insufficient history.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/market_data/test_source_validator.py -v`

- [ ] **Step 3: Implement ordered validation checks**

Checks must execute in the spec order: price, timestamp, session, source comparison, corporate actions, split normalization, halt, abnormal values, history completeness, forecast gate.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/market_data/source_validator.py backend/tests/market_data/test_source_validator.py
git commit -m "feat: gate forecasts by source quality"
```

---

### Task 7: Confidence and Risk Engines

**Files:**
- Create: `backend/app/prediction/confidence.py`
- Create: `backend/app/prediction/risk.py`
- Create: `backend/tests/prediction/test_confidence_risk.py`

**Interfaces:**
- `compute_confidence(model_agreement, data_quality, historical_accuracy, source_agreement, market_stability, news_certainty, event_risk, completeness) -> float` in `0..100`.
- `compute_risk(volatility, event_risk, liquidity, data_quality) -> RiskResult`.

- [ ] **Step 1: Write monotonicity tests**

Higher event risk must never increase confidence; worse data quality must never improve risk; identical inputs return identical outputs.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/prediction/test_confidence_risk.py -v`

- [ ] **Step 3: Implement normalized weighted formulas**

Keep weights in named constants and clamp all inputs before combination. Earnings inside horizon must add a `HIGH_EVENT_RISK` reason and reduce confidence.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/prediction/confidence.py backend/app/prediction/risk.py backend/tests/prediction/test_confidence_risk.py
git commit -m "feat: separate confidence and forecast risk"
```

---

### Task 8: Hybrid Forecast Distribution

**Files:**
- Create: `backend/app/prediction/hybrid_model.py`
- Create: `backend/tests/prediction/test_hybrid_model.py`
- Modify: `backend/app/api/forecasts.py`

**Interfaces:**
- Produces: `HybridInputs` containing five component scores and volatility/price context.
- Produces: `forecast(inputs, validation, confidence, risk) -> Forecast`.

- [ ] **Step 1: Write component-weight and output-order tests**

Assert initial normalized score uses exactly `0.35, 0.20, 0.15, 0.15, 0.15`. Assert target order, probability sum, confidence independence, and `DATA CONFLICT` returns `NO RELIABLE FORECAST` or suspended forecast per validator result.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/prediction/test_hybrid_model.py -v`

- [ ] **Step 3: Implement distribution model**

Convert composite directional score to expected return using calibrated bounded mapping, scale scenario width by ATR/realized volatility, and produce bear/base/bull plus expected low/high. Explanation must list positive and negative evidence from all active analyzers.

- [ ] **Step 4: Run tests and API tests**

Run: `cd backend && python -m pytest tests/prediction/test_hybrid_model.py tests/api/test_forecasts.py -v`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/prediction/hybrid_model.py backend/app/api/forecasts.py backend/tests
git commit -m "feat: implement hybrid probability forecast"
```

---

### Task 9: U.S. Trading Calendar and Weekly Reference

**Files:**
- Create: `backend/app/prediction/weekly_model.py`
- Create: `backend/tests/prediction/test_weekly_model.py`

**Interfaces:**
- Produces: `get_week_sessions(date) -> WeeklySessions(reference_session, target_session)`.
- Produces: `establish_reference(first_session_bars) -> float`.
- Reference algorithm: volume-weighted average of valid trades/bars from 09:35 through 09:45 ET; if unavailable, mark LIMITED and use first valid 5-minute bar close after 09:35.

- [ ] **Step 1: Write holiday/early-close/reference tests**

Test Monday holiday -> Tuesday reference, Friday holiday -> prior valid target, early close remains same target date, and reference VWAP ignores 09:30–09:34 opening-auction noise.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/prediction/test_weekly_model.py -v`

- [ ] **Step 3: Implement exchange calendar and immutable reference record**

Use an exchange-calendar dependency that models NYSE sessions. Persist the established reference with session date and algorithm version; later recalculation must reuse it unchanged.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/prediction/weekly_model.py backend/tests/prediction/test_weekly_model.py
git commit -m "feat: add weekly trading session reference"
```

---

### Task 10: Opportunity Score and Scanner Ranking

**Files:**
- Create: `backend/app/prediction/opportunity.py`
- Create: `backend/tests/prediction/test_opportunity.py`
- Modify: `backend/app/api/scanner.py`

**Interfaces:**
- Produces `opportunity_score(expected_return_pct, confidence, data_quality_score, risk_score) -> float` in `0..100`.

- [ ] **Step 1: Write ranking tests**

A +12% forecast at 31% confidence and high risk must rank below +5% at 84% confidence and medium/low risk. Negative-return rows remain rankable for bearish sorts but get low bullish opportunity score.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/prediction/test_opportunity.py tests/api/test_scanner.py -v`

- [ ] **Step 3: Implement normalized opportunity formula and scanner sorting keys**

Normalize expected return through a capped transform, confidence `0..1`, quality `0..1`, and inverse risk `0..1`; multiply then scale `0..100`.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/prediction/opportunity.py backend/app/api/scanner.py backend/tests
git commit -m "feat: rank weekly opportunities by quality"
```

---

### Task 11: Forecast Snapshot Persistence and Outcomes

**Files:**
- Create: `backend/app/database/models.py`
- Create: `backend/app/database/repositories.py`
- Create: `backend/tests/database/test_prediction_repository.py`

**Interfaces:**
- Stores forecast timestamp, as-of timestamp, model version, feature payload/version, targets, probabilities, confidence, validation state, and realized outcome/error when known.

- [ ] **Step 1: Write repository round-trip tests**

Use transactional test database. Assert saved feature JSON and model version round-trip exactly and realized outcomes can be attached without mutating original forecast fields.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/database/test_prediction_repository.py -v`

- [ ] **Step 3: Implement SQLAlchemy models and repository methods**

Expose `save_forecast(snapshot)`, `record_outcome(forecast_id, outcome)`, `get_forecasts(ticker, start, end)`.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/database backend/tests/database
git commit -m "feat: persist reproducible forecasts"
```

---

### Task 12: Walk-Forward Backtesting

**Files:**
- Create: `backend/app/backtesting/walk_forward.py`
- Create: `backend/tests/backtesting/test_walk_forward.py`

**Interfaces:**
- Produces: `run_walk_forward(ticker, decision_times, data_source, model_version) -> BacktestReport`.

- [ ] **Step 1: Write future-leakage sentinel test**

A fake data source raises if queried with a timestamp later than the current simulated `as_of`. Backtest must complete without triggering the sentinel.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/backtesting/test_walk_forward.py -v`

- [ ] **Step 3: Implement replay and metrics**

Compute direction accuracy, mean/median base error, bear/base/bull error, range capture, confidence calibration, and group metrics by stock, sector, regime, confidence bucket.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/backtesting backend/tests/backtesting
git commit -m "feat: add no-lookahead walk forward backtesting"
```

---

### Task 13: Periodic Calibration

**Files:**
- Create: `backend/app/prediction/calibration.py`
- Create: `backend/tests/prediction/test_calibration.py`

**Interfaces:**
- Produces: `calibrate_weights(backtest_rows, prior_weights) -> ModelWeights` with minimum/maximum per-component bounds and sum `1.0`.

- [ ] **Step 1: Write stability tests**

One bad prediction must not materially rewrite weights; sufficient historical samples can move weights within configured bounds; weights always sum to one.

- [ ] **Step 2: Run and confirm failure**

Run: `cd backend && python -m pytest tests/prediction/test_calibration.py -v`

- [ ] **Step 3: Implement regularized calibration**

Fit constrained linear/logistic calibration on historical component scores with L2 regularization and blend new weights with prior weights using sample-size-dependent shrinkage. Persist a new model version only when minimum sample threshold is met.

- [ ] **Step 4: Run tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/prediction/calibration.py backend/tests/prediction/test_calibration.py
git commit -m "feat: calibrate model weights conservatively"
```

---

### Task 14: Full Prediction Regression Suite

**Files:**
- Create: `backend/tests/regression/test_prediction_pipeline.py`

**Interfaces:**
- Verifies all earlier interfaces together.

- [ ] **Step 1: Add fixed regression fixtures for bullish, bearish, earnings-risk, stale, data-conflict, and insufficient-history cases**

Each fixture has expected quality state, signal direction class, target ordering, and confidence band.

- [ ] **Step 2: Run full prediction suite**

Run: `cd backend && python -m pytest tests/analysis tests/market_data tests/prediction tests/backtesting tests/regression -q`

Expected: PASS.

- [ ] **Step 3: Run API suite**

Run: `cd backend && python -m pytest tests/api -q`

Expected: PASS with hybrid engine active.

- [ ] **Step 4: Record model version `hybrid-v1.0` in backend configuration and response metadata**

No forecast response may omit its model version.

- [ ] **Step 5: Commit**

```bash
git add backend
git commit -m "test: lock hybrid v1 prediction regressions"
```
---

### Task 15: Complete Product API Surface

**Files:**
- Create: `backend/app/api/stocks.py`
- Create: `backend/app/api/markets.py`
- Create: `backend/app/api/technical.py`
- Create: `backend/app/api/fundamentals.py`
- Create: `backend/app/api/news.py`
- Create: `backend/app/api/verification.py`
- Create: `backend/app/api/watchlist.py`
- Create: `backend/tests/api/test_product_surface.py`
- Modify: `backend/app/main.py`

**Interfaces:**
- Produces: `GET /stocks/search?q=` and `GET /stocks/{ticker}`.
- Produces: `GET /markets/overview`.
- Produces: `GET /technical/{ticker}`, `GET /fundamentals/{ticker}`, `GET /news/{ticker}`, `GET /verification/{ticker}`.
- Produces: `POST /watchlist` and `DELETE /watchlist/{ticker}`.

- [ ] **Step 1: Write API contract tests for every endpoint**

Use deterministic fixtures. Search must match ticker/company/partial company name; market overview must return S&P 500, Nasdaq, Dow, market status, top gainers, top losers, and most active; analysis endpoints must return analyzer evidence and timestamps; verification must expose source agreement/freshness/data quality; watchlist add/delete must be idempotent for a test principal.

- [ ] **Step 2: Run and confirm missing-route failures**

Run: `cd backend && python -m pytest tests/api/test_product_surface.py -v`

Expected: route failures before implementation.

- [ ] **Step 3: Implement focused routers over existing services/repositories**

`GET /stocks/{ticker}` returns company/exchange metadata plus latest summary metrics. `GET /markets/overview` reads precomputed/cached market lists when available rather than issuing per-request universe scans. Analysis routes call the analyzers created in Tasks 1–8. Watchlist routes resolve a current principal through an injectable dependency so production auth can replace the test/dev principal without changing route logic.

- [ ] **Step 4: Run product API + existing API suites**

Run: `cd backend && python -m pytest tests/api -q`

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/api backend/app/main.py backend/tests/api
git commit -m "feat: expose complete v1 product api"
```

