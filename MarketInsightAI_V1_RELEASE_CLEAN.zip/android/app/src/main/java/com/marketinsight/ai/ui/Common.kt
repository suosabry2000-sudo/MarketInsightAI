package com.marketinsight.ai.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.DataQuality
import com.marketinsight.ai.core.state.FreshnessState
import java.text.NumberFormat
import java.util.Locale

private val usd = NumberFormat.getCurrencyInstance(Locale.US)
fun money(value: Double): String = if (value.isFinite()) usd.format(value) else "—"
fun pct(value: Double): String = if (value.isFinite()) "%+.2f%%".format(value) else "—"
fun probability(value: Double): String = "%.0f%%".format(if (value <= 1.0) value * 100 else value)

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
fun StatusBanner(offline: Boolean, demo: Boolean, error: String? = null) {
    if (!offline && !demo) return
    val label = if (demo) "DEMO / OFFLINE — values shown are sample data, not live market prices." else "OFFLINE / CACHED — live status removed until verified data returns."
    Surface(shape = RoundedCornerShape(12.dp), border = BorderStroke(1.dp, MaterialTheme.colorScheme.error)) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Text(label, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            if (!error.isNullOrBlank()) Text(error.take(180), style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun QualityBadge(quality: DataQuality, freshness: FreshnessState? = null) {
    val label = freshness?.name ?: quality.name.replace('_', ' ')
    AssistChip(onClick = {}, label = { Text(label) })
}

@Composable
fun MetricRow(label: String, value: String, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun TickerRow(ticker: String, price: Double, changePct: Double? = null, subtitle: String? = null, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Column {
            Text(ticker, fontWeight = FontWeight.Bold)
            if (!subtitle.isNullOrBlank()) Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(money(price), fontWeight = FontWeight.SemiBold)
            if (changePct != null) Text(pct(changePct), color = if (changePct >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        }
    }
}
