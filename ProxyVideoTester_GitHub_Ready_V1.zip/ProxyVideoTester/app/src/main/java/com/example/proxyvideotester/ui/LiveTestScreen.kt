package com.example.proxyvideotester.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.ui.PlayerView

@Composable
fun LiveTestScreen(
    state: MainUiState,
    player: Player?,
    onStop: () -> Unit,
) {
    Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Live Test", style = MaterialTheme.typography.headlineMedium)
        if (state.settings.showPlayerPreview && player != null) {
            AndroidView(
                factory = { context -> PlayerView(context).apply { useController = false } },
                update = { it.player = player },
                modifier = Modifier.fillMaxWidth().height(210.dp),
            )
        }
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Endpoint: ${state.currentEndpoint?.toString() ?: "—"}")
                Text("Detected IP: ${state.session.detectedIp ?: "—"}")
                Text("State: ${if (state.session.running) "RUNNING" else "COMPLETE"}")
                val snapshot = state.livePlayback
                Text("Played: ${formatDuration(snapshot?.actualPlayingMs ?: state.session.actualPlayingMs)}")
                Text("Buffering: ${formatDuration(snapshot?.bufferingMs ?: 0)} (${snapshot?.bufferEventCount ?: 0} events)")
                Text("First playback: ${snapshot?.timeToFirstPlaybackMs?.let(::formatDuration) ?: "—"}")
                Text("Passed ${state.session.passed} • Failed ${state.session.failed} • Remaining ${state.session.remaining}")
            }
        }
        if (state.session.running) {
            Button(onClick = onStop) { Text("Stop Session") }
        }
    }
}
