# Market Insight AI V1 Device Acceptance

This record is intentionally **not marked PASS** until a real Android device/emulator installs the compiled release artifact.

- [ ] `adb install -r dist/MarketInsightAI-v1.0.apk`
- [ ] App launches without crash
- [ ] System / Light / Dark themes
- [ ] Search ticker/company
- [ ] Quote/chart ranges 1D/1W/1M/3M/6M/1Y/5Y/MAX
- [ ] MON → FRI scanner filters/sorts
- [ ] Bear/Base/Bull forecast + confidence/risk/data quality
- [ ] Technical/Fundamentals/News/Verification/Accuracy screens
- [ ] Watchlist add/remove and cached state
- [ ] Offline mode shows OFFLINE/CACHED and removes LIVE
- [ ] Backend/feed outage shows explicit failure/stale state
- [ ] Release signature verifies with `apksigner`
- [ ] APK secret scan passes

Record device model, Android version, artifact SHA-256, date, and observed failures before declaring V1 ready.
