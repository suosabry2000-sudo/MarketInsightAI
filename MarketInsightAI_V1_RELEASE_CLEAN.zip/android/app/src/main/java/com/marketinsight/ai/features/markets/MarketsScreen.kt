package com.marketinsight.ai.features.markets

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.MarketOverview
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*

@Composable
fun MarketsScreen(repository: MarketRepository, onOpenStock: (String) -> Unit, onOpenScanner: () -> Unit) {
    var state by remember { mutableStateOf<FetchResult<MarketOverview>?>(null) }
    LaunchedEffect(Unit) { state = repository.marketOverview() }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("U.S. Markets", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
        item { StatusBanner(state?.isOffline == true, state?.isDemo == true, state?.error) }
        item { SectionCard("Top Gainers") { state?.data?.topGainers.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } } } }
        item { SectionCard("Top Losers") { state?.data?.topLosers.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } } } }
        item { SectionCard("Most Active") { state?.data?.mostActive.orEmpty().forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } } } }
        item {
            SectionCard("Discover") {
                listOf("Mega Cap", "Technology", "Financial", "Healthcare", "Energy", "Consumer", "Industrials", "AI Stocks", "Semiconductors").forEach { label ->
                    OutlinedButton(onClick = onOpenScanner, modifier = Modifier.fillMaxWidth()) { Text(label) }
                }
            }
        }
        item { Spacer(Modifier.height(72.dp)) }
    }
}
