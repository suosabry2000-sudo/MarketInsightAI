# Market Insight AI V1 Production Integration and Release Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Productionize Market Insight AI with streaming quotes, precomputed scanner workers, security, rate limiting, notifications, deployment, release signing, secret scanning, and final APK verification.

**Architecture:** Provider streams terminate at the backend, which normalizes and caches live state in Redis, persists durable forecast/history records in PostgreSQL, and serves Android over HTTPS/WSS. Android uses short-lived authentication tokens and FCM push delivery. Production feed configuration must use an entitled consolidated U.S. market source before the app labels data as consolidated/live U.S. market data.

**Tech Stack:** FastAPI, WebSockets, Redis, PostgreSQL, SQLAlchemy, background worker scheduler, Docker, reverse proxy/TLS, Firebase Cloud Messaging, Android R8/ProGuard and Gradle release signing.

**Spec:** `docs/superpowers/specs/2026-08-24-market-insight-ai-v1-design.md`

## Global Constraints

- HTTPS/WSS only in production.
- No provider/database/backend secrets in APK.
- Release APK must be signed.
- Code shrinking/obfuscation enabled where appropriate.
- Logs must not leak secrets.
- Scanner is server-precomputed; opening the Android screen must not trigger thousands of provider requests.
- Live data must include source, provider timestamp, normalized timestamp, market session, freshness, verification state.
- Final output names: `MarketInsightAI-debug.apk` and `MarketInsightAI-v1.0.apk`.

---

## File Structure Locked by This Plan

- `backend/app/live/stream_manager.py` — provider stream lifecycle.
- `backend/app/live/websocket_api.py` — client WebSocket fan-out.
- `backend/app/workers/scanner_worker.py` — periodic scanner precompute.
- `backend/app/workers/news_worker.py` — news/event refresh.
- `backend/app/workers/outcome_worker.py` — realized outcome recording.
- `backend/app/security/auth.py` — token verification/issuance abstraction.
- `backend/app/security/rate_limit.py` — request budgets.
- `backend/app/notifications/fcm.py` — push delivery.
- `backend/app/api/alerts.py` — alert CRUD/token registration.
- `infra/docker-compose.prod.yml` — production service topology.
- `infra/nginx.conf` — HTTPS/WSS reverse proxy.
- `android/app/proguard-rules.pro` — release shrinker rules.
- `android/app/build.gradle.kts` — signing/release config from local/env secrets only.
- `scripts/verify_release.sh` — final build/security/integrity checks.

---

### Task 1: Redis Live-State Cache

**Files:**
- Create: `backend/app/live/cache.py`
- Create: `backend/tests/live/test_cache.py`

**Interfaces:**
- Produces `set_quote`, `get_quote`, `publish_quote`, `set_scanner_snapshot`, `get_scanner_snapshot`.

- [ ] **Step 1: Write TTL/freshness tests**

Assert quote JSON round-trip, scanner snapshot round-trip, and expired quote cannot be returned as fresh.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement Redis-backed cache with explicit TTLs**

Keys include model/provider version where needed; no credentials in values.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add backend/app/live backend/tests/live
git commit -m "feat: add redis live market cache"
```

---

### Task 2: Provider Stream Manager and Backend WebSocket

**Files:**
- Create: `backend/app/live/stream_manager.py`
- Create: `backend/app/live/websocket_api.py`
- Create: `backend/tests/live/test_websocket.py`
- Modify: `backend/app/main.py`

**Interfaces:**
- Produces backend client endpoint `/ws/quotes`.
- Client subscription message: `{"type":"subscribe","tickers":["AAPL","NVDA"]}`.

- [ ] **Step 1: Write WebSocket subscription test**

Connect test client, subscribe to AAPL, publish a fake normalized quote, assert only subscribed client receives it with source/freshness metadata.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement stream fan-out and per-client subscription limits**

Throttle client UI stream to a configurable maximum update rate per ticker while retaining latest quote in Redis.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add backend/app/live backend/app/main.py backend/tests/live
git commit -m "feat: stream normalized quotes to clients"
```

---

### Task 3: Scanner Precompute Worker

**Files:**
- Create: `backend/app/workers/scanner_worker.py`
- Create: `backend/tests/workers/test_scanner_worker.py`
- Modify: `backend/app/api/scanner.py`

**Interfaces:**
- Worker computes eligible U.S. universe in batches and stores one snapshot per filter universe.

- [ ] **Step 1: Write worker batch/cache tests**

Assert API reads cached snapshot and does not call provider per stock on request; assert batch failure preserves previous snapshot as STALE with timestamp.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement scheduled precompute**

During active market sessions refresh live-dependent fields frequently; slower fundamental/news components use their own caches. Exact worker cadence derives from spec refresh policy and is configuration-driven.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add backend/app/workers/scanner_worker.py backend/app/api/scanner.py backend/tests/workers
git commit -m "feat: precompute weekly scanner snapshots"
```

---

### Task 4: Alert API and FCM Delivery

**Files:**
- Create: `backend/app/api/alerts.py`
- Create: `backend/app/notifications/fcm.py`
- Create: `backend/tests/api/test_alerts.py`
- Create: `backend/tests/notifications/test_fcm.py`

**Interfaces:**
- Supports price threshold, signal change, confidence threshold, weekly opportunity, breaking news, earnings approaching.

- [ ] **Step 1: Write alert validation tests**

Reject impossible confidence >100, missing price threshold for price alert, and unsupported alert type.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement alert persistence/evaluation and FCM adapter**

FCM credentials exist only on backend. Push payload includes ticker, alert type, generated timestamp, and navigation target; never includes provider credentials.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add backend/app/api/alerts.py backend/app/notifications backend/tests
git commit -m "feat: deliver stock alerts through fcm"
```

---

### Task 5: Authentication and Rate Limiting

**Files:**
- Create: `backend/app/security/auth.py`
- Create: `backend/app/security/rate_limit.py`
- Create: `backend/tests/security/test_auth_rate_limit.py`

**Interfaces:**
- Produces bearer-token dependency and per-user/per-IP limits.

- [ ] **Step 1: Write unauthorized/expired/rate-limit tests**

Protected watchlist/alerts require valid token; market read endpoints apply anonymous/client limits; 429 responses include retry metadata.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement short-lived signed access token support**

Keep auth provider pluggable; token secrets are environment-only. Redact Authorization header from logs.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add backend/app/security backend/tests/security
git commit -m "feat: secure api with tokens and rate limits"
```

---

### Task 6: Background Outcome and Accuracy Workers

**Files:**
- Create: `backend/app/workers/outcome_worker.py`
- Create: `backend/app/api/accuracy.py`
- Create: `backend/tests/workers/test_outcome_worker.py`
- Create: `backend/tests/api/test_accuracy.py`

**Interfaces:**
- Records realized final-session results and exposes accuracy metrics required by spec.

- [ ] **Step 1: Write realized-outcome tests**

A forecast for a target session cannot be scored before that session ends. After valid close data arrives, direction/base error/range capture are recorded once idempotently.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement worker and accuracy endpoint**

Expose 7/30/90-day direction accuracy, mean/median error, range capture, high-confidence accuracy, and history rows.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add backend/app/workers/outcome_worker.py backend/app/api/accuracy.py backend/tests
git commit -m "feat: record outcomes and model accuracy"
```

---

### Task 7: Android WebSocket Quote Updates

**Files:**
- Create: `android/app/src/main/java/com/marketinsight/ai/core/network/QuoteSocket.kt`
- Create: `android/app/src/test/java/com/marketinsight/ai/core/network/QuoteSocketTest.kt`
- Modify: stock/scanner ViewModels.

**Interfaces:**
- Produces `Flow<QuoteDto>` with reconnection/backoff and subscription control.

- [ ] **Step 1: Write reconnection/throttle tests**

Assert duplicate rapid quotes are coalesced to configured UI rate, last quote wins, and disconnected state removes live status until a fresh quote arrives.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement OkHttp WebSocket client**

Use exponential backoff with cap and lifecycle-aware subscription cleanup.

- [ ] **Step 4: Run tests**

- [ ] **Step 5: Commit**

```bash
git add android/app/src/main/java/com/marketinsight/ai/core/network android/app/src/test android/app/src/main/java/com/marketinsight/ai/features
git commit -m "feat: stream live quotes into android"
```

---

### Task 8: Production Docker/TLS Topology

**Files:**
- Create: `infra/docker-compose.prod.yml`
- Create: `infra/nginx.conf`
- Create: `infra/.env.production.example`
- Create: `backend/tests/integration/test_production_config.py`

**Interfaces:**
- Services: reverse proxy, backend, worker, PostgreSQL, Redis.

- [ ] **Step 1: Write configuration validation test**

Ensure production config rejects missing database URL, Redis URL, token secret, and required provider credentials; ensure example env contains names but no secret values.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement production topology**

Only reverse proxy exposes public ports. Backend/DB/Redis remain on private Docker network. Configure WebSocket upgrade headers and HTTPS redirect.

- [ ] **Step 4: Validate Compose configuration**

Run: `docker compose -f infra/docker-compose.prod.yml config`

Expected: valid configuration.

- [ ] **Step 5: Commit**

```bash
git add infra backend/tests/integration/test_production_config.py
git commit -m "ops: add production deployment topology"
```

---

### Task 9: Android Release Signing and Obfuscation

**Files:**
- Modify: `android/app/build.gradle.kts`
- Create: `android/app/proguard-rules.pro`
- Create: `android/keystore.properties.example`
- Create: `android/app/src/test/java/com/marketinsight/ai/security/NoSecretsTest.kt`

**Interfaces:**
- Produces release artifact `MarketInsightAI-v1.0.apk`.

- [ ] **Step 1: Write APK/resource secret-string test**

Test known environment variable names may appear, but actual runtime secret values supplied through CI must not be found in compiled resources/BuildConfig.

- [ ] **Step 2: Run and confirm current release setup incomplete**

- [ ] **Step 3: Configure release signing from environment/local untracked properties**

Enable `isMinifyEnabled=true`, resource shrinking, and keep serialization/network model rules required for runtime. Never commit `.jks` or passwords.

- [ ] **Step 4: Build release APK with test signing in CI and verify package**

Run: `cd android && ./gradlew clean assembleRelease`

Expected: signed release artifact under `app/build/outputs/apk/release/`.

- [ ] **Step 5: Commit**

```bash
git add android/app/build.gradle.kts android/app/proguard-rules.pro android/keystore.properties.example android/app/src/test
git commit -m "build: harden android release configuration"
```

---

### Task 10: Release Verification Script

**Files:**
- Create: `scripts/verify_release.sh`
- Create: `scripts/check_no_secrets.py`
- Modify: `README.md`

**Interfaces:**
- Produces copied artifacts: `dist/MarketInsightAI-debug.apk`, `dist/MarketInsightAI-v1.0.apk`.

- [ ] **Step 1: Write verification script checks before implementation**

Script must fail on any failed backend test, Android unit test, missing APK, unsigned release, secret scan hit, or APK integrity failure.

- [ ] **Step 2: Implement checks**

Commands include:

```bash
cd backend && python -m pytest -q
cd ../android && ./gradlew testDebugUnitTest assembleDebug assembleRelease
apksigner verify --verbose app/build/outputs/apk/release/app-release.apk
```

Then run Python secret scan against unzipped APK string/resource contents using configured forbidden secret values from environment.

- [ ] **Step 3: Run verification on CI/local Android toolchain**

Expected: all checks PASS.

- [ ] **Step 4: Copy artifacts with final names and checksum them**

Use `sha256sum dist/MarketInsightAI-debug.apk dist/MarketInsightAI-v1.0.apk > dist/SHA256SUMS.txt`.

- [ ] **Step 5: Commit**

```bash
git add scripts README.md
git commit -m "build: add v1 release verification"
```

---

### Task 11: Device Acceptance Test

**Files:**
- Create: `docs/release/v1-device-acceptance.md`

**Interfaces:**
- Verifies the Definition of Success on a real Android device.

- [ ] **Step 1: Install release APK**

Run: `adb install -r dist/MarketInsightAI-v1.0.apk`.

- [ ] **Step 2: Verify theme/search/live/chart/scanner/forecast/watchlist flows**

Record PASS/FAIL for every release-verification item in spec section 23.

- [ ] **Step 3: Verify offline behavior**

Disable network after caching AAPL; confirm OFFLINE/CACHED + last-updated appears and LIVE disappears.

- [ ] **Step 4: Verify backend failure and stale-data states**

Stop backend/feed in controlled test and confirm explicit error states.

- [ ] **Step 5: Commit acceptance record only after all required checks pass**

```bash
git add docs/release/v1-device-acceptance.md
git commit -m "test: record v1 device acceptance"
```

---

### Task 12: Production Data Entitlement Gate

**Files:**
- Create: `backend/app/market_data/feed_entitlement.py`
- Create: `backend/tests/market_data/test_feed_entitlement.py`
- Modify: quote/market metadata response.

**Interfaces:**
- Produces `FeedEntitlement(scope, consolidated, display_label)`.

- [ ] **Step 1: Write labeling tests**

`iex`/single-exchange config must never return display label `Consolidated U.S. market`; entitled SIP config may. Missing entitlement must downgrade label and source-verification metadata.

- [ ] **Step 2: Run and confirm failure**

- [ ] **Step 3: Implement entitlement-aware labels**

The app receives feed scope from backend and displays it in Source Verification.

- [ ] **Step 4: Run backend + Android source-verification tests**

Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/app/market_data/feed_entitlement.py backend/tests android/app/src/main/java/com/marketinsight/ai/features/verification
git commit -m "feat: enforce honest market feed labeling"
```

