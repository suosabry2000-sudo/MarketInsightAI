package com.marketinsight.ai.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.features.alerts.AlertsScreen
import com.marketinsight.ai.features.forecast.ForecastHubScreen
import com.marketinsight.ai.features.forecast.ForecastScreen
import com.marketinsight.ai.features.home.HomeScreen
import com.marketinsight.ai.features.markets.MarketsScreen
import com.marketinsight.ai.features.reports.ReportKind
import com.marketinsight.ai.features.reports.ReportScreen
import com.marketinsight.ai.features.settings.SettingsScreen
import com.marketinsight.ai.features.stockdetails.StockDetailsScreen
import com.marketinsight.ai.features.watchlist.WatchlistScreen
import com.marketinsight.ai.features.weeklyscanner.WeeklyScannerScreen

private data class BottomDestination(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)
private val bottom = listOf(
    BottomDestination("home", "Home", Icons.Default.Home),
    BottomDestination("markets", "Markets", Icons.Default.ShowChart),
    BottomDestination("forecasts", "Forecasts", Icons.Default.Insights),
    BottomDestination("watchlist", "Watchlist", Icons.Default.Star),
    BottomDestination("profile", "Profile", Icons.Default.Person),
)
private const val ScannerLabel = "MON → FRI STOCK LIST"

@Composable
fun MarketInsightApp(repository: MarketRepository, themeMode: String, onThemeChanged: (String) -> Unit) {
    val navController = rememberNavController()
    val entry by navController.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val primary = bottom.map { it.route }.toSet()

    Scaffold(
        bottomBar = {
            if (route in primary) {
                NavigationBar {
                    bottom.forEach { item ->
                        NavigationBarItem(
                            selected = route == item.route,
                            onClick = {
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, item.label) },
                            label = { Text(item.label) },
                        )
                    }
                }
            }
        },
    ) { padding ->
        NavHost(navController, startDestination = "home", modifier = Modifier.padding(padding)) {
            composable("home") { HomeScreen(repository, { navController.navigate("stock/$it") }, { navController.navigate("scanner") }) }
            composable("markets") { MarketsScreen(repository, { navController.navigate("stock/$it") }, { navController.navigate("scanner") }) }
            composable("forecasts") { ForecastHubScreen({ navController.navigate("scanner") }, { navController.navigate("forecast/$it") }) }
            composable("watchlist") { WatchlistScreen(repository) { navController.navigate("stock/$it") } }
            composable("profile") { SettingsScreen(repository, themeMode, onThemeChanged) { navController.navigate("alerts") } }
            composable("scanner") { WeeklyScannerScreen(repository) { navController.navigate("stock/$it") } }
            composable("stock/{ticker}") { back ->
                val ticker = back.arguments?.getString("ticker") ?: "AAPL"
                StockDetailsScreen(
                    ticker, repository,
                    { navController.navigate("forecast/$ticker") },
                    { navController.navigate("technical/$ticker") },
                    { navController.navigate("fundamentals/$ticker") },
                    { navController.navigate("news/$ticker") },
                    { navController.navigate("verification/$ticker") },
                    { navController.navigate("accuracy/$ticker") },
                )
            }
            composable("forecast/{ticker}") { ForecastScreen(it.arguments?.getString("ticker") ?: "AAPL", repository) }
            composable("technical/{ticker}") { ReportScreen(ReportKind.TECHNICAL, it.arguments?.getString("ticker") ?: "AAPL", repository) }
            composable("fundamentals/{ticker}") { ReportScreen(ReportKind.FUNDAMENTALS, it.arguments?.getString("ticker") ?: "AAPL", repository) }
            composable("news/{ticker}") { ReportScreen(ReportKind.NEWS, it.arguments?.getString("ticker") ?: "AAPL", repository) }
            composable("verification/{ticker}") { ReportScreen(ReportKind.VERIFICATION, it.arguments?.getString("ticker") ?: "AAPL", repository) }
            composable("accuracy/{ticker}") { ReportScreen(ReportKind.ACCURACY, it.arguments?.getString("ticker") ?: "AAPL", repository) }
            composable("alerts") { AlertsScreen(repository) }
        }
    }
}
