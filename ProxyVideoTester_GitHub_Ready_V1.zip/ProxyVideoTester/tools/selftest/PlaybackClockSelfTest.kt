import com.example.proxyvideotester.domain.AttemptFacts
import com.example.proxyvideotester.domain.PlaybackClock
import com.example.proxyvideotester.domain.ResultClassifier
import com.example.proxyvideotester.domain.TestStatus

fun main() {
    val clock = PlaybackClock()
    clock.onPlayingChanged(true, 0)
    check(clock.playedMs(20_000) == 20_000L)
    clock.onPlayingChanged(false, 20_000)
    check(clock.playedMs(30_000) == 20_000L)
    clock.onPlayingChanged(true, 30_000)
    check(clock.playedMs(70_000) == 60_000L)

    val passed = ResultClassifier.classify(
        AttemptFacts(
            proxyReachable = true,
            ipVerified = true,
            mediaPrepared = true,
            actualPlayingMs = 60_000,
            requestedPlayingMs = 60_000,
        )
    )
    check(passed == TestStatus.PASSED)

    val timeout = ResultClassifier.classify(
        AttemptFacts(
            proxyReachable = true,
            ipVerified = true,
            mediaPrepared = true,
            actualPlayingMs = 59_999,
            requestedPlayingMs = 60_000,
            timedOut = true,
        )
    )
    check(timeout == TestStatus.PLAYBACK_TIMEOUT)
}
