package com.marketinsight.ai.core.state

import com.marketinsight.ai.core.model.DataQuality

enum class FreshnessState { LIVE, VERIFIED, STALE, OFFLINE, CONFLICT, LIMITED }

fun freshnessState(isOffline: Boolean, ageSeconds: Double, quality: DataQuality): FreshnessState {
    if (isOffline) return FreshnessState.OFFLINE
    return when {
        quality == DataQuality.DATA_CONFLICT || quality == DataQuality.NO_RELIABLE_FORECAST -> FreshnessState.CONFLICT
        quality == DataQuality.STALE || ageSeconds > 120.0 -> FreshnessState.STALE
        quality == DataQuality.LIMITED -> FreshnessState.LIMITED
        ageSeconds <= 15.0 -> FreshnessState.LIVE
        else -> FreshnessState.VERIFIED
    }
}
