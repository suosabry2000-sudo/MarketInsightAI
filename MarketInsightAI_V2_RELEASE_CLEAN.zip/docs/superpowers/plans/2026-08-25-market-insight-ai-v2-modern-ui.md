# Market Insight AI V2 Modern UI Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Modernize Home and Markets while preserving the approved navigation and data-quality semantics.

**Architecture:** Build reusable compact market components in `ui/Common.kt`, then update Home and Markets to use a denser hierarchy and modern surfaces without changing backend contracts.

**Tech Stack:** Kotlin, Jetpack Compose, Material 3.

**Spec:** `docs/superpowers/specs/2026-08-25-market-insight-ai-v2-design.md`

## Global Constraints
- Preserve light/dark theme support.
- Preserve accessibility-friendly contrast and readable text sizes.
- Never label stale/delayed public fallback values as live.

---

### Task 1: Reusable modern components

**Files:**
- Modify: `android/app/src/main/java/com/marketinsight/ai/ui/Common.kt`
- Modify: `android/app/src/main/java/com/marketinsight/ai/core/theme/Theme.kt`

**Interfaces:**
- Produces: compact section container, market pill/badge, modern stock row, headline metric treatment.

- [ ] **Step 1: Add source-contract checks** for modern row and badge helpers.
- [ ] **Step 2: Confirm checks fail**.
- [ ] **Step 3: Implement reusable components and refined color/surface tokens**.
- [ ] **Step 4: Run source-contract and Kotlin checks**.

### Task 2: Home redesign

**Files:**
- Modify: `android/app/src/main/java/com/marketinsight/ai/features/home/HomeScreen.kt`

**Interfaces:**
- Consumes: existing market overview/search/watchlist/scanner.
- Produces: compact header, search, market status/index strip, movers, watchlist, scanner CTA.

- [ ] **Step 1: Add Home V2 source assertions**.
- [ ] **Step 2: Implement Home V2 layout**.
- [ ] **Step 3: Run checks**.

### Task 3: Full release verification

**Files:**
- Modify if needed: `scripts/check_android_contract.py`
- Modify if needed: `README.md`

- [ ] **Step 1: Run backend tests**: `cd backend && python -m pytest -q`.
- [ ] **Step 2: Run Kotlin smoke checks**: `./scripts/kotlin_smoke_test.sh`.
- [ ] **Step 3: Run Android contract checks**: `python scripts/check_android_contract.py`.
- [ ] **Step 4: Run secret scan**: `python scripts/check_no_secrets.py`.
- [ ] **Step 5: Package V2 source ZIP and update GitHub Actions input**.
