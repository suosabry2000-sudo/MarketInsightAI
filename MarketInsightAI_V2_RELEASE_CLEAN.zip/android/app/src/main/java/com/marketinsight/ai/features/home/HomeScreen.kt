package com.marketinsight.ai.features.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.marketinsight.ai.core.model.MarketOverview
import com.marketinsight.ai.core.model.StockSearchResult
import com.marketinsight.ai.data.repository.FetchResult
import com.marketinsight.ai.data.repository.MarketRepository
import com.marketinsight.ai.ui.*
import kotlinx.coroutines.delay

@Composable
fun HomeScreen(
    repository: MarketRepository,
    onOpenStock: (String) -> Unit,
    onOpenScanner: () -> Unit,
    onOpenMarkets: () -> Unit,
) {
    var overview by remember { mutableStateOf<FetchResult<MarketOverview>?>(null) }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<StockSearchResult>>(emptyList()) }

    LaunchedEffect(Unit) { overview = repository.marketOverview() }
    LaunchedEffect(query) {
        if (query.isBlank()) { results = emptyList(); return@LaunchedEffect }
        delay(300)
        results = repository.search(query).data.orEmpty()
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 18.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Text("Market Insight AI", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
                    Text("U.S. markets • forecasts • evidence", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                MarketPill(overview?.data?.marketStatus ?: "LOADING", emphasized = true)
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Search ticker or company") },
                placeholder = { Text("AAPL, gold, Nvidia…") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
            )
        }

        if (results.isNotEmpty()) {
            item {
                ModernSectionCard("Search Results") {
                    results.take(8).forEach { r ->
                        Row(
                            Modifier.fillMaxWidth().clickable { onOpenStock(r.ticker) }.padding(vertical = 7.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(r.ticker, fontWeight = FontWeight.Black)
                                Text(r.company, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            MarketPill(r.exchange.ifBlank { "US" })
                        }
                    }
                }
            }
        }

        item { StatusBanner(overview?.isOffline == true, overview?.isDemo == true, overview?.error) }

        item {
            Button(
                onClick = onOpenScanner,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(20.dp),
            ) {
                Text("MON → FRI STOCK LIST", fontWeight = FontWeight.Black)
            }
        }

        item {
            Text("Market Snapshot", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
            val indexes = overview?.data?.indexes.orEmpty()
            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(indexes, key = { it.symbol }) { index ->
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.width(150.dp),
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(index.symbol, fontWeight = FontWeight.Black)
                            Text(index.name, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                pct(index.changePct),
                                color = if (index.changePct >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                }
            }
        }

        item {
            ModernSectionCard("Top Gainers") {
                val rows = overview?.data?.topGainers.orEmpty().take(5)
                if (rows.isEmpty()) Text("Loading…")
                rows.forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } }
            }
        }

        item {
            ModernSectionCard("Most Active") {
                val rows = overview?.data?.mostActive.orEmpty().take(5)
                if (rows.isEmpty()) Text("Loading…")
                rows.forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } }
            }
        }

        item {
            ModernSectionCard("Watchlist") {
                val watch = repository.localWatchlist().sorted()
                if (watch.isEmpty()) Text("Add stocks from any stock page.")
                watch.take(6).forEach { ticker ->
                    TextButton(onClick = { onOpenStock(ticker) }) { Text(ticker, fontWeight = FontWeight.Bold) }
                }
            }
        }

        item {
            FilledTonalButton(
                onClick = onOpenMarkets,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp),
            ) {
                Text("Explore all stocks", fontWeight = FontWeight.Bold)
            }
        }

        item {
            ModernSectionCard("Top Losers") {
                overview?.data?.topLosers.orEmpty().take(5).forEach { TickerRow(it.ticker, it.price, it.changePct) { onOpenStock(it.ticker) } }
            }
        }
    }
}
