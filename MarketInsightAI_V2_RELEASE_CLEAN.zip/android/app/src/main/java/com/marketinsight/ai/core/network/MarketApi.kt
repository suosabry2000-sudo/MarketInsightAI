package com.marketinsight.ai.core.network

import com.marketinsight.ai.BuildConfig
import com.marketinsight.ai.core.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

class MarketApi(
    baseUrl: String = BuildConfig.API_BASE_URL,
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build(),
) {
    private val root = baseUrl.trimEnd('/')
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun get(path: String, token: String? = null): String = execute(
        Request.Builder().url(root + path).apply { if (!token.isNullOrBlank()) header("Authorization", "Bearer $token") }.get().build()
    )

    suspend fun post(path: String, json: String, token: String? = null): String = execute(
        Request.Builder().url(root + path).apply { if (!token.isNullOrBlank()) header("Authorization", "Bearer $token") }
            .post(json.toRequestBody(jsonType)).build()
    )

    suspend fun delete(path: String, token: String? = null): String = execute(
        Request.Builder().url(root + path).apply { if (!token.isNullOrBlank()) header("Authorization", "Bearer $token") }.delete().build()
    )

    private suspend fun execute(request: Request): String = withContext(Dispatchers.IO) {
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("HTTP ${response.code}: ${body.take(240)}")
            body
        }
    }

    companion object {

        const val SCANNER_WEEKLY = "/scanner/weekly"
        const val FORECASTS = "/forecasts/"
        const val STOCK_SEARCH = "/stocks/search"
        const val DEVICE_AUTH = "/auth/device"
        fun encode(value: String): String = URLEncoder.encode(value, StandardCharsets.UTF_8.toString())

        fun parseQuote(json: JSONObject): Quote = Quote(
            ticker = json.optString("ticker"),
            price = json.optDouble("price"),
            currency = json.optString("currency", "USD"),
            provider = json.optString("provider"),
            providerTimestamp = json.optString("provider_timestamp"),
            normalizedTimestamp = json.optString("normalized_timestamp"),
            marketSession = json.optString("market_session", "CLOSED"),
            freshnessSeconds = json.optDouble("freshness_seconds", 0.0),
            dataQuality = DataQuality.fromWire(json.optString("data_quality")),
            feedScope = json.optString("feed_scope"),
            feedLabel = json.optString("feed_label", json.optString("feed_scope")),
            consolidated = json.optBoolean("consolidated", false),
        )

        fun parseMarketOverview(raw: String): MarketOverview {
            val root = JSONObject(raw)
            fun markets(name: String): List<MarketRow> = root.optJSONArray(name).objects().map {
                MarketRow(it.optString("ticker"), it.optDouble("price"), it.optDouble("change_pct"), it.optDouble("volume", 0.0))
            }
            val indexes = root.optJSONArray("indexes").objects().map {
                IndexRow(it.optString("symbol"), it.optString("name"), it.optDouble("change_pct"))
            }
            return MarketOverview(indexes, root.optString("market_status", "CLOSED"), markets("top_gainers"), markets("top_losers"), markets("most_active"), root.optString("generated_at"))
        }

        private fun parseStockRow(it: JSONObject): StockSearchResult = StockSearchResult(
            ticker = it.optString("ticker"),
            company = it.optString("company"),
            exchange = it.optString("exchange"),
            sector = it.optStringOrNull("sector"),
            assetType = it.optString("asset_type", "STOCK"),
            price = it.optNullableDouble("price"),
            changePct = it.optNullableDouble("change_pct"),
            priceStatus = it.optString("price_status", "UNAVAILABLE"),
            robinhoodVerified = it.optBoolean("robinhood_verified", false),
        )

        fun parseSearch(raw: String): List<StockSearchResult> = JSONObject(raw).optJSONArray("results").objects().map(::parseStockRow)

        fun parseCatalogPage(raw: String): CatalogPage {
            val root = JSONObject(raw)
            return CatalogPage(
                results = root.optJSONArray("results").objects().map(::parseStockRow),
                total = root.optInt("total"),
                offset = root.optInt("offset"),
                limit = root.optInt("limit"),
                hasMore = root.optBoolean("has_more", false),
            )
        }

        fun parseChart(raw: String): List<PriceBar> = JSONObject(raw).optJSONArray("bars").objects().map {
            PriceBar(it.optString("timestamp"), it.optDouble("open"), it.optDouble("high"), it.optDouble("low"), it.optDouble("close"), it.optDouble("volume"))
        }

        fun parseForecast(raw: String): Forecast {
            val o = JSONObject(raw)
            val rows = o.optJSONArray("daily_rows").objects().map {
                DailyForecastRow(it.optString("date"), it.optDouble("low"), it.optDouble("high"), it.optDouble("base"), it.optDouble("bull_probability"), it.optDouble("confidence"))
            }
            return Forecast(
                ticker = o.optString("ticker"), modelVersion = o.optString("model_version"), asOf = o.optString("as_of"),
                expectedLow = o.optDouble("expected_low"), expectedHigh = o.optDouble("expected_high"), bearTarget = o.optDouble("bear_target"),
                baseTarget = o.optDouble("base_target"), bullTarget = o.optDouble("bull_target"), bullProbability = o.optDouble("bull_probability"),
                bearProbability = o.optDouble("bear_probability"), confidence = o.optDouble("confidence"), risk = o.optString("risk", "UNKNOWN"),
                dataQuality = DataQuality.fromWire(o.optString("data_quality")), explanation = o.optString("explanation"),
                tomorrowOpen = o.optNullableDouble("tomorrow_open"), tomorrowLow = o.optNullableDouble("tomorrow_low"), tomorrowHigh = o.optNullableDouble("tomorrow_high"), tomorrowClose = o.optNullableDouble("tomorrow_close"),
                dailyRows = rows,
            )
        }

        fun parseScanner(raw: String): ScannerResponse {
            val o = JSONObject(raw)
            val rows = o.optJSONArray("stocks").objects().map { x ->
                ScannerRow(
                    ticker = x.optString("ticker"), mondayReference = x.optDouble("monday_reference"), livePrice = x.optDouble("live_price"),
                    fridayBear = x.optDouble("friday_bear"), fridayBase = x.optDouble("friday_base"), fridayBull = x.optDouble("friday_bull"),
                    expectedMovePct = x.optDouble("expected_move_pct"), expectedMoveFromLivePct = x.optDouble("expected_move_from_live_pct"),
                    bullProbability = x.optDouble("bull_probability"), bearProbability = x.optDouble("bear_probability"), confidence = x.optDouble("confidence"),
                    opportunityScore = x.optDouble("opportunity_score"), signal = x.optString("signal"), risk = x.optString("risk"),
                    dataQuality = DataQuality.fromWire(x.optString("data_quality")), exchange = x.optStringOrNull("exchange"), sector = x.optStringOrNull("sector"),
                    indexMemberships = x.optJSONArray("index_memberships").strings(), themes = x.optJSONArray("themes").strings(), marketCapBucket = x.optStringOrNull("market_cap_bucket"),
                    mostActive = x.optBoolean("most_active", false), volatility = x.optDouble("volatility", 0.0),
                )
            }
            return ScannerResponse(o.optString("market_status", "CLOSED"), o.optString("generated_at"), o.optString("reference_session"), o.optString("target_session"), rows)
        }

        fun parseTechnical(raw: String): TechnicalReport {
            val o = JSONObject(raw)
            return TechnicalReport(o.optString("ticker"), o.optString("as_of"), o.optDouble("score"), o.optDouble("completeness"), o.optJSONObject("indicators").doubleMap(), o.optJSONArray("evidence").strings())
        }

        fun parseFundamentals(raw: String): FundamentalReport {
            val o = JSONObject(raw)
            return FundamentalReport(o.optString("ticker"), o.optString("as_of"), o.optDouble("score"), o.optString("category"), o.optDouble("completeness"), o.optJSONObject("metrics").doubleMap(), o.optJSONArray("evidence").strings(), o.optString("source"))
        }

        fun parseNews(raw: String): NewsReport {
            val o = JSONObject(raw); val split = o.optJSONObject("sentiment_split") ?: JSONObject()
            val events = o.optJSONArray("events").objects().map { x ->
                NewsEvent(x.optString("headline"), x.optString("publisher"), x.optString("published_at"), x.optDouble("sentiment"), x.optDouble("importance"), x.optString("url"))
            }
            return NewsReport(o.optString("ticker"), o.optString("as_of"), o.optDouble("sentiment_score"), split.optDouble("positive"), split.optDouble("neutral"), split.optDouble("negative"), events, o.optJSONArray("evidence").strings())
        }

        fun parseVerification(raw: String): VerificationReport {
            val o = JSONObject(raw)
            return VerificationReport(o.optString("ticker"), o.optString("as_of"), o.optString("provider"), o.optString("feed_scope"), o.optString("feed_label"), o.optBoolean("consolidated"), o.optDouble("source_agreement"), o.optDouble("freshness_seconds"), DataQuality.fromWire(o.optString("data_quality")), o.optDouble("completeness"), o.optJSONArray("reasons").strings())
        }

        fun parseAccuracy(raw: String): AccuracyReport {
            val o = JSONObject(raw)
            return AccuracyReport(o.optString("ticker"), o.optString("generated_at"), o.optDouble("direction_accuracy_7d"), o.optDouble("direction_accuracy_30d"), o.optDouble("direction_accuracy_90d"), o.optDouble("average_target_error_pct"), o.optDouble("median_target_error_pct"), o.optDouble("range_capture_pct"), o.optDouble("high_confidence_accuracy_pct"), o.optInt("sample_count"))
        }
    }
}

private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).mapNotNull { optJSONObject(it) }
private fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else (0 until length()).mapNotNull { optString(it).takeIf(String::isNotBlank) }
private fun JSONObject?.doubleMap(): Map<String, Double?> {
    if (this == null) return emptyMap()
    return keys().asSequence().associateWith { key -> if (isNull(key)) null else optDouble(key).takeUnless { it.isNaN() } }
}
private fun JSONObject.optStringOrNull(name: String): String? = if (isNull(name)) null else optString(name).takeIf { it.isNotBlank() }
private fun JSONObject.optNullableDouble(name: String): Double? = if (isNull(name) || !has(name)) null else optDouble(name).takeUnless { it.isNaN() }
