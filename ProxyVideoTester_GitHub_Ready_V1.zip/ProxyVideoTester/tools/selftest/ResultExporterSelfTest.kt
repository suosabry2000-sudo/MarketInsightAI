import com.example.proxyvideotester.domain.EndpointTestResult
import com.example.proxyvideotester.domain.TestStatus
import com.example.proxyvideotester.export.ExportRecord
import com.example.proxyvideotester.export.ResultExporter

fun main() {
    val result = EndpointTestResult(
        id = "r1", sessionId = "s1", proxyId = "p1",
        targetDisplay = "https://example.test/video.mp4?token=secret",
        startedAtEpochMs = 1, finishedAtEpochMs = 2,
        requestedWatchMs = 60_000, actualPlayingMs = 60_000, wallClockMs = 65_000,
        detectedPublicIp = "203.0.113.1", connectLatencyMs = 15,
        timeToFirstPlaybackMs = 500, bufferingMs = 4_500, bufferEventCount = 1,
        status = TestStatus.PASSED, errorDetail = null,
    )
    val record = ExportRecord("http://sam@proxy.example:8080", result.copy(targetDisplay = ResultExporter.redactUrl(result.targetDisplay)))
    val csv = ResultExporter.toCsv(listOf(record))
    val json = ResultExporter.toJson(listOf(record))
    check("secret" !in csv)
    check("secret" !in json)
    check("?redacted" in csv)
    check("PASSED" in json)
    check(ResultExporter.redactUrl("https://example.test/a?token=123#x") == "https://example.test/a?redacted")
}
