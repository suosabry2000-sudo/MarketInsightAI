# Market Insight AI V1

Native Android + FastAPI research app for U.S. equities. The app presents live/cached market data, a Monday→Friday stock scanner, probabilistic bear/base/bull forecasts, technical/fundamental/news evidence, source verification, watchlists, alerts, and historical model-accuracy metrics.

## Safety and forecast semantics

Forecasts are probabilistic estimates, not guaranteed prices, returns, or trading instructions. The Android client explicitly removes `LIVE` labeling when data is stale/offline and falls back to clearly labeled demo data when no production backend is reachable.

## Backend

```bash
cd backend
python -m pip install -e '.[dev]'
uvicorn app.main:app --reload
```

Development defaults to the deterministic fake provider. Production requires the environment names documented in `infra/.env.production.example`. Provider/database/token secrets stay on the server and must never be embedded in the APK.

## Android development

The Android app uses Kotlin, Jetpack Compose, Material 3, OkHttp WebSockets, local cache/preferences, and Firebase Messaging integration. Debug builds talk to `http://10.0.2.2:8000/` from the Android emulator.

```bash
cd android
gradle testDebugUnitTest assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Release build

Release endpoints come from `MARKET_INSIGHT_API_BASE_URL` and `MARKET_INSIGHT_WS_BASE_URL`. Signing comes only from environment variables or an untracked `keystore.properties` file.

```bash
./scripts/verify_release.sh
```

A successful release verification produces:

- `dist/MarketInsightAI-debug.apk`
- `dist/MarketInsightAI-v1.0.apk`
- `dist/SHA256SUMS.txt`

GitHub Actions workflow `.github/workflows/android-release.yml` installs Gradle 8.9 + Android SDK, runs backend and Android tests, generates an installable CI signing key, builds both APKs, verifies the release signature, scans the APK for configured forbidden secret values, and uploads the artifacts.

## Production deployment

`infra/docker-compose.prod.yml` defines a reverse proxy, FastAPI backend, worker, PostgreSQL, and Redis. Only the reverse proxy publishes host ports. TLS certificates are mounted into `infra/certs` at deployment time.
