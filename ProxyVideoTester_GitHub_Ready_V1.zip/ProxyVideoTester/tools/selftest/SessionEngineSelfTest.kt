import com.example.proxyvideotester.domain.*
import kotlinx.coroutines.runBlocking

fun main() = runBlocking {
    val attempted = mutableListOf<String>()
    val engine = TestSessionEngine(
        ipCheck = IpCheckPort { ep ->
            attempted += ep.host
            if (ep.host == "bad") IpCheckOutcome(false, false, error = "dead")
            else IpCheckOutcome(true, true, ip = "203.0.113.1", latencyMs = 10)
        },
        playback = PlaybackPort { _, _, requested, _ ->
            PlaybackOutcome(true, requested, requested, 100, 0, 0)
        },
        nowEpochMs = { 1000L },
    )
    val results = engine.run(
        TestSessionRequest(
            mediaUrl = "https://example.test/video.mp4",
            targetDisplay = "https://example.test/video.mp4",
            requestedPlayingMs = 60_000,
            endpoints = listOf(
                ProxyEndpoint(host = "one", port = 8080),
                ProxyEndpoint(host = "bad", port = 8080),
                ProxyEndpoint(host = "three", port = 8080),
            )
        )
    )
    check(attempted == listOf("one", "bad", "three"))
    check(results.map { it.status } == listOf(TestStatus.PASSED, TestStatus.PROXY_UNREACHABLE, TestStatus.PASSED))

    lateinit var stopEngine: TestSessionEngine
    var stopPlayCalls = 0
    stopEngine = TestSessionEngine(
        ipCheck = IpCheckPort { IpCheckOutcome(true, true, ip = "203.0.113.2") },
        playback = PlaybackPort { _, _, _, shouldStop ->
            stopPlayCalls += 1
            stopEngine.requestStop()
            check(shouldStop())
            PlaybackOutcome(true, 1_000, 1_000, 100, 0, 0, cancelled = true)
        },
        nowEpochMs = { 2000L },
    )
    val stopped = stopEngine.run(
        TestSessionRequest(
            mediaUrl = "https://example.test/video.mp4",
            targetDisplay = "https://example.test/video.mp4",
            requestedPlayingMs = 60_000,
            endpoints = listOf(
                ProxyEndpoint(host = "stop-one", port = 8080),
                ProxyEndpoint(host = "stop-two", port = 8080),
            )
        )
    )
    check(stopPlayCalls == 1)
    check(stopped.size == 1)
    check(stopped.single().status == TestStatus.USER_CANCELLED)

    var retryCalls = 0
    val retryEngine = TestSessionEngine(
        ipCheck = IpCheckPort {
            retryCalls += 1
            if (retryCalls == 1) IpCheckOutcome(false, false, error = "temporary", retryable = true)
            else IpCheckOutcome(true, true, ip = "203.0.113.3")
        },
        playback = PlaybackPort { _, _, requested, _ -> PlaybackOutcome(true, requested, requested, 50, 0, 0) },
        nowEpochMs = { 3000L },
    )
    val retried = retryEngine.run(
        TestSessionRequest(
            mediaUrl = "https://example.test/video.mp4",
            targetDisplay = "https://example.test/video.mp4",
            requestedPlayingMs = 60_000,
            endpoints = listOf(ProxyEndpoint(host = "retry", port = 8080)),
        )
    )
    check(retryCalls == 2)
    check(retried.single().status == TestStatus.PASSED)
}

