package com.example.proxyvideotester.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.proxyvideotester.domain.TestStatus

enum class ResultFilter { ALL, PASSED, FAILED }

@Composable
fun ResultsScreen(
    state: MainUiState,
    onExportCsv: () -> String,
    onExportJson: () -> String,
    onClear: () -> Unit,
) {
    val context = LocalContext.current
    var filter by remember { mutableStateOf(ResultFilter.ALL) }
    var pendingCsv by remember { mutableStateOf("") }
    var pendingJson by remember { mutableStateOf("") }
    val csvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri: Uri? ->
        if (uri != null) context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingCsv) }
    }
    val jsonLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingJson) }
    }

    val visible = state.results.filter {
        when (filter) {
            ResultFilter.ALL -> true
            ResultFilter.PASSED -> it.status == TestStatus.PASSED
            ResultFilter.FAILED -> it.status != TestStatus.PASSED
        }
    }

    LazyColumn(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        item {
            Text("Results")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ResultFilter.entries.forEach { option ->
                    FilterChip(selected = filter == option, onClick = { filter = option }, label = { Text(option.name) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(onClick = {
                    pendingCsv = onExportCsv()
                    csvLauncher.launch("proxy-video-results.csv")
                }, enabled = state.results.isNotEmpty()) { Text("Export CSV") }
                Button(onClick = {
                    pendingJson = onExportJson()
                    jsonLauncher.launch("proxy-video-results.json")
                }, enabled = state.results.isNotEmpty()) { Text("Export JSON") }
                Button(onClick = onClear, enabled = state.results.isNotEmpty() && !state.session.running) { Text("Clear") }
            }
        }
        items(visible, key = { it.id }) { result ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("${result.status} • ${result.detectedPublicIp ?: "No IP"}")
                    Text("Played ${formatDuration(result.actualPlayingMs)} / ${formatDuration(result.requestedWatchMs)}")
                    Text("Wall ${formatDuration(result.wallClockMs)} • Buffer ${formatDuration(result.bufferingMs)}")
                    Text("Latency ${result.connectLatencyMs?.let { "$it ms" } ?: "—"}")
                    result.errorDetail?.let { Text(it) }
                }
            }
        }
    }
}
