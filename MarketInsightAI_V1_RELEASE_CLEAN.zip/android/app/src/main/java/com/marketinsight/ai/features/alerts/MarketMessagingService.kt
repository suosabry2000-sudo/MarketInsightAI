package com.marketinsight.ai.features.alerts

import com.google.firebase.messaging.FirebaseMessagingService
import com.marketinsight.ai.data.repository.MarketRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class MarketMessagingService : FirebaseMessagingService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        scope.launch { MarketRepository(applicationContext).registerPushToken(token) }
    }
}
