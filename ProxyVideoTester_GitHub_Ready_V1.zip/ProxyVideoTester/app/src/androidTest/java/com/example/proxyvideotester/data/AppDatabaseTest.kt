package com.example.proxyvideotester.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.proxyvideotester.domain.TestStatus
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AppDatabaseTest {
    private lateinit var db: AppDatabase

    @Before fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).build()
    }

    @After fun close() = db.close()

    @Test fun endpointAndResultRoundTrip() = runBlocking {
        db.proxyDao().upsert(
            ProxyEndpointEntity(
                id = "p1", label = "Local", host = "127.0.0.1", port = 8080,
                type = "HTTP", username = null, enabled = true,
                lastDetectedPublicIp = null, lastStatus = null, lastLatencyMs = null,
                lastTestedAtEpochMs = null,
            )
        )
        db.resultDao().insert(
            EndpointResultEntity(
                id = "r1", sessionId = "s1", proxyId = "p1", targetDisplay = "https://example.test/video.mp4",
                startedAtEpochMs = 1, finishedAtEpochMs = 2, requestedWatchMs = 60_000,
                actualPlayingMs = 60_000, wallClockMs = 65_000, detectedPublicIp = "203.0.113.1",
                connectLatencyMs = 10, timeToFirstPlaybackMs = 500, bufferingMs = 4_500,
                bufferEventCount = 1, status = TestStatus.PASSED.name, errorDetail = null,
            )
        )
        assertEquals("127.0.0.1", db.proxyDao().getById("p1")?.host)
        assertEquals(TestStatus.PASSED.name, db.resultDao().listForSession("s1").single().status)
    }
}
