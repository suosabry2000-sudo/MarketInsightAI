import com.example.proxyvideotester.player.PlaybackStateAccumulator

fun main() {
    val a = PlaybackStateAccumulator(startedAtMs = 0)
    a.onPrepared(1_000)
    a.onPlayingChanged(true, 2_000)
    check(a.snapshot(22_000).actualPlayingMs == 20_000L)
    a.onBufferingChanged(true, 22_000)
    a.onPlayingChanged(false, 22_000)
    check(a.snapshot(32_000).actualPlayingMs == 20_000L)
    a.onBufferingChanged(false, 32_000)
    a.onPlayingChanged(true, 32_000)
    val s = a.snapshot(72_000)
    check(s.actualPlayingMs == 60_000L)
    check(s.bufferingMs == 10_000L)
    check(s.bufferEventCount == 1)
    check(s.timeToFirstPlaybackMs == 2_000L)
    check(s.mediaPrepared)
}
