package com.marketinsight.ai.core.state

import com.marketinsight.ai.core.model.DataQuality
import org.junit.Assert.assertEquals
import org.junit.Test

class FreshnessTest {
    @Test fun offline_never_appears_live() = assertEquals(FreshnessState.OFFLINE, freshnessState(true, 0.0, DataQuality.VERIFIED))
    @Test fun stale_age_is_stale() = assertEquals(FreshnessState.STALE, freshnessState(false, 121.0, DataQuality.VERIFIED))
    @Test fun conflict_overrides_freshness() = assertEquals(FreshnessState.CONFLICT, freshnessState(false, 0.0, DataQuality.DATA_CONFLICT))
}
