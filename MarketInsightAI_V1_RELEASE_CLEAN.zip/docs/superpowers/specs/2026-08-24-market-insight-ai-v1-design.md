# Market Insight AI V1 — Technical Design Specification

**Date:** 2026-08-24  
**Status:** Approved design, pending implementation plan  
**Target:** Android APK + secure backend  
**Market scope:** U.S. equities only (NYSE/Nasdaq-listed stocks and major U.S. equity indexes/benchmarks)

## 1. Product Goal

Market Insight AI is a native Android stock-analysis application that combines live U.S. equity prices, historical market data, technical analysis, fundamentals, financial news sentiment, macro conditions, sector context, and a hybrid forecast engine. The app's primary differentiator is a transparent Monday-to-Friday stock scanner that records a first-trading-session reference price and continuously estimates the final trading session's bear/base/bull outcomes, expected move, confidence, and risk.

The app must present forecasts as probabilistic estimates, never guaranteed future prices. Confidence, data freshness, source agreement, event risk, and historical model performance are first-class user-visible concepts.

## 2. V1 Scope

### Included

- U.S. stocks only.
- Live/near-real-time U.S. equity prices.
- Search by ticker, company name, and partial company name.
- Intraday and historical price charts.
- Light and dark themes.
- Home market dashboard.
- Watchlist.
- Top gainers, top losers, and most active stocks.
- Monday-to-Friday stock list/scanner.
- First-trading-session weekly reference price.
- Current live price.
- Friday/final-session bear, base, and bull targets.
- Expected percent move.
- Confidence score.
- Opportunity score.
- Technical analysis.
- Fundamental analysis.
- News sentiment.
- Macro analysis.
- Sector and market-relative analysis.
- Tomorrow forecast.
- Monday-to-Friday forecast.
- Human-readable forecast explanation.
- Source verification and data-conflict protection.
- Earnings/event-risk warnings.
- Historical forecast tracking.
- Model accuracy reporting.
- Price, signal, and event alerts.
- Offline/cached viewing with explicit stale-data labeling.
- Filters and sorting for scanner lists.

### Excluded from V1

- Crypto.
- Forex.
- Options.
- Brokerage order execution.
- Automated trading.
- International equities.
- Portfolio optimization.
- Social/community features.

## 3. UX and Visual Design

The UI is a native Android application using Kotlin and Jetpack Compose.

### Theme

Two complete themes are required:

- **Light:** white surfaces, restrained green accents, clean high-contrast typography.
- **Dark:** charcoal/black surfaces, green highlights, readable neutral secondary text.

The user can choose System, Light, or Dark in Settings.

### Primary navigation

Bottom navigation contains:

1. Home
2. Markets
3. Forecasts
4. Watchlist
5. Profile

### Home screen

Displays:

- Search bar.
- S&P 500, Nasdaq, and Dow status cards.
- Market session state: PRE-MARKET, OPEN, AFTER HOURS, CLOSED.
- Top gainers.
- Top losers.
- Most active.
- Watchlist preview.
- Strongest AI signals.
- Prominent **MON → FRI STOCK LIST** button.

### Stock details

Displays:

- Ticker and company name.
- Exchange/market metadata.
- Live/current price.
- Daily percent and dollar change.
- After-hours/pre-market change when available.
- Price chart with 1D, 1W, 1M, 3M, 6M, 1Y, 5Y, MAX.
- Line and candlestick modes.
- Volume overlay/section.
- Open, high, low, previous close, market cap, volume, average volume, 52-week high/low.
- Add/remove watchlist.
- Analyze action.

### Forecast screen

Displays:

- Tomorrow expected open, low, high, close.
- Direction probability.
- Confidence.
- Bear, base, and bull target prices.
- Monday-to-Friday day-by-day forecast.
- Final-session bear/base/bull targets.
- Risk and event warnings.
- “Why this forecast?” explanation.

### Monday → Friday stock list/scanner

This is a dedicated high-value feature.

Each row/card shows:

- Ticker/company.
- Monday/first-session reference price.
- Current live price.
- Friday/final-session bear target.
- Friday/final-session base target.
- Friday/final-session bull target.
- Expected move from weekly reference.
- Expected move from current live price.
- Bull probability.
- Bear probability.
- Confidence.
- Risk.
- Opportunity score.
- Signal label.

Filters:

- All U.S.
- S&P 500.
- Nasdaq.
- Dow.
- Technology.
- AI.
- Semiconductors.
- Mega Cap.
- Most Active.
- Watchlist.

Sorts:

- Best Opportunity.
- Highest Expected Gain.
- Highest Expected Drop.
- Highest Confidence.
- Strongest Bullish.
- Strongest Bearish.
- Lowest Risk.
- Highest Volatility.
- Ticker A–Z.

Tapping a stock opens its complete analysis.

### Technical analysis screen

Includes:

- Overall Technical Score, 0–100.
- RSI.
- MACD.
- EMA 9/20/50/200.
- SMA 20/50/200.
- VWAP.
- Bollinger Bands.
- ATR.
- ADX.
- Volume and relative volume.
- Momentum.
- Rate of change.
- Support/resistance.
- Gap state.
- Trend structure.
- 52-week position.

### Fundamental analysis screen

Includes:

- Fundamental Score, 0–100.
- Revenue and growth.
- Net income.
- EPS and EPS growth.
- Gross margin.
- Operating margin.
- Free cash flow.
- Cash.
- Debt.
- P/E.
- Forward P/E.
- PEG.
- Price-to-sales.
- Dividend metrics.
- Buyback context where available.

Each metric is categorized as Strong, Good, Neutral, or Weak.

### News and sentiment screen

Includes:

- Positive/neutral/negative sentiment split.
- Overall sentiment.
- Headline.
- Publisher.
- Timestamp.
- Sentiment label.
- Importance score.
- Relevance score.
- Material-forecast-impact flag.

Duplicate articles about the same event are grouped to avoid over-counting.

### Source verification screen

Shows separately:

- Price-data agreement.
- Analyst/reference-data agreement.
- Financial statement verification.
- SEC filing status.
- News-source verification.
- Macro-data verification.
- Freshness.

If source disagreement exceeds tolerance, the app reduces confidence or suspends the forecast.

### Model accuracy screen

Displays:

- 7-day, 30-day, and 90-day directional accuracy.
- Average target error.
- Median target error.
- Range-capture rate.
- Accuracy for high-confidence forecasts.
- Per-stock performance.
- Historical prediction versus actual outcome.

### Settings

- Theme.
- Default chart type.
- Default forecast period.
- Notification settings.
- Confidence threshold.
- Minimum expected move threshold.
- Watchlist management.
- Data refresh behavior.
- Privacy/about/disclaimer.

## 4. System Architecture

### Android client

Recommended stack:

- Kotlin.
- Jetpack Compose.
- Material 3.
- MVVM.
- Retrofit/OkHttp.
- WebSocket client.
- Room local database/cache.
- Kotlin Coroutines/Flow.
- WorkManager.
- Firebase Cloud Messaging for push notifications.

The APK contains no market-provider secrets, database credentials, or backend administration secrets.

### Backend

Recommended stack:

- Python.
- FastAPI.
- Pydantic.
- NumPy.
- Pandas.
- scikit-learn for V1 model components.
- PostgreSQL.
- Redis.
- WebSockets.
- Background workers.
- Docker.

### Backend modules

```text
MarketInsightBackend/
├── api/
│   ├── stocks
│   ├── quotes
│   ├── charts
│   ├── forecasts
│   ├── scanner
│   ├── news
│   ├── fundamentals
│   └── alerts
├── market_data/
│   ├── live_feed
│   ├── historical
│   └── source_validator
├── analysis/
│   ├── technical
│   ├── momentum
│   ├── fundamentals
│   ├── sentiment
│   ├── macro
│   └── sector
├── prediction/
│   ├── hybrid_model
│   ├── weekly_model
│   ├── confidence
│   ├── risk
│   └── calibration
├── backtesting/
├── workers/
├── database/
└── tests/
```

### Android modules

```text
MarketInsightAndroid/
├── app/
├── core/
│   ├── network/
│   ├── database/
│   ├── models/
│   ├── theme/
│   └── utils/
├── features/
│   ├── home/
│   ├── markets/
│   ├── stockdetails/
│   ├── charts/
│   ├── forecast/
│   ├── weeklyscanner/
│   ├── technical/
│   ├── fundamentals/
│   ├── news/
│   ├── verification/
│   ├── watchlist/
│   ├── alerts/
│   ├── accuracy/
│   └── settings/
└── data/
    ├── api/
    ├── repository/
    └── cache/
```

## 5. Data Sources

### Live and historical prices

Production should use a properly licensed consolidated U.S. equity feed. The architecture must support provider substitution behind an adapter interface.

Development may use a lower-cost feed, but the UI must never label single-exchange data as consolidated U.S. market data.

### Fundamentals

Use official SEC EDGAR/data.sec.gov filing and XBRL data as the authoritative source where available. Supplemental provider data may be used for convenience, but official filing data remains the verification anchor.

### Macro

Use official Federal Reserve/FRED series for rates, inflation, yields, unemployment, GDP, and related macro signals.

### News

Use licensed/reliable financial news feeds. The backend normalizes, deduplicates, timestamps, scores relevance, and classifies sentiment and importance.

### Source abstraction

Every external source is hidden behind a provider adapter so vendors can be changed without rewriting application logic.

## 6. Live Data Flow

```text
Market provider WebSocket
        ↓
Backend live-feed adapter
        ↓
Normalization and validation
        ↓
Redis latest-state cache
        ↓
Backend WebSocket/API
        ↓
Android application
```

The Android UI must throttle extremely frequent updates to maintain smooth rendering.

Each live data item includes:

- source.
- provider timestamp.
- normalized timestamp.
- market session.
- freshness status.
- verification state.

## 7. Refresh Policy

- Live price: streaming/near-real-time.
- Bid/ask: streaming when entitlement provides it.
- Intraday chart: live/minute bars.
- Volume: live.
- Technical indicators: approximately every minute or when a new bar is complete.
- Market Insight score: approximately every 1–5 minutes and on material events.
- Weekly forecast: periodic recalculation plus event-driven recalculation.
- Weekly scanner: continuously refreshed/precomputed during active market sessions.
- News: frequent/event-driven.
- Fundamentals: on filing/data change.
- SEC filings: periodic and new-filing detection.
- Macro: around official releases and scheduled refreshes.
- Model performance/backtesting: scheduled worker jobs.

## 8. Hybrid Prediction Model

The V1 forecast engine combines five major score families:

- Technical: 35%.
- Price/Momentum: 20%.
- Fundamental: 15%.
- News/Sentiment: 15%.
- Market/Macro: 15%.

These are initial defaults, not immutable constants. Backtesting may later calibrate weights by sector, volatility profile, and market regime.

### Technical feature set

- RSI.
- MACD.
- EMA 9/20/50/200.
- SMA 20/50/200.
- VWAP.
- Bollinger Bands.
- ATR.
- ADX.
- Volume.
- Relative volume.
- Momentum.
- Rate of change.
- Support/resistance.
- Price gaps.
- Trend structure.
- 52-week position.

### Fundamental feature set

- Revenue and growth.
- EPS and growth.
- Net income.
- Margins.
- Free cash flow.
- Cash/debt.
- Valuation multiples.
- Dividend/buyback context.

### News feature set

- Sentiment.
- Recency.
- Source credibility.
- Ticker relevance.
- Event type.
- Materiality.
- Duplicate-event collapse.

### Market/macro feature set

- Nasdaq/S&P direction.
- Sector benchmark movement.
- Relative strength versus market/sector.
- Interest-rate/yield signals.
- Inflation and macro regime.
- Volatility regime.

## 9. Monday-to-Friday Forecast Logic

“Monday → Friday” means **first valid U.S. trading session of the week → final valid U.S. trading session of the week**.

If Monday is a market holiday, Tuesday becomes the reference session. If Friday is a holiday, Thursday or the final valid session becomes the target.

At the first trading session the backend stores:

- session date.
- opening price.
- opening/high/low context.
- reference price.
- volume context.
- market regime.
- sector regime.
- source quality.
- initial forecast timestamp.

The reference price is intentionally separate from the exact first print to avoid making the forecast hinge on opening-auction noise. The implementation plan will define the exact reference algorithm, with a default candidate of a short stabilized opening window or representative early-session price.

During the week:

- the reference price remains immutable for that week.
- live price updates continuously.
- bear/base/bull targets are recalculated.
- expected move from reference is recalculated.
- expected move from current price is recalculated.
- confidence and risk update as new information arrives.

### Output distribution

The model returns:

- Expected low.
- Expected high.
- Bear target.
- Base target.
- Bull target.
- Bull probability.
- Bear probability.
- Expected return.
- Confidence.
- Risk.

The product never presents the base target as guaranteed.

## 10. Opportunity Score

The scanner should not rank stocks only by raw expected return.

Conceptually:

```text
Opportunity Score = Expected Return × Confidence × Data Quality × Risk Adjustment
```

The implementation must normalize components before combination so the score is stable and comparable across stocks.

A high expected return with poor confidence or poor source quality should rank below a smaller but more reliable opportunity.

## 11. Confidence Model

Confidence is separate from direction probability.

Inputs include:

- Model agreement.
- Data quality.
- Historical model accuracy.
- Source agreement.
- Market stability.
- News certainty.
- Event risk.
- Data completeness.

A stock can be “Bullish 75%” while having only “Confidence 58%”; the UI must not conflate the two.

## 12. Risk and Event Handling

### Earnings

Earnings inside the forecast horizon reduce confidence and raise event risk. The forecast remains available unless data quality becomes insufficient, but the UI displays a high-event-risk warning.

### Trading halts

Live forecasting pauses during a confirmed halt. Cached forecast values are marked stale/paused.

### Splits/reverse splits

Historical data must be split-adjusted or otherwise normalized so a corporate action is not misinterpreted as a market crash/rally.

### Corporate actions

Material actions should trigger a forecast recalculation and/or event-risk state.

### Market regime

The system classifies broad conditions such as:

- Strong Bull.
- Bull.
- Sideways.
- High Volatility.
- Bear.
- Extreme Risk.

Forecast weighting can vary by regime.

## 13. Source Validation and Data Quality

Before forecasting:

1. Verify latest price.
2. Verify timestamp/freshness.
3. Verify market session.
4. Compare available sources.
5. Check corporate actions.
6. Check split normalization.
7. Check trading halt state.
8. Check abnormal/corrupt values.
9. Check minimum history/data completeness.
10. Generate forecast only if quality thresholds are satisfied.

Possible states:

- VERIFIED.
- LIMITED.
- STALE.
- DATA CONFLICT.
- NO RELIABLE FORECAST.

Minimum behavior:

- Data quality below threshold: no standard forecast.
- Material source disagreement: suspend or sharply reduce confidence.
- Insufficient history: limited forecast state.

## 14. Backtesting and Calibration

Backtesting must be walk-forward and free of look-ahead bias.

For every historical forecast point:

1. Freeze time at that historical timestamp.
2. Load only data that was available then.
3. Generate forecast.
4. Compare with actual subsequent outcome.

Metrics:

- Direction accuracy.
- Average price error.
- Median price error.
- Bear/base/bull target error.
- High/low range capture.
- Confidence calibration.
- Performance by stock.
- Performance by sector.
- Performance by market regime.
- Performance by confidence bucket.

Every live forecast stores:

- forecast timestamp.
- all input feature values/versions needed for reproducibility.
- model version.
- targets.
- probability/confidence.
- actual realized outcome when known.
- error metrics.

Weights are recalibrated periodically, not after every individual miss, to reduce overfitting.

## 15. API Design

Representative endpoints:

```text
GET /stocks/search?q=
GET /stocks/{ticker}
GET /quotes/{ticker}
GET /charts/{ticker}
GET /forecasts/{ticker}
GET /scanner/weekly
GET /news/{ticker}
GET /fundamentals/{ticker}
GET /verification/{ticker}
GET /accuracy/{ticker}
GET /markets/overview
POST /watchlist
DELETE /watchlist/{ticker}
POST /alerts
DELETE /alerts/{id}
```

### Weekly scanner response shape

```json
{
  "market_status": "OPEN",
  "generated_at": "ISO-8601 timestamp",
  "reference_session": "YYYY-MM-DD",
  "target_session": "YYYY-MM-DD",
  "stocks": [
    {
      "ticker": "AAPL",
      "monday_reference": 0.0,
      "live_price": 0.0,
      "friday_bear": 0.0,
      "friday_base": 0.0,
      "friday_bull": 0.0,
      "expected_move_pct": 0.0,
      "expected_move_from_live_pct": 0.0,
      "bull_probability": 0.0,
      "bear_probability": 0.0,
      "confidence": 0.0,
      "opportunity_score": 0.0,
      "signal": "BULLISH",
      "risk": "MEDIUM",
      "data_quality": "VERIFIED"
    }
  ]
}
```

## 16. Persistence and Caching

### PostgreSQL

Stores:

- Stock master data.
- Company metadata.
- Historical candles/bars as retained by licensing rules.
- Predictions.
- Prediction inputs/version metadata.
- Prediction outcomes.
- Technical/fundamental/news/macro scores.
- Model performance.
- Users.
- Watchlists.
- Alert definitions.

### Redis

Stores fast-changing state:

- Latest prices.
- Current market status.
- Current scanner rankings.
- Latest forecasts.
- WebSocket/session state.
- Short-lived API caches.

The scanner is precomputed on the server; opening the Android screen must not trigger thousands of provider requests.

## 17. Notifications

Supported V1 alert types:

- Price above threshold.
- Price below threshold.
- AI signal change.
- Confidence above threshold.
- Weekly opportunity threshold reached.
- Major breaking news.
- Earnings approaching.

Settings include:

- Enable/disable alert categories.
- Minimum confidence.
- Minimum expected move.

Push delivery uses Firebase Cloud Messaging.

## 18. Offline and Stale Data Behavior

When offline:

- Previously cached stock pages remain viewable.
- Previously cached charts remain viewable.
- Watchlist remains viewable.
- Cached forecasts remain viewable.
- The UI prominently labels data as OFFLINE/CACHED.
- “LIVE” badges disappear.
- Last-updated timestamps remain visible.

The app must never display cached data as live.

## 19. Security

Requirements:

- HTTPS/WSS only.
- No market-provider secret in APK.
- No news-provider secret in APK.
- No database credential in APK.
- Backend-side input validation.
- Authentication/token support.
- Rate limiting.
- Secure server-side secret storage.
- Signed release APK.
- Android code shrinking/obfuscation where appropriate.
- Logging must avoid leaking secrets.

## 20. Time Zones and Market Calendar

Backend market logic uses `America/New_York` for U.S. exchange sessions.

The app may additionally show user-local time where useful.

A proper U.S. exchange calendar is required for:

- Weekends.
- Full holidays.
- Early closes.
- First/last trading session determination.
- Forecast horizon selection.

## 21. Performance Requirements

Target interaction behavior:

- Scanner opens with cached/precomputed data immediately or near-immediately.
- Live prices stream afterward.
- Sorting/filtering occurs locally where practical.
- Stock detail uses cached result first, then refreshes.
- No screen waits on recalculation of hundreds/thousands of stocks.
- UI remains responsive during quote streaming.

## 22. Error States

The UI must have explicit states for:

- Backend unavailable.
- Market-data feed unavailable.
- Source disagreement.
- Stale data.
- Insufficient data.
- No reliable forecast.
- Trading halt.
- Earnings/event risk.
- Authentication failure.
- Rate limit/provider quota failure.

A failed live dependency must not silently degrade to an unlabeled stale value.

## 23. Testing Strategy

### Android tests

- API response parsing.
- Stock search.
- Watchlist add/remove.
- Theme switching.
- Scanner filters.
- Scanner sorting.
- Offline cache.
- Stale-data labeling.
- Error states.
- Forecast display.
- Notification preferences.
- Navigation.

### Backend tests

- Quote normalization.
- Source disagreement.
- Missing/stale data.
- Market hours.
- U.S. holidays.
- Early closes.
- Splits/reverse splits.
- Halt detection.
- Earnings events.
- Indicator calculations.
- Forecast scoring.
- Confidence scoring.
- Weekly reference handling.
- Final-session target handling.
- Scanner ranking.
- API validation.

### Backtesting tests

- No future data leakage.
- Historical source timestamps respected.
- Model-version reproducibility.
- Confidence calibration.
- Correct corporate-action adjustment.

### Release verification

The project is not “ready” merely because it compiles. Before calling V1 ready:

- APK installs on Android.
- APK launches without crashing.
- Light theme works.
- Dark theme works.
- Search works.
- Real backend connection works.
- Live stock screen works.
- Charts work.
- Monday → Friday stock list works.
- Filtering/sorting works.
- Forecast report works.
- Watchlist works.
- Offline behavior works.
- Server failures are handled.
- Stale data is labeled.
- No secrets are embedded in APK.
- Release APK is signed and generated.
- APK integrity is verified.

## 24. Build Outputs

Development build:

```text
MarketInsightAI-debug.apk
```

Release build:

```text
MarketInsightAI-v1.0.apk
```

Working package name:

```text
com.marketinsight.ai
```

Working product name:

```text
Market Insight AI
```

Both can be renamed before final release.

## 25. Definition of Success

V1 is successful when a user can:

1. Install the release APK on Android.
2. Open the app and see live U.S. market context.
3. Search any supported U.S. stock.
4. Open a detailed stock report.
5. View a clearly labeled live price and freshness state.
6. View tomorrow and weekly probabilistic forecasts.
7. Open the Monday → Friday scanner and rank stocks by expected opportunity.
8. See technical, fundamental, news, macro, sector, and source-verification evidence.
9. Understand why the model produced a forecast.
10. See confidence and historical accuracy instead of guaranteed-return claims.
11. Add stocks to a watchlist and configure alerts.
12. Continue viewing cached data offline without mistaking it for live data.

## 26. Implementation Sequencing Principle

Implementation should proceed in vertical slices rather than building all backend modules first or all Android screens first. The first end-to-end slice should prove:

1. Android app launches in light/dark theme.
2. Backend serves one real U.S. ticker.
3. Live/current price and chart render.
4. One hybrid forecast response renders.
5. One weekly-scanner row renders.
6. Tests verify the data path.

After that, expand to the full stock universe, analysis subsystems, scanner ranking, notifications, and release hardening.

