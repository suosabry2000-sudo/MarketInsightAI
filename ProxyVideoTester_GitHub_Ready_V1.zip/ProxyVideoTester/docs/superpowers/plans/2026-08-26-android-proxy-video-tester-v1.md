# Android Proxy Video Tester V1 Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a repo-ready Android app that sequentially tests user-supplied proxy endpoints by verifying the external IP and playing an authorized direct media URL for a configured amount of actual Media3 playback time.

**Architecture:** Single Android application module using Compose for UI, Room/DataStore for local data, OkHttp-based networking for IP verification, and Media3 ExoPlayer for real media playback. Domain logic owns parsing, queue progression, timing, and deterministic status classification so the UI remains thin and testable.

**Tech Stack:** Kotlin, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, Media3 1.5.1, Room 2.6.1, DataStore 1.1.1, OkHttp 4.12.0, JUnit 4.13.2, AndroidX test/Compose test, GitHub Actions.

**Spec:** `docs/superpowers/specs/2026-08-26-android-proxy-video-tester-design.md`

## Global Constraints

- The app is a network/video QA tool and must not include artificial engagement or public-view inflation functionality.
- Process proxy endpoints sequentially in V1.
- Default requested playback duration is 60 seconds.
- Count only actual `Player.STATE_READY && playWhenReady` playback time; buffering/paused time does not count.
- A PASS requires successful proxy/IP verification and the requested actual playing duration.
- Never log/export proxy passwords by default; redact credentials and sensitive query parameters.
- Keep TLS certificate verification enabled.
- Stop testing promptly when the user cancels.
- CI acceptance: `./gradlew test`, `./gradlew lint`, and `./gradlew assembleDebug` pass and the APK is uploaded as an Actions artifact.

---

## File Structure

- `settings.gradle.kts` — project repositories and module registration.
- `build.gradle.kts` — top-level plugin versions.
- `gradle.properties` — Android/Gradle defaults.
- `app/build.gradle.kts` — Android dependencies and test configuration.
- `app/src/main/AndroidManifest.xml` — app/network permissions and launcher activity.
- `app/src/main/java/com/example/proxyvideotester/MainActivity.kt` — Compose host.
- `app/src/main/java/com/example/proxyvideotester/domain/ProxyEndpoint.kt` — normalized proxy model.
- `app/src/main/java/com/example/proxyvideotester/domain/EndpointParser.kt` — input parsing/validation.
- `app/src/main/java/com/example/proxyvideotester/domain/TestModels.kt` — statuses/session/result data types.
- `app/src/main/java/com/example/proxyvideotester/domain/PlaybackClock.kt` — active-playback time accounting.
- `app/src/main/java/com/example/proxyvideotester/domain/TestSessionEngine.kt` — sequential queue state machine.
- `app/src/main/java/com/example/proxyvideotester/network/ProxyClientFactory.kt` — per-endpoint OkHttp client creation.
- `app/src/main/java/com/example/proxyvideotester/network/IpVerifier.kt` — connectivity/IP verification.
- `app/src/main/java/com/example/proxyvideotester/player/MediaPlaybackRunner.kt` — Media3 playback wrapper and metrics.
- `app/src/main/java/com/example/proxyvideotester/data/AppDatabase.kt` — Room DB and converters.
- `app/src/main/java/com/example/proxyvideotester/data/Entities.kt` — Room entities.
- `app/src/main/java/com/example/proxyvideotester/data/Dao.kt` — endpoint/result/session persistence.
- `app/src/main/java/com/example/proxyvideotester/data/TesterRepository.kt` — domain/data bridge.
- `app/src/main/java/com/example/proxyvideotester/ui/MainViewModel.kt` — orchestration and UI state.
- `app/src/main/java/com/example/proxyvideotester/ui/App.kt` — navigation/root UI.
- `app/src/main/java/com/example/proxyvideotester/ui/DashboardScreen.kt` — main run controls/status.
- `app/src/main/java/com/example/proxyvideotester/ui/ProxyListScreen.kt` — import/edit/validation.
- `app/src/main/java/com/example/proxyvideotester/ui/ResultsScreen.kt` — persisted results and export triggers.
- `app/src/main/java/com/example/proxyvideotester/export/ResultExporter.kt` — CSV/JSON serialization.
- `.github/workflows/android.yml` — CI tests/lint/debug APK artifact.
- `README.md` — setup, supported proxy forms, build/use instructions, safety scope.

---

### Task 1: Project shell and CI baseline

**Files:**
- Create: `settings.gradle.kts`
- Create: `build.gradle.kts`
- Create: `gradle.properties`
- Create: `app/build.gradle.kts`
- Create: `app/src/main/AndroidManifest.xml`
- Create: `app/src/main/java/com/example/proxyvideotester/MainActivity.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/ui/App.kt`
- Create: `.github/workflows/android.yml`
- Create: `README.md`

**Interfaces:**
- Produces Android package `com.example.proxyvideotester` and a Compose app entry point `ProxyVideoTesterApp()`.

- [ ] **Step 1: Create the Gradle/Android project and a smoke unit test**

Create `app/src/test/java/com/example/proxyvideotester/SmokeTest.kt`:

```kotlin
package com.example.proxyvideotester

import org.junit.Assert.assertTrue
import org.junit.Test

class SmokeTest {
    @Test fun projectLoads() = assertTrue(true)
}
```

- [ ] **Step 2: Run the smoke test**

Run: `./gradlew testDebugUnitTest`
Expected: PASS.

- [ ] **Step 3: Add Compose launcher UI**

`MainActivity` calls `setContent { ProxyVideoTesterApp() }`; `ProxyVideoTesterApp()` shows title `Proxy Video Tester`, a text field placeholder for media URL, and a disabled `Start Test` button until valid input exists.

- [ ] **Step 4: Add CI workflow**

Workflow jobs on push/pull request run Java 17, Gradle cache, `./gradlew test`, `./gradlew lint`, `./gradlew assembleDebug`, then upload `app/build/outputs/apk/debug/app-debug.apk` as artifact `proxy-video-tester-debug-apk`.

- [ ] **Step 5: Commit**

```bash
git add settings.gradle.kts build.gradle.kts gradle.properties app .github/workflows/android.yml README.md
git commit -m "chore: scaffold Android proxy video tester"
```

---

### Task 2: Endpoint parser and validation

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/domain/ProxyEndpoint.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/domain/EndpointParser.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/domain/EndpointParserTest.kt`

**Interfaces:**
- Produces: `EndpointParser.parseLine(String): ParseResult`
- Produces: `EndpointParser.parseMultiline(String): List<ParseResult>`
- Produces model: `ProxyEndpoint(host, port, type, username, password, enabled)`

- [ ] **Step 1: Write parser tests**

Cover `host:port`, `http://host:port`, `http://user:pass@host:port`, malformed line, invalid port, blank line, and 100-line paste preserving order.

- [ ] **Step 2: Run tests and verify failure**

Run: `./gradlew testDebugUnitTest --tests '*EndpointParserTest*'`
Expected: FAIL because parser types do not exist.

- [ ] **Step 3: Implement parser**

Normalize omitted scheme to HTTP; allow HTTP and SOCKS5 enum values; reject ports outside `1..65535`; trim whitespace; preserve username/password only in the model and never include them in `toString()`.

- [ ] **Step 4: Run parser tests**

Run: `./gradlew testDebugUnitTest --tests '*EndpointParserTest*'`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/domain app/src/test/java/com/example/proxyvideotester/domain
git commit -m "feat: parse and validate proxy endpoints"
```

---

### Task 3: Playback timing and result classification

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/domain/TestModels.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/domain/PlaybackClock.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/domain/PlaybackClockTest.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/domain/StatusClassificationTest.kt`

**Interfaces:**
- Produces: `PlaybackClock.onPlayingChanged(isPlaying: Boolean, nowMs: Long)`
- Produces: `PlaybackClock.playedMs(nowMs: Long): Long`
- Produces enum statuses exactly: `PASSED`, `PROXY_UNREACHABLE`, `IP_VERIFY_FAILED`, `MEDIA_PREPARE_FAILED`, `PLAYBACK_FAILED`, `PLAYBACK_TIMEOUT`, `USER_CANCELLED`.

- [ ] **Step 1: Write failing timing tests**

Verify 20s playing + 10s buffering + 40s playing = 60s counted playback, not 70s wall time.

- [ ] **Step 2: Run timing tests and verify failure**

Run: `./gradlew testDebugUnitTest --tests '*PlaybackClockTest*'`
Expected: FAIL.

- [ ] **Step 3: Implement timing and result models**

Use monotonic elapsed times supplied to `PlaybackClock`; only accumulate intervals while `isPlaying == true`.

- [ ] **Step 4: Run tests**

Run: `./gradlew testDebugUnitTest --tests '*PlaybackClockTest*' --tests '*StatusClassificationTest*'`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/domain/TestModels.kt app/src/main/java/com/example/proxyvideotester/domain/PlaybackClock.kt app/src/test/java/com/example/proxyvideotester/domain
git commit -m "feat: add playback timing and result models"
```

---

### Task 4: Proxy-aware network/IP verification

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/network/ProxyClientFactory.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/network/IpVerifier.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/network/ProxyClientFactoryTest.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/network/IpVerifierTest.kt`

**Interfaces:**
- Consumes: `ProxyEndpoint`
- Produces: `ProxyClientFactory.create(endpoint, timeoutMs): OkHttpClient`
- Produces: `IpVerifier.verify(client, endpointUrl): IpVerificationResult`

- [ ] **Step 1: Write client construction tests**

Verify HTTP endpoints create Java `Proxy.Type.HTTP`, optional Basic `Proxy-Authorization` is added through an authenticator, and credentials never appear in thrown error messages.

- [ ] **Step 2: Run tests and verify failure**

Run: `./gradlew testDebugUnitTest --tests '*ProxyClientFactoryTest*' --tests '*IpVerifierTest*'`
Expected: FAIL.

- [ ] **Step 3: Implement HTTP proxy client and IP verifier**

Default IP echo URL: `https://api.ipify.org`; require a non-empty textual IP response; record elapsed connect/request time using `SystemClock.elapsedRealtime()` in production and injected clock in tests.

For SOCKS5, construct `Proxy(Type.SOCKS, InetSocketAddress(host, port))` only for unauthenticated endpoints in V1; authenticated SOCKS5 lines remain parsed but are marked unsupported during preflight with a clear validation error.

- [ ] **Step 4: Run network unit tests**

Run: `./gradlew testDebugUnitTest --tests '*ProxyClientFactoryTest*' --tests '*IpVerifierTest*'`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/network app/src/test/java/com/example/proxyvideotester/network
git commit -m "feat: verify public IP through configured proxy"
```

---

### Task 5: Real Media3 playback runner

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/player/MediaPlaybackRunner.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/player/MediaPlaybackRunnerLogicTest.kt`

**Interfaces:**
- Consumes: authorized direct MP4/HLS/DASH URL, requested duration, proxy endpoint.
- Produces: `suspend fun run(request: PlaybackRequest): PlaybackMetrics`
- `PlaybackMetrics` reports actual playing ms, wall-clock ms, buffering ms/count, and final failure category when applicable.

- [ ] **Step 1: Write state-accounting tests**

Drive a fake player-state source through READY/playing → BUFFERING → READY/playing and assert requested playback completes only after counted playing time reaches the request.

- [ ] **Step 2: Run tests and verify failure**

Run: `./gradlew testDebugUnitTest --tests '*MediaPlaybackRunnerLogicTest*'`
Expected: FAIL.

- [ ] **Step 3: Implement the Media3 wrapper**

Use `ExoPlayer.Builder(context)` and `DefaultMediaSourceFactory`; configure a proxy-aware `HttpDataSource.Factory` for HTTP proxy support using an OkHttp-backed Media3 data source. Observe `Player.Listener` state changes, update `PlaybackClock`, count buffering transitions, stop/release in `finally`, and treat Media3 errors as `PLAYBACK_FAILED` or `MEDIA_PREPARE_FAILED` depending on whether READY was reached.

Authenticated SOCKS5 media playback remains unsupported in V1 and is rejected before the run; HTTP proxy playback is the acceptance path.

- [ ] **Step 4: Run playback logic tests**

Run: `./gradlew testDebugUnitTest --tests '*MediaPlaybackRunnerLogicTest*'`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/player app/src/test/java/com/example/proxyvideotester/player
git commit -m "feat: add real Media3 playback measurement"
```

---

### Task 6: Sequential session engine

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/domain/TestSessionEngine.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/domain/TestSessionEngineTest.kt`

**Interfaces:**
- Consumes: enabled endpoints, media URL, duration, `IpVerifier`, `MediaPlaybackRunner`.
- Produces: `StateFlow<SessionState>` and one deterministic `EndpointTestResult` per attempted endpoint.

- [ ] **Step 1: Write state-machine tests**

Verify: endpoints run in insertion order; one failure proceeds to next; stop returns `USER_CANCELLED` for current endpoint and does not start remaining endpoints; PASS requires both IP verification and sufficient playback duration.

- [ ] **Step 2: Run tests and verify failure**

Run: `./gradlew testDebugUnitTest --tests '*TestSessionEngineTest*'`
Expected: FAIL.

- [ ] **Step 3: Implement engine**

Use a coroutine loop with an `AtomicBoolean`/Job cancellation boundary, one connectivity retry only for transient connection exceptions, no repeated playback retries, and state counters for passed/failed/remaining.

- [ ] **Step 4: Run engine tests**

Run: `./gradlew testDebugUnitTest --tests '*TestSessionEngineTest*'`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/domain/TestSessionEngine.kt app/src/test/java/com/example/proxyvideotester/domain/TestSessionEngineTest.kt
git commit -m "feat: add sequential proxy test session engine"
```

---

### Task 7: Room persistence and repository

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/data/Entities.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/data/Dao.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/data/AppDatabase.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/data/TesterRepository.kt`
- Create: `app/src/androidTest/java/com/example/proxyvideotester/data/AppDatabaseTest.kt`

**Interfaces:**
- Produces Room entities for endpoint metadata, sessions, and endpoint results.
- Password is not stored in Room; runtime credentials are held in memory and can later be integrated with Android Keystore-backed secure storage.

- [ ] **Step 1: Write Room instrumentation test**

Insert one endpoint and one result, reopen DAO query, and assert both values survive database instance recreation.

- [ ] **Step 2: Implement entities/DAO/database/repository**

Store endpoint host/port/type/username/enabled and last test metadata; do not persist plaintext password. Store complete result metrics and session summaries.

- [ ] **Step 3: Run instrumentation tests on emulator/device when available**

Run: `./gradlew connectedDebugAndroidTest`
Expected: PASS on configured Android emulator/device. If none is available locally, CI remains responsible only for unit/lint/build while this test is retained for device execution.

- [ ] **Step 4: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/data app/src/androidTest/java/com/example/proxyvideotester/data
git commit -m "feat: persist endpoints and test results"
```

---

### Task 8: Compose screens and ViewModel

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/ui/MainViewModel.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/ui/DashboardScreen.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/ui/ProxyListScreen.kt`
- Create: `app/src/main/java/com/example/proxyvideotester/ui/ResultsScreen.kt`
- Modify: `app/src/main/java/com/example/proxyvideotester/ui/App.kt`
- Create: `app/src/androidTest/java/com/example/proxyvideotester/ui/DashboardScreenTest.kt`

**Interfaces:**
- `MainViewModel` exposes immutable `StateFlow<MainUiState>` and actions for import, start, stop, delete/enable endpoint, and results navigation.

- [ ] **Step 1: Write Compose validation test**

Assert invalid media URL disables Start; valid direct HTTPS media URL plus at least one valid enabled endpoint enables Start; stop control appears during running session.

- [ ] **Step 2: Implement screens**

Dashboard displays media URL, duration, endpoint count, Start/Stop, current endpoint, detected IP, playback timer, state, and counters. Proxy list supports multiline paste with inline errors. Results supports passed/failed filter and endpoint metrics.

- [ ] **Step 3: Run unit/build checks**

Run: `./gradlew testDebugUnitTest assembleDebug`
Expected: PASS.

- [ ] **Step 4: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/ui app/src/androidTest/java/com/example/proxyvideotester/ui
git commit -m "feat: add dashboard proxy list and results UI"
```

---

### Task 9: CSV/JSON export and redaction

**Files:**
- Create: `app/src/main/java/com/example/proxyvideotester/export/ResultExporter.kt`
- Create: `app/src/test/java/com/example/proxyvideotester/export/ResultExporterTest.kt`

**Interfaces:**
- Produces: `toCsv(results): String`
- Produces: `toJson(results): String`
- Produces: `redactUrl(url): String`

- [ ] **Step 1: Write export tests**

Assert CSV/JSON include endpoint host/port, detected IP, timing/status metrics, but exclude password and strip sensitive query values from target URL representation.

- [ ] **Step 2: Implement exporter**

Use deterministic column order and valid JSON escaping. Target URL display stores scheme/host/path and replaces query with `?redacted` when present.

- [ ] **Step 3: Run tests**

Run: `./gradlew testDebugUnitTest --tests '*ResultExporterTest*'`
Expected: PASS.

- [ ] **Step 4: Commit**

```bash
git add app/src/main/java/com/example/proxyvideotester/export app/src/test/java/com/example/proxyvideotester/export
git commit -m "feat: export redacted test results"
```

---

### Task 10: Final verification and repo-ready package

**Files:**
- Modify: `README.md`
- Verify: `.github/workflows/android.yml`
- Verify all source/test files.

**Interfaces:**
- Produces a repo that can be pushed to GitHub and automatically builds a debug APK artifact.

- [ ] **Step 1: Run full unit suite**

Run: `./gradlew test`
Expected: PASS.

- [ ] **Step 2: Run Android lint**

Run: `./gradlew lint`
Expected: PASS with no fatal errors.

- [ ] **Step 3: Build debug APK**

Run: `./gradlew assembleDebug`
Expected: `app/build/outputs/apk/debug/app-debug.apk` exists.

- [ ] **Step 4: Verify README**

README must state supported input forms, direct authorized media requirement, HTTP proxy acceptance path, SOCKS5 V1 limitations, local build commands, GitHub Actions artifact location, and that the app is not for public engagement manipulation.

- [ ] **Step 5: Commit final verification/docs**

```bash
git add README.md .github/workflows/android.yml
git commit -m "docs: finalize build and usage instructions"
```
