import com.example.proxyvideotester.network.IpLiteralValidator

fun main() {
    check(IpLiteralValidator.isValid("8.8.8.8"))
    check(IpLiteralValidator.isValid("2001:4860:4860::8888"))
    check(!IpLiteralValidator.isValid("example.com"))
    check(!IpLiteralValidator.isValid("dead.beef"))
    check(!IpLiteralValidator.isValid("999.1.1.1"))
    check(!IpLiteralValidator.isValid(""))
}
