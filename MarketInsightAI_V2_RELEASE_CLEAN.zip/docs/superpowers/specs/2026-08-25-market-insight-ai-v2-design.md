# Market Insight AI V2 Design

## Goal
Upgrade the existing online Android app from a small featured-stock experience to a production-style market browser with a large U.S. tradable universe, modern trading-app UI, fast search/filtering, and explicit price sorting from high-to-low and low-to-high.

## Market universe
- The backend remains source-of-truth for market metadata and quotes.
- V2 loads the broad active U.S. listed equity universe and ETF-like listed funds where the upstream catalog can identify them.
- The app must not claim exact Robinhood availability unless Robinhood provides authoritative tradability evidence for the symbol. The UI labels the catalog as `U.S. tradable universe`; a future `Robinhood verified` filter can be enabled when authoritative tradability data is connected.
- Catalog pagination supports thousands of symbols without sending all quote updates to the phone at once.

## Pricing and sorting
- All Stocks supports `Price: High → Low` and `Price: Low → High`.
- Sorting is based on latest verified/cached quote price from the backend, not a static hard-coded price.
- Unknown/unverified prices sort last.
- Other sorts remain available: symbol A→Z, symbol Z→A, % change high/low, most active, confidence when forecast data is present.
- Price data is fetched in pages/batches and cached server-side so the UI can scroll smoothly.

## Search and filters
- Search by ticker, company name, and partial match.
- Filters: All, Stocks, ETFs/Funds where identifiable, NASDAQ, NYSE, NYSE American, Technology, AI, Semiconductors, Energy, Healthcare, Financials, Consumer, Industrials, Utilities, Real Estate, Materials, Watchlist.
- Filters and sorts compose: e.g. `Technology + Price High → Low`.

## Android UI
- Keep Material 3, Kotlin, Jetpack Compose, bottom navigation.
- Modernize Home and Markets with tighter spacing, stronger hierarchy, compact rows, elevated surfaces, rounded search, filter chips, sort sheet/menu, live/delayed badges, watchlist star, and compact price/change typography.
- All Stocks uses lazy rows with ticker, company, exchange/category, latest price, day change, and a placeholder/sparkline slot for later chart enrichment.
- Home remains curated (market status, indexes, movers, watchlist, scanner entry) while Markets is the full-universe browser.

## Performance and safety
- Do not fire one HTTP request per visible symbol from Android.
- Backend exposes paged enriched catalog rows and caches bulk quote snapshots.
- Public Yahoo fallback remains explicitly labeled limited/delayed; stale prices are not labeled live.
- Existing forecast disclaimers and data-quality handling remain intact.

## Acceptance criteria
1. Markets can browse thousands of symbols from backend catalog pagination.
2. Search finds symbols beyond the built-in demo list.
3. Price High→Low and Low→High work and place unknown prices last.
4. Filters compose with price sorting.
5. Home/Markets visual hierarchy is noticeably more modern than V1 while preserving accessibility and dark/light themes.
6. Existing backend tests, Kotlin smoke checks, Android unit tests, release build, signature verification, and secret scan pass.
