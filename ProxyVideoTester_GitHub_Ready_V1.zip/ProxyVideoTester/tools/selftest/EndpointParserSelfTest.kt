import com.example.proxyvideotester.domain.EndpointParser
import com.example.proxyvideotester.domain.ParseResult
import com.example.proxyvideotester.domain.ProxyType

fun main() {
    val bare = EndpointParser.parseLine("127.0.0.1:8080")
    check(bare is ParseResult.Valid)
    check(bare.endpoint.host == "127.0.0.1")
    check(bare.endpoint.port == 8080)
    check(bare.endpoint.type == ProxyType.HTTP)

    val auth = EndpointParser.parseLine("http://sam:secret@proxy.example:3128")
    check(auth is ParseResult.Valid)
    check(auth.endpoint.username == "sam")
    check(auth.endpoint.password == "secret")
    check(!auth.endpoint.toString().contains("secret"))

    val invalid = EndpointParser.parseLine("proxy.example:99999")
    check(invalid is ParseResult.Invalid)

    val hundred = (1..100).joinToString("\n") { "10.0.0.$it:8080" }
    val parsed = EndpointParser.parseMultiline(hundred)
    check(parsed.size == 100)
    check((parsed.first() as ParseResult.Valid).endpoint.host == "10.0.0.1")
    check((parsed.last() as ParseResult.Valid).endpoint.host == "10.0.0.100")
}
