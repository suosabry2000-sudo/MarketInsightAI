package com.example.proxyvideotester.network

import kotlinx.coroutines.test.runTest
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class IpVerifierTest {
    @Test fun acceptsIpLiteralResponse() = runTest {
        MockWebServer().use { server ->
            server.enqueue(MockResponse().setBody("203.0.113.10\n"))
            val result = IpVerifier.verify(OkHttpClient(), server.url("/").toString())
            assertTrue(result.success)
            assertEquals("203.0.113.10", result.ip)
        }
    }

    @Test fun rejectsNonIpResponse() = runTest {
        MockWebServer().use { server ->
            server.enqueue(MockResponse().setBody("not-an-ip"))
            val result = IpVerifier.verify(OkHttpClient(), server.url("/").toString())
            assertFalse(result.success)
        }
    }
}
