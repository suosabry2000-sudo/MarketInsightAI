package com.example.proxyvideotester.domain

import java.util.UUID

enum class ProxyType { HTTP, SOCKS5 }

data class ProxyEndpoint(
    val id: String = UUID.randomUUID().toString(),
    val label: String? = null,
    val host: String,
    val port: Int,
    val type: ProxyType = ProxyType.HTTP,
    val username: String? = null,
    val password: String? = null,
    val enabled: Boolean = true,
    val lastDetectedPublicIp: String? = null,
    val lastStatus: String? = null,
    val lastLatencyMs: Long? = null,
    val lastTestedAtEpochMs: Long? = null,
) {
    fun authority(): String = "$host:$port"

    override fun toString(): String {
        val scheme = if (type == ProxyType.SOCKS5) "socks5" else "http"
        val user = username?.takeIf { it.isNotBlank() }?.let { "$it@" }.orEmpty()
        return "$scheme://$user$host:$port"
    }
}
