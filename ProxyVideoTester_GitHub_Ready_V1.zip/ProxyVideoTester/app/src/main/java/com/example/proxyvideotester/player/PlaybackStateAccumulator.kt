package com.example.proxyvideotester.player

import com.example.proxyvideotester.domain.PlaybackClock

data class PlaybackSnapshot(
    val mediaPrepared: Boolean,
    val actualPlayingMs: Long,
    val wallClockMs: Long,
    val timeToFirstPlaybackMs: Long?,
    val bufferingMs: Long,
    val bufferEventCount: Int,
)

class PlaybackStateAccumulator(
    private val startedAtMs: Long,
) {
    private val clock = PlaybackClock()
    private var prepared = false
    private var firstPlaybackAtMs: Long? = null
    private var bufferingSinceMs: Long? = null
    private var accumulatedBufferingMs = 0L
    private var bufferEvents = 0

    fun onPrepared(nowMs: Long) {
        prepared = true
    }

    fun onPlayingChanged(isPlaying: Boolean, nowMs: Long) {
        if (isPlaying && firstPlaybackAtMs == null) firstPlaybackAtMs = nowMs
        clock.onPlayingChanged(isPlaying, nowMs)
    }

    fun onBufferingChanged(isBuffering: Boolean, nowMs: Long) {
        val active = bufferingSinceMs
        when {
            isBuffering && active == null -> {
                bufferingSinceMs = nowMs
                bufferEvents += 1
            }
            !isBuffering && active != null -> {
                accumulatedBufferingMs += (nowMs - active).coerceAtLeast(0)
                bufferingSinceMs = null
            }
        }
    }

    fun snapshot(nowMs: Long): PlaybackSnapshot {
        val activeBuffer = bufferingSinceMs
        val totalBuffering = accumulatedBufferingMs +
            if (activeBuffer != null) (nowMs - activeBuffer).coerceAtLeast(0) else 0
        return PlaybackSnapshot(
            mediaPrepared = prepared,
            actualPlayingMs = clock.playedMs(nowMs),
            wallClockMs = (nowMs - startedAtMs).coerceAtLeast(0),
            timeToFirstPlaybackMs = firstPlaybackAtMs?.let { (it - startedAtMs).coerceAtLeast(0) },
            bufferingMs = totalBuffering,
            bufferEventCount = bufferEvents,
        )
    }
}
