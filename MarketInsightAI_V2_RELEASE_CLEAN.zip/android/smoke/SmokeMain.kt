import com.marketinsight.ai.core.model.DataQuality
import com.marketinsight.ai.core.model.ScannerRow
import com.marketinsight.ai.core.state.FreshnessState
import com.marketinsight.ai.core.state.freshnessState
import com.marketinsight.ai.features.weeklyscanner.ScannerFilter
import com.marketinsight.ai.features.weeklyscanner.ScannerSort
import com.marketinsight.ai.features.weeklyscanner.applyScannerFilter
import com.marketinsight.ai.features.weeklyscanner.applyScannerSort
import com.marketinsight.ai.features.markets.filterStockCatalog
import com.marketinsight.ai.features.markets.CatalogSort
import com.marketinsight.ai.features.markets.applyCatalogFiltersAndSort
import com.marketinsight.ai.features.markets.builtInStockCatalog
import com.marketinsight.ai.core.model.StockSearchResult

fun main() {
    check(freshnessState(isOffline = true, ageSeconds = 1.0, quality = DataQuality.VERIFIED) == FreshnessState.OFFLINE)
    check(freshnessState(isOffline = false, ageSeconds = 180.0, quality = DataQuality.VERIFIED) == FreshnessState.STALE)
    val rows = listOf(
        ScannerRow("AAPL", 100.0, 101.0, 95.0, 106.0, 110.0, 6.0, 4.95, .7, .3, 80.0, 72.0, "BULLISH", "MEDIUM", DataQuality.VERIFIED, "NASDAQ", "Technology", listOf("S&P 500", "Nasdaq"), listOf("Technology", "AI"), "Mega Cap", true, .25),
        ScannerRow("AMD", 100.0, 98.0, 90.0, 94.0, 105.0, -6.0, -4.08, .3, .7, 75.0, 58.0, "BEARISH", "HIGH", DataQuality.LIMITED, "NASDAQ", "Technology", listOf("S&P 500", "Nasdaq"), listOf("Technology", "Semiconductors"), "Mega Cap", true, .45),
    )
    check(applyScannerFilter(rows, ScannerFilter.AI).map { it.ticker } == listOf("AAPL"))
    check(applyScannerFilter(rows, ScannerFilter.SEMICONDUCTORS).map { it.ticker } == listOf("AMD"))
    check(applyScannerSort(rows, ScannerSort.HIGHEST_GAIN).first().ticker == "AAPL")
    check(applyScannerSort(rows, ScannerSort.HIGHEST_DROP).first().ticker == "AMD")
    check(builtInStockCatalog.size >= 100)
    check(listOf("AAPL", "JPM", "XOM", "UNH", "CAT").all { ticker -> builtInStockCatalog.any { it.ticker == ticker } })
    val catalog = (0 until 300).map { i ->
        StockSearchResult("T%04d".format(i), "Test Company $i", if (i % 2 == 0) "NASDAQ" else "NYSE", if (i % 3 == 0) "Technology" else "Financial")
    }
    check(filterStockCatalog(catalog, "T0299").single().ticker == "T0299")
    check(filterStockCatalog(catalog, "Test Company 12").any { it.ticker == "T0012" })
    check(filterStockCatalog(catalog, "", exchange = "NYSE").all { it.exchange == "NYSE" })
    val priced = listOf(
        StockSearchResult("AAA", "Alpha", "NYSE", "Technology", "STOCK", 10.0, 1.0, "AVAILABLE"),
        StockSearchResult("BBB", "Beta", "NASDAQ", "Technology", "STOCK", 30.0, -1.0, "AVAILABLE"),
        StockSearchResult("CCC", "Gamma", "NYSE", "Financial", "STOCK", 20.0, 0.5, "AVAILABLE"),
        StockSearchResult("MISS", "Missing", "NYSE", "Technology", "STOCK", null, null, "UNAVAILABLE"),
    )
    check(applyCatalogFiltersAndSort(priced, sort = CatalogSort.PRICE_HIGH_LOW).map { it.ticker } == listOf("BBB", "CCC", "AAA", "MISS"))
    check(applyCatalogFiltersAndSort(priced, sort = CatalogSort.PRICE_LOW_HIGH).map { it.ticker } == listOf("AAA", "CCC", "BBB", "MISS"))
    check(applyCatalogFiltersAndSort(priced, exchange = "NYSE", sector = "Technology", sort = CatalogSort.PRICE_LOW_HIGH).map { it.ticker } == listOf("AAA", "MISS"))
    println("Kotlin smoke checks passed")
}
