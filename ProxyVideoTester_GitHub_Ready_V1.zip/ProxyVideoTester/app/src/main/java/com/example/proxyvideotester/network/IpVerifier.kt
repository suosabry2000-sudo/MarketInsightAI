package com.example.proxyvideotester.network

import java.net.InetAddress
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

data class IpVerificationResult(
    val success: Boolean,
    val reachable: Boolean,
    val retryable: Boolean,
    val ip: String? = null,
    val latencyMs: Long? = null,
    val error: String? = null,
)

object IpLiteralValidator {
    private val allowed = Regex("^[0-9A-Fa-f:.]+$")

    fun isValid(value: String): Boolean {
        val candidate = value.trim()
        if (candidate.isEmpty() || !allowed.matches(candidate)) return false
        if (candidate.contains(':')) {
            return runCatching { InetAddress.getByName(candidate) }.isSuccess
        }
        val octets = candidate.split('.')
        if (octets.size != 4) return false
        return octets.all { part ->
            part.isNotEmpty() && part.all(Char::isDigit) && part.toIntOrNull() in 0..255
        }
    }
}

object IpVerifier {
    const val DEFAULT_IP_ECHO_URL = "https://api.ipify.org"

    suspend fun verify(
        client: OkHttpClient,
        endpointUrl: String = DEFAULT_IP_ECHO_URL,
        nowMs: () -> Long = { System.nanoTime() / 1_000_000L },
    ): IpVerificationResult = withContext(Dispatchers.IO) {
        val started = nowMs()
        try {
            val request = Request.Builder().url(endpointUrl).get().build()
            client.newCall(request).execute().use { response ->
                val elapsed = (nowMs() - started).coerceAtLeast(0)
                if (!response.isSuccessful) {
                    return@withContext IpVerificationResult(
                        success = false,
                        reachable = true,
                        retryable = response.code >= 500,
                        latencyMs = elapsed,
                        error = "IP check returned HTTP ${response.code}",
                    )
                }
                val value = response.body?.string()?.trim().orEmpty()
                if (!IpLiteralValidator.isValid(value)) {
                    return@withContext IpVerificationResult(
                        success = false,
                        reachable = true,
                        retryable = false,
                        latencyMs = elapsed,
                        error = "IP check did not return an IP address",
                    )
                }
                IpVerificationResult(success = true, reachable = true, retryable = false, ip = value, latencyMs = elapsed)
            }
        } catch (error: Exception) {
            IpVerificationResult(
                success = false,
                reachable = false,
                retryable = true,
                latencyMs = (nowMs() - started).coerceAtLeast(0),
                error = error.javaClass.simpleName.ifBlank { "Connection failed" },
            )
        }
    }
}
